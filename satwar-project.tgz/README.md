# 卫星战争 (Satellite War: Organic Frontlines) —— 安卓版

把 WebSim 上的网页游戏打包成可直接安装的 APK。

## 这个工程做了什么

- 用系统 WebView 运行游戏，全屏、保持亮屏、支持横竖屏。
- 游戏文件、地图数据（Natural Earth）、国旗、Leaflet、JSZip 全部打进安装包，**不需要 VPN**。
- 默认使用“简化模式”，不加载卫星底图。想用卫星底图，需要联网（ArcGIS 一般可直连）。
- 原本依赖 WebSim 的功能改为**仅本机可用**：社区中心(Hub)、国家库/国旗库、评论、全球聊天。
  你保存的内容存在手机本地，别人看不到。“捐助”按钮不会有任何效果。
- 游戏里导出的文件（预设、国家文件、zip、图片）会保存到手机的 `下载/SatelliteWar/` 文件夹。
- 导入文件（自定义音乐、预设）会弹出系统文件选择器。

## 工程里还缺的游戏文件（只有 WebSim 上才有）

放进 `app/src/main/assets/www/`，没有它们 APK 也能打出来，但对应功能会缺失：

| 文件 | 缺了会怎样 |
|---|---|
| `style.css` | 界面没有样式，**必须有** |
| `other thing (1).png` | 主菜单没有 logo |
| `world map 2022.json` | “现代”剧本进不去（会退回到空白地图） |
| `explosion-pas-61639.mp3` `low-button-click-331780.mp3` `war.wav` `peace.wav` `modern-war-129016.mp3` | 对应的音效没声音 |
| `1942.json` `world_war_1__1914_.json` `1804_map.json` `1492_map (2).json` `1ad.json` `1948 (1).json` `better_cold_war_preset.json` `ww2_releasables_fixed_preset.json` `canada_states (1).json` `my_custom_preset (7).json` | 对应的历史剧本进不去 |

背景音乐（3 首 mp3）可以不放，游戏里仍可在设置中导入自己的音乐。

## 用 GitHub 在线打包（不需要电脑）

1. 新建一个 GitHub 仓库。
2. 在仓库首页点 **Add file → Upload files**，上传 `satwar-project.tgz`。
3. 点 **Add file → Create new file**，文件名填 `.github/workflows/build.yml`
   （输入斜杠会自动建文件夹），内容粘贴 `build.yml` 的全部文字，提交。
4. 进入 **Actions** 页，选 **Build APK → Run workflow**。等几分钟。
5. 构建成功后，点进这次运行，在页面底部 **Artifacts** 下载 `SatelliteWar-APK`，
   解压得到 `SatelliteWar.apk`，在手机上安装（需要允许“安装未知来源应用”）。

构建失败的话，把失败那一步的报错文字发给我。

## 注意

- 游戏本体署名为 thepineguy，仅限自己使用。公开发布前请先取得原作者同意。
- 这是调试签名的 APK，可以直接安装，但不能上架应用商店。
