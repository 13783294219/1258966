/*
 * android-shim.js
 * Loaded before the game. Replaces the WebSim-only APIs the game expects
 * (WebsimSocket / window.websim) with local, offline equivalents, and makes
 * file export and external links work inside an Android WebView.
 *
 * Community features (Hub, Country/Flag Library, comments, global chat) become
 * LOCAL ONLY: whatever you save/share is stored on this device (IndexedDB).
 */
(function () {
  'use strict';

  var USER = { id: 'local-player', username: 'Player' };
  var hasBridge = typeof window.AndroidBridge !== 'undefined';

  // ---------------------------------------------------------------- cookies
  // The game shows a "support / join Discord" popup once; mark it as seen.
  try { document.cookie = 'mw_support_dont_show=true; path=/; max-age=31536000'; } catch (e) {}

  // ---------------------------------------------------------- external links
  window.open = function (url) {
    try {
      if (hasBridge && url) window.AndroidBridge.openExternal(String(url));
    } catch (e) {}
    return null;
  };

  // ------------------------------------------------------ file downloads
  // <a download> with a blob: or data: URL does nothing in a WebView, so we
  // hand the bytes to the Android side, which saves them into Downloads.
  var blobs = new Map();
  var realCreate = URL.createObjectURL.bind(URL);
  var realRevoke = URL.revokeObjectURL.bind(URL);

  URL.createObjectURL = function (obj) {
    var u = realCreate(obj);
    try { if (obj instanceof Blob) blobs.set(u, obj); } catch (e) {}
    return u;
  };
  URL.revokeObjectURL = function (u) {
    // The game revokes right after click(); keep our reference a little longer.
    setTimeout(function () { blobs.delete(u); }, 30000);
    return realRevoke(u);
  };

  function saveBlob(blob, name) {
    var fr = new FileReader();
    fr.onload = function () {
      var s = String(fr.result);
      var i = s.indexOf(',');
      try {
        window.AndroidBridge.saveFile(name, blob.type || 'application/octet-stream', s.substring(i + 1));
      } catch (e) { console.error('saveFile failed', e); }
    };
    fr.onerror = function () { console.error('Could not read blob for saving'); };
    fr.readAsDataURL(blob);
  }

  var realClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    try {
      if (hasBridge && this.hasAttribute('download')) {
        var href = this.href;
        var name = this.getAttribute('download') || 'download';
        var blob = blobs.get(href);
        if (blob) { saveBlob(blob, name); return; }
        if (/^data:/i.test(href)) {
          fetch(href).then(function (r) { return r.blob(); }).then(function (b) { saveBlob(b, name); });
          return;
        }
      }
    } catch (e) { console.error(e); }
    return realClick.apply(this, arguments);
  };

  // ------------------------------------------------------- window.websim
  function fileToDataUrl(file) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onload = function () { resolve(String(fr.result)); };
      fr.onerror = function () { reject(fr.error); };
      fr.readAsDataURL(file);
    });
  }

  window.websim = {
    getCurrentUser: function () { return Promise.resolve({ id: USER.id, username: USER.username }); },
    // Stored as a data: URL so it survives restarts and can be fetch()ed later.
    upload: function (file) { return fileToDataUrl(file); },
    // Tipping the author is a WebSim feature; nothing to do offline.
    postComment: function () { return Promise.resolve(); }
  };

  // --------------------------------------------------------- WebsimSocket
  var DB_NAME = 'satwar-local-v1';
  var STORE = 'records';
  var dbPromise = null;

  function openDb() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function (resolve) {
      try {
        var req = indexedDB.open(DB_NAME, 1);
        req.onupgradeneeded = function () {
          req.result.createObjectStore(STORE, { keyPath: 'key' });
        };
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { resolve(null); };
      } catch (e) { resolve(null); }
    });
    return dbPromise;
  }

  function dbPut(collection, rec) {
    return openDb().then(function (db) {
      if (!db) return;
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(STORE, 'readwrite');
          tx.objectStore(STORE).put({ key: collection + ':' + rec.id, collection: collection, rec: rec });
          tx.oncomplete = function () { resolve(); };
          tx.onerror = function () { resolve(); };
        } catch (e) { resolve(); }
      });
    });
  }

  function dbDelete(collection, id) {
    return openDb().then(function (db) {
      if (!db) return;
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(STORE, 'readwrite');
          tx.objectStore(STORE).delete(collection + ':' + id);
          tx.oncomplete = function () { resolve(); };
          tx.onerror = function () { resolve(); };
        } catch (e) { resolve(); }
      });
    });
  }

  function dbLoadAll() {
    return openDb().then(function (db) {
      if (!db) return [];
      return new Promise(function (resolve) {
        try {
          var req = db.transaction(STORE, 'readonly').objectStore(STORE).getAll();
          req.onsuccess = function () { resolve(req.result || []); };
          req.onerror = function () { resolve([]); };
        } catch (e) { resolve([]); }
      });
    });
  }

  function uid() {
    return Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function matches(rec, criteria) {
    for (var k in criteria) {
      if (Object.prototype.hasOwnProperty.call(criteria, k) && rec[k] !== criteria[k]) return false;
    }
    return true;
  }

  function WebsimSocket() {
    var self = this;
    this.clientId = USER.id;
    this.peers = {};
    this.peers[USER.id] = { username: USER.username, id: USER.id };
    this._data = {};      // collection name -> array of records
    this._subs = {};      // collection name -> array of { cb, criteria }
    this._colls = {};

    this.initialize = function () {
      return dbLoadAll().then(function (rows) {
        rows.forEach(function (row) {
          if (!self._data[row.collection]) self._data[row.collection] = [];
          self._data[row.collection].push(row.rec);
        });
      });
    };

    this._list = function (name, criteria) {
      var arr = (self._data[name] || []).filter(function (r) { return !criteria || matches(r, criteria); });
      return arr.slice().sort(function (a, b) {
        return String(b.created_at).localeCompare(String(a.created_at));
      });
    };

    this._notify = function (name) {
      (self._subs[name] || []).slice().forEach(function (s) {
        try { s.cb(self._list(name, s.criteria)); } catch (e) { console.error(e); }
      });
    };

    this._subscribe = function (name, criteria, cb) {
      if (!self._subs[name]) self._subs[name] = [];
      var entry = { cb: cb, criteria: criteria };
      self._subs[name].push(entry);
      return function () {
        var i = self._subs[name].indexOf(entry);
        if (i >= 0) self._subs[name].splice(i, 1);
      };
    };

    this.collection = function (name) {
      if (self._colls[name]) return self._colls[name];
      var c = {
        getList: function () { return self._list(name); },
        subscribe: function (cb) { return self._subscribe(name, null, cb); },
        filter: function (criteria) {
          return {
            getList: function () { return self._list(name, criteria); },
            subscribe: function (cb) { return self._subscribe(name, criteria, cb); }
          };
        },
        create: function (data) {
          var rec = Object.assign({}, data, {
            id: uid(),
            created_at: new Date().toISOString(),
            username: USER.username,
            user_id: USER.id
          });
          if (!self._data[name]) self._data[name] = [];
          self._data[name].push(rec);
          return dbPut(name, rec).then(function () { self._notify(name); return rec; });
        },
        update: function (id, data) {
          var arr = self._data[name] || [];
          var rec = null;
          for (var i = 0; i < arr.length; i++) { if (arr[i].id === id) { rec = arr[i]; break; } }
          if (!rec) return Promise.reject(new Error('Record not found'));
          Object.assign(rec, data);
          return dbPut(name, rec).then(function () { self._notify(name); return rec; });
        },
        delete: function (id) {
          self._data[name] = (self._data[name] || []).filter(function (r) { return r.id !== id; });
          return dbDelete(name, id).then(function () { self._notify(name); });
        }
      };
      self._colls[name] = c;
      return c;
    };
  }

  window.WebsimSocket = WebsimSocket;
})();
