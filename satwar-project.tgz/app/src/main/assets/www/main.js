import L from 'leaflet';
import JSZip from 'jszip';

/**
 * TRANSLATION SYSTEM (i18n)
 */
const TRANSLATIONS = {
    en: {
        MODERN_WARS: "Modern Wars", LANGUAGE: "Language", LANGUAGE_SUB: "System-wide display language.",
        MAP_RES: "Map Resolution", RES_LOW: "Low (Performance)", RES_STD: "Standard (Medium)", RES_HIGH: "High (Very Heavy)", RES_SUB: "Higher resolution improves borders but slows loading.",
        GRID_DENSITY: "Grid Density", GRID_FAST: "Low (Fast)", GRID_STD: "Standard", GRID_SMOOTH: "High (Smooth)", GRID_INSANE: "Insane (Ultra)", GRID_SUB: "Density affects the smoothness of frontlines.",
        MAX_UNITS: "Max Units (Global)", UNIT_MIN: "100 (Minimalist)", UNIT_STD: "250 (Standard)", UNIT_WAR: "500 (Grand War)", UNIT_STRESS: "1000 (Maximum Stress)", UNIT_SUB: "Reduces unit count for cleaner fronts and better performance.",
        BG_VOLUME: "Background Music Volume", BG_SUB: "Adjusts the volume of the background music.",
        DISABLE_MT: "Disable Mountains", DISABLE_MT_SUB: "Removes terrain-based movement penalties and visual darkening.",
        DISABLE_PROV: "Disable Provinces", DISABLE_PROV_SUB: "Removes the visual internal province subdivisions within countries.",
        HIDE_UNITS: "Hide Units Visually", HIDE_UNITS_SUB: "Disables rendering of unit icons and flags for a significant FPS boost.",
        SAVE_SKIP: "Remember & Skip on Startup", APPLY_INIT: "Apply & Initialize",
        OPERATIONS: "Operations", CONQUEST: "CONQUEST", CONQUEST_SUB: "Global Warfare", EDITOR: "EDITOR", EDITOR_SUB: "World Builder",
        INTELLIGENCE: "Intelligence", HUB: "EDITOR HUB", HUB_SUB: "Community Content", LOAD_FILE: "LOAD FILE", LOAD_FILE_SUB: "Import Preset",
        SYSTEM: "System", ENGINE: "ENGINE", ENGINE_SUB: "Fidelity & FPS", TUTORIAL: "TUTORIAL", TUTORIAL_SUB: "Learn the Ropes",
        SERVER: "SERVER", SERVER_SUB: "Join Discord", CREDITS: "CREDITS", CREDITS_SUB: "Contributors", DONATE: "DONATE", DONATE_SUB: "Support the dev",
        PC_REQD: "System Requirement: High-performance PC recommended. Mobile and low-end hardware may experience significant simulation lag.",
        STABLE: "CONNECTION STABLE", LOADING: "Loading...", GOD_MODE: "GOD MODE", GOD_ACTIVE: "GOD ACTIVE", SIM_PAUSED: "SIMULATION PAUSED",
        SELECT_P1: "Select First Country", SELECT_P2: "Select Enemy Country", CONFLICT_SETUP: "Conflict Setup",
        CHOOSE_ERA: "CHOOSE ERA", MODERN_DAY: "MODERN DAY", MODERN_DAY_SUB: "Present Geopolitics (Real Earth)", WW2_SCENARIO: "1936 SCENARIO", WW2_SCENARIO_SUB: "WW2 Strategic Theater", BACK_TO_MENU: "BACK TO MENU",
        RANDOM_WAR_OFF: "Random War: OFF", RANDOM_WAR_ON: "Random War: ON", ADD_SIDE: "+ Side", FFA: "FFA", SETUP_PROMPT: "Select a side, then click countries on the map to recruit them.",
        STRATEGY: "Attack Strategy", STRAT_ALL: "All Fronts (Global)", STRAT_FOCUS: "Targeted Strike (Localized)", DENSITY: "Force Density",
        FIGHT_TO_DEATH: "FIGHT TO THE DEATH (NO PEACE)", DISABLE_MISSILES: "DISABLE LONG-RANGE MISSILES", DISABLE_MT: "DISABLE MOUNTAINS", DISABLE_PROV: "DISABLE PROVINCES", DISABLE_PUPPETS: "DISABLE PUPPETS (NO VASSAL CALL)",
        INAUGURATE: "Inaugurate Conflict", REBELLION: "Start Rebellion", POLITICAL: "POLITICAL", ARROWS: "ARROWS (BUGGY)", BATTLE_VIS: "BATTLE VISUALS", GOD: "GOD", DIPLOMACY: "DIPLOMACY", RESTART: "RESTART",
        UNITS: "UNITS", VS_MINI: "vs", EDITOR_TOOLS: "EDITOR TOOLS", NEW_NATION: "New Nation", TEST_SCENARIO: "Test Scenario", UPDATE_SCENARIO: "Update Scenario", SAVE_PRESET: "Save Preset", LOAD_PRESET: "Load Preset", SHARE_HUB: "Share to Hub", HUB_TAB: "Editor Hub", COUNTRY_LIB: "Country Library", FLAG_LIB: "Flag Library", SAVE_COUNTRY: "Save Country", LOAD_COUNTRY: "Load Country", PAINT: "Paint", FILL: "Fill", UNCLAIM: "Unclaim", EXIT_EDITOR: "Exit Editor",
        NATIONS: { "Germany": "Germany", "German Reich": "German Reich", "Poland": "Poland", "Russia": "Russia", "United States": "United States", "France": "France", "United Kingdom": "United Kingdom", "Italy": "Italy", "China": "China", "Japan": "Japan", "Soviet Union": "Soviet Union", "Turkey": "Turkey", "Ukraine": "Ukraine", "Belarus": "Belarus", "Brazil": "Brazil", "Canada": "Canada", "Australia": "Australia", "India": "India", "Spain": "Spain", "Mexico": "Mexico", "South Korea": "South Korea", "North Korea": "North Korea", "Vietnam": "Vietnam" }
    },
    ru: {
        MODERN_WARS: "Современные Войны", LANGUAGE: "Язык", LANGUAGE_SUB: "Язык отображения системы.",
        MAP_RES: "Разрешение карты", RES_LOW: "Низкое (Скорость)", RES_STD: "Стандарт (Среднее)", RES_HIGH: "Высокое (Тяжелое)", RES_SUB: "Высокое разрешение улучшает границы, но замедляет загрузку.",
        GRID_DENSITY: "Плотность сетки", GRID_FAST: "Низкая (Быстро)", GRID_STD: "Стандарт", GRID_SMOOTH: "Высокая (Плавно)", GRID_SUB: "Плотность влияет на плавность линий фронта.",
        MAX_UNITS: "Макс. юнитов", UNIT_MIN: "100 (Минимум)", UNIT_STD: "250 (Стандарт)", UNIT_WAR: "500 (Большая война)", UNIT_STRESS: "1000 (Стресс-тест)", UNIT_SUB: "Уменьшает количество юнитов для производительности.",
        BG_VOLUME: "Громкость музыки", BG_SUB: "Регулировка громкости фоновой музыки.",
        DISABLE_MT: "Отключить горы", DISABLE_MT_SUB: "Удаляет штрафы за передвижение по пересеченной местности.",
        DISABLE_PROV: "Отключить провинции", DISABLE_PROV_SUB: "Удаляет внутренние границы внутри стран.",
        HIDE_UNITS: "Скрыть юнитов", HIDE_UNITS_SUB: "Отключает отрисовку иконок юнитов для повышения FPS.",
        SAVE_SKIP: "Запомнить и пропускать при запуске", APPLY_INIT: "Применить и Запустить",
        OPERATIONS: "Операции", CONQUEST: "ЗАВОЕВАНИЕ", CONQUEST_SUB: "Глобальная война", EDITOR: "РЕДАКТОР", EDITOR_SUB: "Конструктор мира",
        INTELLIGENCE: "Разведка", HUB: "ХАБ РЕДАКТОРА", HUB_SUB: "Контент сообщества", LOAD_FILE: "ЗАГРУЗИТЬ", LOAD_FILE_SUB: "Импорт сценария",
        SYSTEM: "Система", ENGINE: "ДВИЖОК", ENGINE_SUB: "Качество и FPS", TUTORIAL: "ОБУЧЕНИЕ", TUTORIAL_SUB: "Изучить основы",
        SERVER: "СЕРВЕР", SERVER_SUB: "Discord", CREDITS: "АВТОРЫ", CREDITS_SUB: "Контрибьюторы", DONATE: "ПОДДЕРЖКА", DONATE_SUB: "Поддержать разработку",
        PC_REQD: "Требования: Рекомендуется мощный ПК. На мобильных устройствах возможны лаги.",
        STABLE: "СОЕДИНЕНИЕ СТАБИЛЬНО", LOADING: "Загрузка...", GOD_MODE: "РЕЖИМ БОГА", GOD_ACTIVE: "БОГ АКТИВЕН", SIM_PAUSED: "СИМУЛЯЦИЯ ПРИОСТАНОВЛЕНА",
        SELECT_P1: "Выберите первую страну", SELECT_P2: "Выберите противника", CONFLICT_SETUP: "Настройка конфликта",
        CHOOSE_ERA: "ВЫБЕРИТЕ ЭПОХУ", MODERN_DAY: "НАШИ ДНИ", MODERN_DAY_SUB: "Современная геополитика", WW2_SCENARIO: "СЦЕНАРИЙ 1936", WW2_SCENARIO_SUB: "Театр Второй мировой войны", BACK_TO_MENU: "В МЕНЮ",
        RANDOM_WAR_OFF: "Случ. война: ВЫКЛ", RANDOM_WAR_ON: "Случ. война: ВКЛ", ADD_SIDE: "+ Сторона", FFA: "Каждый сам за себя", SETUP_PROMPT: "Выберите сторону, затем нажимайте на страны на карте.",
        STRATEGY: "Стратегия атаки", STRAT_ALL: "Все фронты (Глобально)", STRAT_FOCUS: "Точечный удар (Локально)", DENSITY: "Плотность войск",
        FIGHT_TO_DEATH: "ВОЙНА ДО КОНЦА (БЕЗ МИРА)", DISABLE_MISSILES: "ОТКЛЮЧИТЬ РАКЕТЫ", DISABLE_MT: "БЕЗ ГОР", DISABLE_PROV: "БЕЗ ПРОВИНЦИЙ", DISABLE_PUPPETS: "БЕЗ ВАССАЛОВ",
        INAUGURATE: "Начать конфликт", REBELLION: "Восстание", POLITICAL: "ПОЛИТИЧЕСКАЯ", ARROWS: "СТРЕЛКИ", BATTLE_VIS: "БОИ", GOD: "БОГ", DIPLOMACY: "ДИПЛОМАТИЯ", RESTART: "ПЕРЕЗАПУСК",
        UNITS: "ЮНИТЫ", VS_MINI: "против", EDITOR_TOOLS: "ИНСТРУМЕНТЫ", NEW_NATION: "Новая нация", TEST_SCENARIO: "Тест", UPDATE_SCENARIO: "Обновить", SAVE_PRESET: "Сохранить", LOAD_PRESET: "Загрузить", SHARE_HUB: "В Хаб", HUB_TAB: "Хаб", COUNTRY_LIB: "Библиотека стран", FLAG_LIB: "Флаги", SAVE_COUNTRY: "Сохр. страну", LOAD_COUNTRY: "Загр. страну", PAINT: "Кисть", FILL: "Заливка", UNCLAIM: "Стереть", EXIT_EDITOR: "Выход",
        NATIONS: { "Germany": "Германия", "German Reich": "Германский Рейх", "Poland": "Польша", "Russia": "Россия", "United States": "США", "France": "Франция", "United Kingdom": "Великобритания", "Italy": "Италия", "China": "Китай", "Japan": "Япония", "United States of America": "США", "Soviet Union": "СССР", "Turkey": "Турция", "Ukraine": "Украина", "Belarus": "Беларусь", "Kazakhstan": "Казахстан", "Brazil": "Бразилия", "Canada": "Канада", "Australia": "Австралия", "India": "Индия", "Spain": "Испания", "Mexico": "Мексика", "South Korea": "Южная Корея", "North Korea": "Северная Корея", "Vietnam": "Вьетнам" }
    },
    ja: {
        MODERN_WARS: "モダン・ウォーズ", LANGUAGE: "言語", LANGUAGE_SUB: "システム表示言語。",
        MAP_RES: "マップ解像度", RES_LOW: "低 (パフォーマンス)", RES_STD: "標準 (中)", RES_HIGH: "高 (非常に重い)", RES_SUB: "解像度が高いと境界線は綺麗になりますが、読み込みが遅くなります。",
        GRID_DENSITY: "グリッド密度", GRID_FAST: "低 (高速)", GRID_STD: "標準", GRID_SMOOTH: "高 (滑らか)", GRID_SUB: "密度は前線の滑らかさに影響します。",
        MAX_UNITS: "最大ユニット数", UNIT_MIN: "100 (最小限)", UNIT_STD: "250 (標準)", UNIT_WAR: "500 (大戦争)", UNIT_STRESS: "1000 (最大負荷)", UNIT_SUB: "ユニット数を減らすことで、パフォーマンスが向上します。",
        BG_VOLUME: "BGM 音量", BG_SUB: "背景音楽の音量を調整します。",
        DISABLE_MT: "山岳を無効にする", DISABLE_MT_SUB: "地形による移動ペナルティと視覚的な暗転を除去します。",
        DISABLE_PROV: "州を無効にする", DISABLE_PROV_SUB: "国境内部の州の境界線を除去します。",
        HIDE_UNITS: "ユニットを非表示にする", HIDE_UNITS_SUB: "アイコンと旗の描画を停止し、FPSを大幅に向上させます。",
        SAVE_SKIP: "設定を保存して次回からスキップ", APPLY_INIT: "適用して初期化",
        OPERATIONS: "軍事作戦", CONQUEST: "征服モード", CONQUEST_SUB: "世界大戦シミュレーション", EDITOR: "エディター", EDITOR_SUB: "ワールドビルダー",
        INTELLIGENCE: "インテリジェンス", HUB: "エディターハブ", HUB_SUB: "コミュニティコンテンツ", LOAD_FILE: "ファイルを読み込む", LOAD_FILE_SUB: "プリセットをインポート",
        SYSTEM: "システム", ENGINE: "エンジン設定", ENGINE_SUB: "画質とFPS", TUTORIAL: "チュートリアル", TUTORIAL_SUB: "基本操作を学ぶ",
        SERVER: "サーバー", SERVER_SUB: "Discordに参加", CREDITS: "クレジット", CREDITS_SUB: "貢献者", DONATE: "寄付", DONATE_SUB: "開発者を支援",
        PC_REQD: "動作環境: 高性能なPCを推奨します。モバイルや低スペック端末では遅延が発生する場合があります。",
        STABLE: "接続安定", LOADING: "読み込み中...", GOD_MODE: "ゴッドモード", GOD_ACTIVE: "ゴッドモード有効", SIM_PAUSED: "シミュレーション停止中",
        SELECT_P1: "最初の国を選択", SELECT_P2: "敵対国を選択", CONFLICT_SETUP: "紛争セットアップ",
        CHOOSE_ERA: "時代を選択", MODERN_DAY: "現代", MODERN_DAY_SUB: "現在の地政学 (リアルアース)", WW2_SCENARIO: "1936年シナリオ", WW2_SCENARIO_SUB: "第二次世界大戦の戦略戦域", BACK_TO_MENU: "メニューに戻る",
        RANDOM_WAR_OFF: "ランダム戦争: オフ", RANDOM_WAR_ON: "ランダム戦争: オン", ADD_SIDE: "+ 陣営追加", FFA: "無差別戦 (FFA)", SETUP_PROMPT: "陣営を選択し、マップ上の国をクリックして参加させてください。",
        STRATEGY: "攻撃戦略", STRAT_ALL: "全前線 (グローバル)", STRAT_FOCUS: "重点攻撃 (局地戦)", DENSITY: "兵力密度",
        FIGHT_TO_DEATH: "死闘モード (講和なし)", DISABLE_MISSILES: "長距離ミサイル無効", DISABLE_MT: "山岳無効", DISABLE_PROV: "州の境界無効", DISABLE_PUPPETS: "傀儡国無効",
        INAUGURATE: "紛争開始", REBELLION: "反乱開始", POLITICAL: "政治地図", ARROWS: "進撃矢印", BATTLE_VIS: "戦闘エフェクト", GOD: "神", DIPLOMACY: "外交", RESTART: "再起動",
        UNITS: "部隊", VS_MINI: "対", EDITOR_TOOLS: "エディターツール", NEW_NATION: "新国家作成", TEST_SCENARIO: "シナリオテスト", UPDATE_SCENARIO: "シナリオ更新", SAVE_PRESET: "プリセット保存", LOAD_PRESET: "プリセット読込", SHARE_HUB: "ハブに共有", HUB_TAB: "ハブ", COUNTRY_LIB: "国家ライブラリ", FLAG_LIB: "国旗ライブラリ", SAVE_COUNTRY: "国家保存", LOAD_COUNTRY: "国家読込", PAINT: "ペイント", FILL: "塗りつぶし", UNCLAIM: "領土解除", EXIT_EDITOR: "終了",
        NATIONS: { "Germany": "ドイツ", "German Reich": "ドイツ国", "Poland": "ポーランド", "Russia": "ロシア", "United States": "アメリカ", "France": "フランス", "United Kingdom": "イギリス", "Italy": "イタリア", "China": "中国", "Japan": "日本", "Soviet Union": "ソ連", "Turkey": "トルコ", "Ukraine": "ウクライナ", "South Korea": "韓国", "North Korea": "北朝鮮", "Brazil": "ブラジル", "Canada": "カナダ", "Australia": "オーストラリア", "India": "インド", "Spain": "スペイン", "Mexico": "メキシコ", "Vietnam": "ベトナム" }
    },
    es: {
        MODERN_WARS: "Guerras Modernas", LANGUAGE: "Idioma", LANGUAGE_SUB: "Idioma de visualización del sistema.",
        MAP_RES: "Resolución del Mapa", RES_LOW: "Baja (Rendimiento)", RES_STD: "Estándar (Media)", RES_HIGH: "Alta (Pesada)", RES_SUB: "Mayor resolución mejora bordes pero ralentiza carga.",
        GRID_DENSITY: "Densidad de Cuadrícula", GRID_FAST: "Baja (Rápida)", GRID_STD: "Estándar", GRID_SMOOTH: "Alta (Suave)", GRID_SUB: "La densidad afecta la suavidad de los frentes.",
        MAX_UNITS: "Unidades Máximas", UNIT_MIN: "100 (Mínimo)", UNIT_STD: "250 (Estándar)", UNIT_WAR: "500 (Guerra)", UNIT_STRESS: "1000 (Estrés Máximo)", UNIT_SUB: "Mejora el rendimiento con menos unidades.",
        BG_VOLUME: "Volumen Música", BG_SUB: "Ajusta el volumen de la música de fondo.",
        DISABLE_MT: "Desactivar Montañas", DISABLE_MT_SUB: "Elimina penalizaciones de terreno y oscurecimiento visual.",
        DISABLE_PROV: "Desactivar Provincias", DISABLE_PROV_SUB: "Elimina subdivisiones internas de los países.",
        HIDE_UNITS: "Ocultar Unidades", HIDE_UNITS_SUB: "Desactiva iconos de unidades para ganar FPS.",
        SAVE_SKIP: "Recordar y Omitir al Inicio", APPLY_INIT: "Aplicar e Inicializar",
        OPERATIONS: "Operaciones", CONQUEST: "CONQUISTA", CONQUEST_SUB: "Guerra Global", EDITOR: "EDITOR", EDITOR_SUB: "Constructor",
        INTELLIGENCE: "Inteligencia", HUB: "CENTRO EDITOR", HUB_SUB: "Contenido Comunitario", LOAD_FILE: "CARGAR ARCHIVO", LOAD_FILE_SUB: "Importar Escenario",
        SYSTEM: "Sistema", ENGINE: "MOTOR", ENGINE_SUB: "Fidelidad y FPS", TUTORIAL: "TUTORIAL", TUTORIAL_SUB: "Aprende las Reglas",
        SERVER: "SERVIDOR", SERVER_SUB: "Unirse a Discord", CREDITS: "CRÉDITOS", CREDITS_SUB: "Colaboradores", DONATE: "DONAR", DONATE_SUB: "Apoya al dev",
        PC_REQD: "Requisito: Se recomienda PC de alto rendimiento. Hardware de gama baja puede sufrir lag.",
        STABLE: "CONEXIÓN ESTABLE", LOADING: "Cargando...", GOD_MODE: "MODO DIOS", GOD_ACTIVE: "DIOS ACTIVO",
        SELECT_P1: "Seleccionar primer país", SELECT_P2: "Seleccionar enemigo", CONFLICT_SETUP: "Configuración del conflicto",
        RANDOM_WAR_OFF: "Guerra aleat: OFF", RANDOM_WAR_ON: "Guerra aleat: ON", ADD_SIDE: "+ Lado", FFA: "FFA", SETUP_PROMPT: "Selecciona un bando, luego haz clic en los países del mapa.",
        STRATEGY: "Estrategia de ataque", STRAT_ALL: "Todos los frentes", STRAT_FOCUS: "Ataque focalizado", DENSITY: "Densidad de fuerza",
        FIGHT_TO_DEATH: "LUCHA HASTA LA MUERTE (SIN PAZ)", DISABLE_MISSILES: "DESACTIVAR MISILES", DISABLE_MT: "DESACTIVAR MONTAÑAS", DISABLE_PROV: "DESACTIVAR PROVINCIAS", DISABLE_PUPPETS: "DESACTIVAR PUPPETS",
        INAUGURATE: "Inaugurar Conflicto", REBELLION: "Iniciar Rebelión", POLITICAL: "POLÍTICO", ARROWS: "FLECHAS", BATTLE_VIS: "VISUALES DE BATALLA", GOD: "DIOS", DIPLOMACY: "DIPLOMACIA", RESTART: "REINICIAR",
        UNITS: "UNIDADES", VS_MINI: "vs", EDITOR_TOOLS: "HERRAMIENTAS", NEW_NATION: "Nueva Nación", TEST_SCENARIO: "Probar Escenario", UPDATE_SCENARIO: "Actualizar", SAVE_PRESET: "Guardar Preset", LOAD_PRESET: "Cargar Preset", SHARE_HUB: "Compartir", HUB_TAB: "Hub", COUNTRY_LIB: "Biblioteca de Países", FLAG_LIB: "Biblioteca de Banderas", SAVE_COUNTRY: "Guardar País", LOAD_COUNTRY: "Cargar País", PAINT: "Pintar", FILL: "Llenar", UNCLAIM: "Desreclamar", EXIT_EDITOR: "Salir",
        NATIONS: { "Germany": "Alemania", "German Reich": "Reich Alemán", "Poland": "Polonia", "Russia": "Rusia", "United States": "Estados Unidos", "France": "Francia", "United Kingdom": "Reino Unido", "Italy": "Italia", "China": "China", "Japan": "Japón", "Soviet Union": "Unión Soviética", "Turkey": "Turquía", "Ukraine": "Ucrania", "Brazil": "Brasil", "Canada": "Canadá", "Australia": "Australia", "India": "India", "Spain": "España", "Mexico": "México", "South Korea": "Corea del Sur", "North Korea": "Corea del Norte", "Vietnam": "Vietnam" }
    },
    fr: {
        MODERN_WARS: "Guerres Modernes", LANGUAGE: "Langue", LANGUAGE_SUB: "Langue d'affichage du système.",
        MAP_RES: "Résolution Carte", RES_LOW: "Basse (Performance)", RES_STD: "Standard (Moyenne)", RES_HIGH: "Haute (Lourde)", RES_SUB: "Améliore les bordures mais ralentit le chargement.",
        GRID_DENSITY: "Densité Grille", GRID_FAST: "Basse (Rapide)", GRID_STD: "Standard", GRID_SMOOTH: "Haute (Lisse)", GRID_SUB: "La densité affecte la fluidité du front.",
        MAX_UNITS: "Unités Max", UNIT_MIN: "100 (Mini)", UNIT_STD: "250 (Standard)", UNIT_WAR: "500 (Guerre)", UNIT_STRESS: "1000 (Stress Max)", UNIT_SUB: "Réduit les unités pour booster les FPS.",
        BG_VOLUME: "Volume Musique", BG_SUB: "Ajuste le volume de fond.",
        DISABLE_MT: "Désactiver Montagnes", DISABLE_MT_SUB: "Supprime les malus de mouvement.",
        DISABLE_PROV: "Désactiver Provinces", DISABLE_PROV_SUB: "Supprime les subdivisions internes.",
        HIDE_UNITS: "Cacher Unités", HIDE_UNITS_SUB: "Désactive les icônes pour plus de FPS.",
        SAVE_SKIP: "Retenir et ignorer au démarrage", APPLY_INIT: "Appliquer et Lancer",
        OPERATIONS: "Opérations", CONQUEST: "CONQUÊTE", CONQUEST_SUB: "Guerre Globale", EDITOR: "ÉDITEUR", EDITOR_SUB: "Créateur de Monde",
        INTELLIGENCE: "Renseignement", HUB: "HUB ÉDITEUR", HUB_SUB: "Contenu Communautaire", LOAD_FILE: "CHARGER FICHIER", LOAD_FILE_SUB: "Importer Scénario",
        SYSTEM: "Système", ENGINE: "MOTEUR", ENGINE_SUB: "Fidélité & FPS", TUTORIAL: "TUTORIEL", TUTORIAL_SUB: "Apprendre les bases",
        SERVER: "SERVEUR", SERVER_SUB: "Rejoindre Discord", CREDITS: "CRÉDITS", CREDITS_SUB: "Contributeurs", DONATE: "DON", DONATE_SUB: "Soutenir le dev",
        PC_REQD: "Requis : PC puissant recommandé. Lag possible sur mobile.",
        STABLE: "CONNEXION STABLE", LOADING: "Chargement...", GOD_MODE: "MODE DIEU", GOD_ACTIVE: "DIEU ACTIF",
        SELECT_P1: "Choisir le premier pays", SELECT_P2: "Choisir l'ennemi", CONFLICT_SETUP: "Configuration du conflit",
        RANDOM_WAR_OFF: "Guerre aléat: OFF", RANDOM_WAR_ON: "Guerre aléat: ON", ADD_SIDE: "+ Camp", FFA: "FFA", SETUP_PROMPT: "Choisissez un camp, puis cliquez sur les pays.",
        STRATEGY: "Stratégie d'attaque", STRAT_ALL: "Tous les fronts", STRAT_FOCUS: "Frappe ciblée", DENSITY: "Densité de force",
        FIGHT_TO_DEATH: "GUERRE À MORT (PAS DE PAIX)", DISABLE_MISSILES: "DÉSACTIVER MISSILES",
        INAUGURATE: "Inaugurer le Conflit", REBELLION: "Lancer Rébellion", POLITICAL: "POLITIQUE", ARROWS: "FLÈCHES", BATTLE_VIS: "VISUELS COMBAT", GOD: "DIEU", DIPLOMACY: "DIPLOMATIE", RESTART: "REDÉMARRER",
        UNITS: "UNITÉS", VS_MINI: "vs", EDITOR_TOOLS: "OUTILS", NEW_NATION: "Nouvelle Nation", TEST_SCENARIO: "Tester", UPDATE_SCENARIO: "Mettre à jour", SAVE_PRESET: "Sauvegarder", LOAD_PRESET: "Charger", SHARE_HUB: "Partager", HUB_TAB: "Hub", COUNTRY_LIB: "Bibliothèque Pays", FLAG_LIB: "Drapeaux", SAVE_COUNTRY: "Sauver Pays", LOAD_COUNTRY: "Charger Pays", PAINT: "Peindre", FILL: "Remplir", UNCLAIM: "Libérer", EXIT_EDITOR: "Quitter",
        NATIONS: { "Germany": "Allemagne", "German Reich": "Reich Allemand", "Poland": "Pologne", "Russia": "Russie", "United States": "États-Unis", "France": "France", "United Kingdom": "Royaume-Uni", "Italy": "Italie", "China": "Chine", "Japan": "Japon", "Soviet Union": "Union Soviétique", "Turkey": "Turquie", "Ukraine": "Ukraine", "Brazil": "Brésil", "Canada": "Canada", "Australia": "Australie", "India": "Inde", "Spain": "Espagne", "Mexico": "Mexique", "South Korea": "Corée du Sud", "North Korea": "Corée du Nord", "Vietnam": "Vietnam" }
    },
    de: {
        MODERN_WARS: "Moderne Kriege", LANGUAGE: "Sprache", LANGUAGE_SUB: "System-Sprache.",
        MAP_RES: "Kartenauflösung", RES_LOW: "Niedrig (Leistung)", RES_STD: "Standard (Mittel)", RES_HIGH: "Hoch (Schwer)", RES_SUB: "Verbessert Grenzen, verzögert Laden.",
        GRID_DENSITY: "Gitterdichte", GRID_FAST: "Niedrig (Schnell)", GRID_STD: "Standard", GRID_SMOOTH: "Hoch (Glatt)", GRID_SUB: "Beeinflusst Frontverlauf.",
        MAX_UNITS: "Einheitenlimit", UNIT_MIN: "100 (Min)", UNIT_STD: "250 (Standard)", UNIT_WAR: "500 (Krieg)", UNIT_STRESS: "1000 (Stress)", UNIT_SUB: "Wenig Einheiten für hohe FPS.",
        BG_VOLUME: "Musiklautstärke", BG_SUB: "Hintergrundmusik anpassen.",
        DISABLE_MT: "Berge deaktivieren", DISABLE_MT_SUB: "Entfernt Geländestrafen.",
        DISABLE_PROV: "Provinzen aus", DISABLE_PROV_SUB: "Entfernt interne Grenzen.",
        HIDE_UNITS: "Einheiten verbergen", HIDE_UNITS_SUB: "Deaktiviert Icons für FPS-Boost.",
        SAVE_SKIP: "Einstellungen speichern & überspringen", APPLY_INIT: "Anwenden & Starten",
        OPERATIONS: "Operationen", CONQUEST: "EROBERUNG", CONQUEST_SUB: "Globaler Krieg", EDITOR: "EDITOR", EDITOR_SUB: "Weltenbauer",
        INTELLIGENCE: "Geheimdienst", HUB: "EDITOR HUB", HUB_SUB: "Community-Inhalte", LOAD_FILE: "DATEI LADEN", LOAD_FILE_SUB: "Preset importieren",
        SYSTEM: "System", ENGINE: "ENGINE", ENGINE_SUB: "Fidelität & FPS", TUTORIAL: "TUTORIAL", TUTORIAL_SUB: "Grundlagen lernen",
        SERVER: "SERVER", SERVER_SUB: "Discord beitreten", CREDITS: "CREDITS", CREDITS_SUB: "Mitwirkende", DONATE: "SPENDEN", DONATE_SUB: "Unterstütze den Dev",
        PC_REQD: "Anforderung: Leistungsstarker PC empfohlen. Lag auf Mobilgeräten möglich.",
        STABLE: "VERBINDUNG STABIL", LOADING: "Laden...", GOD_MODE: "GOTT-MODUS", GOD_ACTIVE: "GOTT AKTIV",
        SELECT_P1: "Erstes Land wählen", SELECT_P2: "Feind wählen", CONFLICT_SETUP: "Konflikt-Setup",
        RANDOM_WAR_OFF: "Zufallskrieg: AUS", RANDOM_WAR_ON: "Zufallskrieg: AN", ADD_SIDE: "+ Seite", FFA: "FFA", SETUP_PROMPT: "Seite wählen, dann Länder auf Karte anklicken.",
        STRATEGY: "Strategie", STRAT_ALL: "Alle Fronten", STRAT_FOCUS: "Gezielter Schlag", DENSITY: "Truppendichte",
        FIGHT_TO_DEATH: "KAMPF BIS ZUM TOD (KEIN FRIEDEN)", DISABLE_MISSILES: "RAKETEN DEAKTIVIEREN",
        INAUGURATE: "Konflikt eröffnen", REBELLION: "Rebellion starten", POLITICAL: "POLITISCH", ARROWS: "PFEILE", BATTLE_VIS: "KAMPFEFFEKTE", GOD: "GOTT", DIPLOMACY: "DIPLOMATIE", RESTART: "NEUSTART",
        UNITS: "EINHEITEN", VS_MINI: "vs", EDITOR_TOOLS: "TOOLS", NEW_NATION: "Neue Nation", TEST_SCENARIO: "Testen", UPDATE_SCENARIO: "Update", SAVE_PRESET: "Speichern", LOAD_PRESET: "Laden", SHARE_HUB: "Teilen", HUB_TAB: "Hub", COUNTRY_LIB: "Länderbibliothek", FLAG_LIB: "Flaggen", SAVE_COUNTRY: "Land speichern", LOAD_COUNTRY: "Land laden", PAINT: "Malen", FILL: "Füllen", UNCLAIM: "Freigeben", EXIT_EDITOR: "Beenden",
        NATIONS: { "Germany": "Deutschland", "German Reich": "Deutsches Reich", "Poland": "Polen", "Russia": "Russland", "United States": "USA", "France": "Frankreich", "United Kingdom": "Großbritannien", "Italy": "Italien", "China": "China", "Japan": "Japan", "Soviet Union": "Sowjetunion", "Turkey": "Türkei", "Ukraine": "Ukraine", "Brazil": "Brasilien", "Canada": "Kanada", "Australia": "Australien", "India": "Indien", "Spain": "Spanien", "Mexico": "Mexiko", "South Korea": "Südkorea", "North Korea": "Nordkorea", "Vietnam": "Vietnam" }
    },
    pt: {
        MODERN_WARS: "Guerras Modernas", LANGUAGE: "Idioma", LANGUAGE_SUB: "Idioma de exibição do sistema.",
        MAP_RES: "Resolução do Mapa", RES_LOW: "Baixa (Performance)", RES_STD: "Padrão (Média)", RES_HIGH: "Alta (Pesada)", RES_SUB: "Melhora bordas, mas retarda o carregamento.",
        GRID_DENSITY: "Densidade da Grade", GRID_FAST: "Baixa (Rápida)", GRID_STD: "Padrão", GRID_SMOOTH: "Alta (Suave)", GRID_SUB: "Afeta a suavidade das linhas de frente.",
        MAX_UNITS: "Limite de Unidades", UNIT_MIN: "100 (Mínimo)", UNIT_STD: "250 (Padrão)", UNIT_WAR: "500 (Guerra)", UNIT_STRESS: "1000 (Stress)", UNIT_SUB: "Reduz unidades para melhor FPS.",
        BG_VOLUME: "Volume da Música", BG_SUB: "Ajusta o volume da música.",
        DISABLE_MT: "Desativar Montanhas", DISABLE_MT_SUB: "Remove penalidades de movimento.",
        DISABLE_PROV: "Desativar Províncias", DISABLE_PROV_SUB: "Remove divisões internas.",
        HIDE_UNITS: "Ocultar Unidades", HIDE_UNITS_SUB: "Desativa ícones para ganho de FPS.",
        SAVE_SKIP: "Salvar e Ignorar no Início", APPLY_INIT: "Aplicar e Iniciar",
        OPERATIONS: "Operações", CONQUEST: "CONQUISTA", CONQUEST_SUB: "Guerra Global", EDITOR: "EDITOR", EDITOR_SUB: "Construtor de Mundo",
        INTELLIGENCE: "Inteligência", HUB: "HUB DO EDITOR", HUB_SUB: "Conteúdo da Comunidade", LOAD_FILE: "CARREGAR ARQUIVO", LOAD_FILE_SUB: "Importar Preset",
        SYSTEM: "Sistema", ENGINE: "MOTOR", ENGINE_SUB: "Fidelidade e FPS", TUTORIAL: "TUTORIAL", TUTORIAL_SUB: "Aprenda o básico",
        SERVER: "SERVIDOR", SERVER_SUB: "Entrar no Discord", CREDITS: "CRÉDITOS", CREDITS_SUB: "Contribuidores", DONATE: "DOAR", DONATE_SUB: "Apoie o dev",
        PC_REQD: "Requisito: Recomenda-se PC potente. Possível lag em mobile.",
        STABLE: "CONEXÃO ESTÁVEL", LOADING: "Carregando...", GOD_MODE: "MODO DEUS", GOD_ACTIVE: "DEUS ATIVO",
        SELECT_P1: "Escolha o primeiro país", SELECT_P2: "Escolha o inimigo", CONFLICT_SETUP: "Configuração do Conflito",
        RANDOM_WAR_OFF: "Guerra Aleat: OFF", RANDOM_WAR_ON: "Guerra Aleat: ON", ADD_SIDE: "+ Lado", FFA: "FFA", SETUP_PROMPT: "Escolha um lado e clique nos países do mapa.",
        STRATEGY: "Estratégia de Ataque", STRAT_ALL: "Todas as frentes", STRAT_FOCUS: "Ataque focado", DENSITY: "Densidade de Força",
        FIGHT_TO_DEATH: "LUTA ATÉ A MORTE (SEM PAZ)", DISABLE_MISSILES: "DESATIVAR MÍSSEIS",
        INAUGURATE: "Inaugurar Conflito", REBELLION: "Iniciar Rebelião", POLITICAL: "POLÍTICO", ARROWS: "SETAS", BATTLE_VIS: "VISUAIS DE BATALHA", GOD: "DEUS", DIPLOMACY: "DIPLOMACIA", RESTART: "REINICIAR",
        UNITS: "UNIDADES", VS_MINI: "vs", EDITOR_TOOLS: "FERRAMENTAS", NEW_NATION: "Nova Nação", TEST_SCENARIO: "Testar", UPDATE_SCENARIO: "Atualizar", SAVE_PRESET: "Salvar Preset", LOAD_PRESET: "Carregar Preset", SHARE_HUB: "Compartilhar", HUB_TAB: "Hub", COUNTRY_LIB: "Biblioteca", FLAG_LIB: "Bandeiras", SAVE_COUNTRY: "Salvar País", LOAD_COUNTRY: "Carregar País", PAINT: "Pintar", FILL: "Preencher", UNCLAIM: "Desreclamar", EXIT_EDITOR: "Sair",
        NATIONS: { "Germany": "Alemanha", "German Reich": "Reich Alemão", "Poland": "Polônia", "Russia": "Rússia", "United States": "EUA", "France": "França", "United Kingdom": "Reino Unido", "Italy": "Itália", "China": "China", "Japan": "Japão", "Soviet Union": "União Soviética", "Turkey": "Turquia", "Ukraine": "Ucrânia", "Brazil": "Brasil", "Canada": "Canadá", "Australia": "Austrália", "India": "Índia", "Spain": "Espanha", "Mexico": "México", "South Korea": "Coreia do Sul", "North Korea": "Coreia do Norte", "Vietnam": "Vietnã" }
    },
    it: {
        MODERN_WARS: "Guerre Moderne", LANGUAGE: "Lingua", LANGUAGE_SUB: "Lingua di sistema.",
        MAP_RES: "Risoluzione Mappa", RES_LOW: "Bassa", RES_STD: "Standard", RES_HIGH: "Alta",
        OPERATIONS: "Operazioni", CONQUEST: "CONQUISTA", EDITOR: "EDITOR", NATIONS: { "Germany": "Germania", "Poland": "Polonia", "Russia": "Russia", "United States": "Stati Uniti", "France": "Francia", "Italy": "Italia" }
    },
    pl: {
        MODERN_WARS: "Wojny Współczesne", LANGUAGE: "Język", LANGUAGE_SUB: "Język systemu.",
        OPERATIONS: "Operacje", CONQUEST: "PODBÓJ", EDITOR: "EDYTOR", NATIONS: { "Germany": "Niemcy", "German Reich": "III Rzesza", "Poland": "Polska", "Russia": "Rosja", "United States": "USA", "France": "Francja" }
    },
    zh: {
        MODERN_WARS: "现代战争", LANGUAGE: "语言", LANGUAGE_SUB: "系统显示语言。",
        OPERATIONS: "军事行动", CONQUEST: "征服模式", EDITOR: "编辑器", NATIONS: { "Germany": "德国", "Poland": "波兰", "Russia": "俄罗斯", "United States": "美国", "France": "法国", "China": "中国", "Japan": "日本" }
    },
    uk: {
        MODERN_WARS: "Сучасні Війни", LANGUAGE: "Мова", LANGUAGE_SUB: "Мова системи.",
        OPERATIONS: "Операції", CONQUEST: "ЗАВОЮВАННЯ", EDITOR: "РЕДАКТОР", NATIONS: { "Germany": "Німеччина", "Poland": "Польща", "Russia": "Росія", "Ukraine": "Україна", "United States": "США" }
    },
    hi: {
        MODERN_WARS: "आधुनिक युद्ध", LANGUAGE: "भाषा", LANGUAGE_SUB: "सिस्टम की भाषा।",
        OPERATIONS: "संचालन", CONQUEST: "विजय", EDITOR: "संपादक", NATIONS: { "Germany": "जर्मनी", "Poland": "पोलैंड", "Russia": "रूस", "United States": "अमेरिका", "India": "भारत" }
    },
    ar: {
        MODERN_WARS: "الحروب الحديثة", LANGUAGE: "اللغة", LANGUAGE_SUB: "لغة عرض النظام.",
        OPERATIONS: "العمليات", CONQUEST: "غزو", EDITOR: "المحرر", NATIONS: { "Germany": "ألمانيا", "Poland": "بولندا", "Russia": "روسيا", "United States": "الولايات المتحدة", "Egypt": "مصر", "Saudi Arabia": "السعودية" }
    }
};

function applyLanguage(lang) {
    if (!lang) lang = getCookie('mw_lang') || 'zh';
    const dict = TRANSLATIONS[lang] || TRANSLATIONS.en;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (dict[key]) {
            el.innerText = dict[key];
        }
    });
    
    // Update dynamic status messages if they are currently set to default strings
    if (statusText) {
        const currentText = statusText.innerText;
        
        // Handle complex status strings like "REMIXING: World"
        if (currentText.includes(': ')) {
            const parts = currentText.split(': ');
            const prefixKey = parts[0] === 'REMIXING' ? 'REMIXING' : (parts[0] === 'PLAYING' ? 'PLAYING' : null);
            if (prefixKey && dict[prefixKey]) {
                statusText.innerText = `${dict[prefixKey]}: ${parts[1]}`;
            }
        } else {
            for (const [key, val] of Object.entries(TRANSLATIONS.en)) {
                if (currentText === val && dict[key]) {
                    statusText.innerText = dict[key];
                    break;
                }
            }
        }
    }

    const select = document.getElementById('language-select');
    if (select) select.value = lang;
    setCookie('mw_lang', lang);
    
    // Re-translate country metadata
    if (countryMetadata) {
        countryMetadata.forEach(m => {
            if (m && m.name) {
                const trans = getTranslation(m.name, lang, 'NATIONS');
                if (trans !== m.name) m.displayName = trans;
                else m.displayName = m.name;
            }
        });
    }
    
    // Re-translate current simulation side UI
    updateSidesUI();
}

function getTranslation(key, lang = getCookie('mw_lang') || 'en', subDict = null) {
    const dict = TRANSLATIONS[lang] || TRANSLATIONS.en;
    if (subDict && dict[subDict]) {
        return dict[subDict][key] || key;
    }
    return dict[key] || key;
}

document.getElementById('language-select')?.addEventListener('change', (e) => {
    applyLanguage(e.target.value);
});

/**
 * HELPERS
 */
function setCookie(name, value, days = 365) {
    const expires = new Date(Date.now() + days * 864e5).toUTCString();
    document.cookie = name + '=' + encodeURIComponent(value) + '; expires=' + expires + '; path=/';
}

function getCookie(name) {
    return document.cookie.split('; ').reduce((r, v) => {
        const parts = v.split('=');
        return parts[0] === name ? decodeURIComponent(parts[1]) : r;
    }, '');
}

function parseColorToRGBA(c) {
    if (!c) return [150, 150, 150, 1.0];
    const canvas = document.createElement('canvas');
    canvas.width = 1;
    canvas.height = 1;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = c;
    ctx.fillRect(0, 0, 1, 1);
    const data = ctx.getImageData(0, 0, 1, 1).data;
    // data is [R, G, B, A] where A is 0-255
    return [data[0], data[1], data[2], data[3] / 255];
}

/**
 * Updates a country's flag across all data structures and UI components.
 */
function updateCountryFlag(countryId, url) {
    if (countryId <= 0 || !url) return;
    
    const meta = countryMetadata.find(m => m && m.id === countryId);
    if (meta) {
        meta.flagUrl = url;
        // Re-initialize image object to ensure the source change is picked up by the renderer
        meta.tempFlag = new Image();
        meta.tempFlag.crossOrigin = "anonymous";
        meta.tempFlag.onload = () => influenceLayer.render();
        meta.tempFlag.src = url;
    }

    // Propagate to live simulation/setup objects (units use these references)
    sides.flat().forEach(c => {
        if (c && c.id === countryId) {
            c.flag = new Image();
            c.flag.crossOrigin = "anonymous";
            c.flag.onload = () => influenceLayer.render();
            c.flag.src = url;
        }
    });

    // Update Inspector UI if currently viewing this country
    if (editingCountryId === countryId && countryInspector.style.display !== 'none') {
        inspectFlagPreview.src = url;
        inspectFlagPreview.style.display = 'block';
    }

    updateSidesUI();
    influenceLayer.render();
}

function getFlagUrl(code, name) {
    if (!code || code === "-99") {
        code = findCodeByName(name);
    }
    if (!code || code === "-99") return null;
    return `https://flagcdn.com/w320/${code.toLowerCase()}.png`;
}

/**
 * Ensure we have a drawable flag image object for a country metadata entry.
 * This prefers any existing tempFlag, otherwise tries to load from flagUrl.
 */
function ensureFlagImage(meta) {
    return new Promise((resolve) => {
        if (!meta) return resolve(null);

        // If we already have a canvas or image ready, use it
        if (meta.tempFlag && (meta.tempFlag.complete === undefined || meta.tempFlag.complete)) {
            return resolve(meta.tempFlag);
        }

        if (!meta.flagUrl) return resolve(null);

        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
            meta.tempFlag = img;
            resolve(img);
        };
        img.onerror = () => resolve(null);
        img.src = meta.flagUrl;
    });
}

/**
 * Generate a dynamic puppet flag: left half = puppet, right half = overlord.
 * This is only used for vassalages created after the game has started.
 */
async function generatePuppetFlag(puppetId, overlordId) {
    if (!puppetId || !overlordId) return;
    const puppetMeta = countryMetadata.find(m => m && m.id === puppetId);
    const overlordMeta = countryMetadata.find(m => m && m.id === overlordId);
    if (!puppetMeta || !overlordMeta) return;

    const puppetImg = await ensureFlagImage(puppetMeta);
    const overlordImg = await ensureFlagImage(overlordMeta);
    if (!puppetImg || !overlordImg) return;

    // Create composite canvas
    const width = 160;
    const height = 100;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    // Base background
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, width, height);

    // Draw puppet flag covering the whole flag area
    ctx.drawImage(
        puppetImg,
        0, 0, puppetImg.naturalWidth || puppetImg.width, puppetImg.naturalHeight || puppetImg.height,
        0, 0, width, height
    );

    // Draw overlord flag as a canton in the top‑left corner
    const cantonWidth = Math.floor(width * 0.35);
    const cantonHeight = Math.floor(height * 0.45);

    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, cantonWidth, cantonHeight);
    ctx.clip();

    ctx.drawImage(
        overlordImg,
        0, 0, overlordImg.naturalWidth || overlordImg.width, overlordImg.naturalHeight || overlordImg.height,
        0, 0, cantonWidth, cantonHeight
    );
    ctx.restore();

    // Border around the canton
    ctx.strokeStyle = "rgba(0,0,0,0.85)";
    ctx.lineWidth = 2;
    ctx.strokeRect(0.5, 0.5, cantonWidth - 1, cantonHeight - 1);

    // Slight border around whole flag
    ctx.strokeStyle = "rgba(0,0,0,0.7)";
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, width, height);

    // Use the canvas as the in‑memory flag immediately so units render correctly
    puppetMeta.tempFlag = canvas;
    sides.flat().forEach(c => {
        if (c && c.id === puppetId) {
            c.flag = canvas;
        }
    });

    // Export as a data:image URL so all UI elements can use it without uploading
    try {
        const dataUrl = canvas.toDataURL('image/png');
        updateCountryFlag(puppetId, dataUrl);
    } catch (e) {
        console.warn('Failed to generate data URL for puppet flag', e);
    }

    // Force a re-render so the new flag is visible on map and in UI
    if (influenceLayer) influenceLayer.render();
}

const explosionUrl = 'explosion-pas-61639.mp3';
const clickUrl = 'low-button-click-331780.mp3';

// Background music playlist: Bearmen Theme + Forward! + Glory to Rome
const bgMusicUrls = [
    'Age of Conflict Soundtrack- Bearmen Theme - Tyler Cunningham Music (youtube).mp3',
    'Age of Conflict Soundtrack- Forward! (1).mp3',
    'Roman Battle Music - Glory to Rome.mp3'
];

const warStartUrl = 'war.wav';
const peaceUrl = 'peace.wav';
const warAmbianceUrl = 'modern-war-129016.mp3';

// Initialize Audio Context immediately so it's ready for early decoding
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
let explosionBuffer = null;
let clickBuffer = null;
// Background music buffers keyed by URL
let bgMusicBuffers = {};
let isAudioLoading = false;
let warStartBuffer = null;
let peaceBuffer = null;
let warAmbianceBuffer = null;
let bgMusicSource = null;
let bgMusicGain = null;
// Track index currently playing from bgMusicUrls
let currentBgTrackIndex = null;
let customTrackUrl = getCookie('mw_custom_track') || null;
let warAmbianceSource = null;
let warAmbianceGain = null;

/**
 * High-priority loader for small UI elements.
 * This runs as soon as the script executes to minimize interaction latency.
 */
const loadImmediate = async (url) => {
    try {
        const response = await fetch(url);
        const arrayBuffer = await response.arrayBuffer();
        return await audioCtx.decodeAudioData(arrayBuffer);
    } catch (e) {
        console.warn(`Audio Error (Immediate): Failed to load ${url}`, e);
        return null;
    }
};

// Start loading the click sound instantly
loadImmediate(clickUrl).then(buffer => {
    if (buffer) clickBuffer = buffer;
});

async function initAudio() {
    // Resume context if suspended (common browser policy on first click)
    if (audioCtx.state === 'suspended') {
        try { await audioCtx.resume(); } catch(e) {}
    }
    
    if (isAudioLoading) return;
    
    const needsMusic = !bgMusicSource;
    const needsBuffers = !explosionBuffer || !clickBuffer || !warStartBuffer || !peaceBuffer || !warAmbianceBuffer;

    if (!needsMusic && !needsBuffers) return;

    isAudioLoading = true;

    const load = async (url) => {
        try {
            const response = await fetch(url);
            const arrayBuffer = await response.arrayBuffer();
            return await audioCtx.decodeAudioData(arrayBuffer);
        } catch (e) {
            console.warn(`Audio Error: Failed to load ${url}`, e);
            return null;
        }
    };

    // Helper to start playing a specific background track index
    const playBackgroundTrack = async (index) => {
        let url;
        if (customTrackUrl) {
            url = customTrackUrl;
        } else {
            if (index == null || index < 0 || index >= bgMusicUrls.length) return;
            url = bgMusicUrls[index];
        }

        // Decode buffer if needed
        if (!bgMusicBuffers[url]) {
            const buf = await load(url);
            if (!buf) return;
            bgMusicBuffers[url] = buf;
        }

        // Double-check overlap: ensure only one track starts playing even with rapid async calls
        if (bgMusicSource && currentBgTrackIndex === index && audioCtx.state !== 'suspended') return;

        // Stop any existing source
        if (bgMusicSource) {
            try { 
                bgMusicSource.onended = null; 
                bgMusicSource.stop(); 
                bgMusicSource.disconnect();
            } catch(e) {}
            bgMusicSource = null;
        }

        bgMusicSource = audioCtx.createBufferSource();
        bgMusicSource.buffer = bgMusicBuffers[url];
        bgMusicSource.loop = false;

        if (!bgMusicGain) {
            bgMusicGain = audioCtx.createGain();
            const savedVol = getCookie('mw_music_vol');
            const initialVol = savedVol !== '' ? parseFloat(savedVol) : 0.15;
            bgMusicGain.gain.value = initialVol;

            const slider = document.getElementById('music-volume-slider');
            const valLabel = document.getElementById('music-vol-val');
            if (slider && valLabel) {
                slider.value = initialVol;
                valLabel.innerText = Math.round(initialVol * 100) + '%';
            }

            bgMusicGain.connect(audioCtx.destination);
        }

        bgMusicSource.connect(bgMusicGain);
        bgMusicSource.start(0);

        currentBgTrackIndex = index;

        // When track ends, pick a different random one
        bgMusicSource.onended = () => {
            bgMusicSource = null;
            if (customTrackUrl) {
                playBackgroundTrack(0); // Loop custom track
                return;
            }
            if (!bgMusicUrls.length) return;
            let next = Math.floor(Math.random() * bgMusicUrls.length);
            if (bgMusicUrls.length > 1 && next === currentBgTrackIndex) {
                next = (next + 1) % bgMusicUrls.length;
            }
            playBackgroundTrack(next);
        };
    };

    // Prioritize loading and playing background music immediately
    const startMusic = async () => {
        if (bgMusicSource || isAudioLoading) return;
        // Pick a random starting track
        const startIndex = Math.floor(Math.random() * bgMusicUrls.length);
        await playBackgroundTrack(startIndex);
    };

    // Fire off music load/play and other sounds in parallel
    const effectTasks = [
        load(explosionUrl).then(b => explosionBuffer = b || explosionBuffer),
        (!clickBuffer ? load(clickUrl).then(b => clickBuffer = b || clickBuffer) : Promise.resolve()),
        load(warStartUrl).then(b => warStartBuffer = b || warStartBuffer),
        load(peaceUrl).then(b => peaceBuffer = b || peaceBuffer),
        load(warAmbianceUrl).then(b => warAmbianceBuffer = b || warAmbianceBuffer)
    ];

    await Promise.all([startMusic(), ...effectTasks]);
    isAudioLoading = false;
}

function playWarAmbiance() {
    if (!audioCtx || !warAmbianceBuffer || warAmbianceSource) return;
    
    warAmbianceSource = audioCtx.createBufferSource();
    warAmbianceSource.buffer = warAmbianceBuffer;
    warAmbianceSource.loop = true;
    
    warAmbianceGain = audioCtx.createGain();
    // Play "really quietly" as requested
    warAmbianceGain.gain.setValueAtTime(0, audioCtx.currentTime);
    warAmbianceGain.gain.linearRampToValueAtTime(0.05, audioCtx.currentTime + 2);
    
    warAmbianceSource.connect(warAmbianceGain);
    warAmbianceGain.connect(audioCtx.destination);
    warAmbianceSource.start(0);
}

function stopWarAmbiance() {
    if (warAmbianceSource) {
        const sourceToStop = warAmbianceSource;
        const gainToStop = warAmbianceGain;
        
        if (gainToStop) {
            gainToStop.gain.linearRampToValueAtTime(0, audioCtx.currentTime + 1.5);
        }
        
        setTimeout(() => {
            try {
                sourceToStop.stop();
            } catch (e) {}
        }, 1600);
        
        warAmbianceSource = null;
        warAmbianceGain = null;
    }
}

function playExplosionSound() {
    if (isMuted || !audioCtx || !explosionBuffer) return;
    const source = audioCtx.createBufferSource();
    source.buffer = explosionBuffer;
    
    // Create a filter but make it less aggressive (higher cutoff)
    const filterNode = audioCtx.createBiquadFilter();
    filterNode.type = 'lowpass';
    filterNode.frequency.setValueAtTime(1800, audioCtx.currentTime); 
    filterNode.Q.setValueAtTime(1, audioCtx.currentTime);

    const gainNode = audioCtx.createGain();
    const startVol = 0.45; // Significantly increased volume for clarity
    gainNode.gain.setValueAtTime(startVol, audioCtx.currentTime);
    // Linear ramp is often more predictable for short samples
    gainNode.gain.linearRampToValueAtTime(0, audioCtx.currentTime + explosionBuffer.duration);
    
    source.connect(filterNode);
    filterNode.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    source.start(0);
}

function playClickSound() {
    if (isMuted || !audioCtx || !clickBuffer) return;
    const source = audioCtx.createBufferSource();
    source.buffer = clickBuffer;
    const gainNode = audioCtx.createGain();
    // Reduced gain to 0.1 to address the "too loud" feedback while maintaining auditability
    gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
    source.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    source.start(0);
}

function playWarStartSound() {
    if (isMuted || !audioCtx || !warStartBuffer) return;
    const source = audioCtx.createBufferSource();
    source.buffer = warStartBuffer;
    const gainNode = audioCtx.createGain();
    gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime); // Quiet start
    source.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    source.start(0);
}

function playPeaceSound() {
    if (isMuted || !audioCtx || !peaceBuffer) return;
    const source = audioCtx.createBufferSource();
    source.buffer = peaceBuffer;
    const gainNode = audioCtx.createGain();
    gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
    source.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    source.start(0);
}

// Global click listener using capture phase to ensure sounds play even when stopPropagation is used
document.addEventListener('click', (e) => {
    const interactiveSelector = 'button, .menu-card, input, select, [role="button"], .side-header';
    if (e.target.closest(interactiveSelector)) {
        // Initialize and resume audio on first user interaction (browser requirement)
        initAudio();
        playClickSound();
    }
}, true);

/**
 * CONFIGURATION & STATE
 */
const BUFF_STATES = ['crippled', 'weakened', 'none', 'buff', 'super', 'godly'];
const BUFF_METADATA = {
    'crippled': { label: 'CRIPPLED', color: '#7b241c', textColor: '#fff', class: 'crippled-active' },
    'weakened': { label: 'WEAKENED', color: '#a04000', textColor: '#fff', class: 'weakened-active' },
    'none': { label: 'NONE', color: '#444', textColor: '#fff', class: '' },
    'buff': { label: 'GOLIATH', color: '#f1c40f', textColor: '#000', class: 'active' },
    'super': { label: 'DEITY', color: '#9b59b6', textColor: '#fff', class: 'super-active' },
    'godly': { label: 'GODLY', color: '#ffffff', textColor: '#000', class: 'godly-active' }
};

/**
 * Cycle a buff state forwards (direction = 1) or backwards (direction = -1).
 */
function cycleBuffState(current, direction) {
    if (!BUFF_STATES.length) return 'none';
    const dir = direction === -1 ? -1 : 1;
    const idx = BUFF_STATES.indexOf(current);
    const baseIndex = idx === -1 ? 0 : idx;
    let nextIndex = (baseIndex + dir + BUFF_STATES.length) % BUFF_STATES.length;
    return BUFF_STATES[nextIndex];
}

const CONFIG = {
    GEOJSON_BASE: 'https://raw.githubusercontent.com/martynafford/natural-earth-geojson/master/',
    GRID_RES: 0.1, 
    INFLUENCE_RATE: 0.18, 
    INFLUENCE_RADIUS: 0.40, 
    UNIT_SPAWN_COUNT: 50, // Base count
    MAX_UNITS_PER_SIDE: 1800,
    UNIT_DENSITY_FACTOR: 0.054, // Tripled density for massive frontline presence
    HOI4_COLORS: {
        'Germany': '#6e6e6e',
        'Russia': '#911c1c',
        'Soviet Union': '#911c1c',
        'United Kingdom': '#bd9c61',
        'United States of America': '#3a5c32',
        'United States': '#3a5c32',
        'France': '#304f9e',
        'Italy': '#4d6e35',
        'Japan': '#d4d4d4',
        'China': '#ded433',
        'Poland': '#f59595',
        'Turkey': '#8f1d1d',
        'Brazil': '#3da33d',
        'Canada': '#e31e24',
        'Australia': '#2e41a3',
        'India': '#e39d3b',
        'Spain': '#d1bc4d',
        'Mexico': '#d3a550',
        'Argentina': '#75aadb',
        'Chile': '#d43b3b',
        'Egypt': '#e3d17d',
        'South Africa': '#de8664',
        'Israel': '#2e86de',
        'Mongolia': '#943821',
        'Iran': '#1a8227',
        'Iraq': '#7a6021',
        'Saudi Arabia': '#2e7a3e',
        'Sweden': '#3a7bad',
        'Norway': '#4e5b8a',
        'Finland': '#7798ab',
        'Romania': '#b59b31',
        'Hungary': '#396b41',
        'Yugoslavia': '#bd8c42',
        'Greece': '#4a7ea3',
        'South Korea': '#2e86de',
        'North Korea': '#ff4757',
        'Vietnam': '#cc3333',
        'Ukraine': '#ffdd00'
    },
    UNIT_SPEED: 0.003,
    UNIT_NAVAL_SPEED: 0.025, // Significantly faster for swift naval invasions
    UNIT_TO_SOLDIER_RATIO: 5000,
    UNIT_HEALTH: 100,
    // Alpenjäger tuning: small, subtle advantages
    ALPEN_HEALTH_MULT: 1.25,           // +25% health
    ALPEN_MTN_SPEED_MULT: 1.4,         // faster in mountains
    ALPEN_COMBAT_MULT: 1.12,           // +12% damage, -12% damage taken
    COMBAT_DAMAGE: 0.7, 
    ATTRITION_DAMAGE: 0.06, 
    REINFORCEMENT_RATE: 0.005,
    ENCIRCLEMENT_DAMAGE_MULT: 2.5,
    ENCIRCLEMENT_RADIUS: 0.7,
    TEAM_A_COLOR: 'rgba(255, 50, 50, 0.5)',
    TEAM_B_COLOR: 'rgba(50, 100, 255, 0.5)',
    FRONTLINE_COLOR: 'rgba(0, 0, 0, 1.0)'
};

function getOptimizationFactor() {
    // More active sides => higher factor => more aggressive optimization
    const activeSides = sides.filter(s => s && s.length > 0).length || 1;
    return Math.max(1, activeSides / 2);
}

let gameState = 'MAIN_MENU';
let gameMode = 'CONQUEST'; // 'CONQUEST' or 'EDITOR'
let mapName = "Untitled Map";
let worldWidthDeg = 360;
let worldHeightDeg = 180;
let missilesEnabled = true;
let gameTimeEnabled = false;
let gameTimeDate = null; // {year, month, day}
let gameTimeAccumulatorMs = 0;
let viewMode = 'POLITICAL'; // 'POLITICAL' or 'FLAG'
let showCountryLabels = false;
// Cache for screen-space label curves so they don't move with the camera
let countryLabelAnchors = new Map(); // key: `${countryId}:${regionIndex}` -> { name, points, fontSize }
// Operational arrows have been deprecated and are now disabled.
let showOperationalArrows = false;
let showBattleIndicators = false;
let cityFocusMode = false;
// High‑level commanders ("generals") for each side, used to model strong plans.
let generals = [];
let operationStarts = new Map(); // Tracks start position of offensives: key -> {lat, lng}
let sides = [[], []]; // Array of arrays of countries
let attackers = sides[0];
let defenders = sides[1];
let teamAId = -1;
let activeSideIndex = 0;
let activeScenarioId = null;
let ffaMode = false;
let randomWarMode = false;
let randomWarFocus = false;
let adjacencyCache = null;
let teamAColor = 'rgba(255, 50, 50, 0.5)';
let teamBColor = 'rgba(50, 100, 255, 0.5)';
let lastSelectionTime = 0;
let lastSelectedId = -1;
let buffedTeam = null; // 'A' or 'B'
// Current remaining manpower for each side (shown as PERSONNEL)
let teamASoldiers = 0;
let teamBSoldiers = 0;
// Starting manpower snapshot, used to keep casualties consistent with PERSONNEL
let initialTeamASoldiers = 0;
let initialTeamBSoldiers = 0;
// Dynamic soldiers-per-unit scaling per side (computed at war start)
let soldiersPerUnitA = CONFIG.UNIT_TO_SOLDIER_RATIO;
let soldiersPerUnitB = CONFIG.UNIT_TO_SOLDIER_RATIO;
// Optional manual manpower overrides entered in the Conflict Setup panel
let manualSideAManpower = null;
let manualSideBManpower = null;
let units = [];
let activeBattles = [];
let capitalLostCountries = new Set();
let bombs = [];
let explosions = [];
let bases = [];
let cities = [];
let activeTheaterCities = [];

let influenceLayer = null;
let rawGeoJsonData = null;
let customCountryData = {
    name: '',
    color: '',
    flagUrl: null
};
let editingCountryId = -1;
let editingCityId = -1;
let selectedCountryIds = new Set();
let selectingOverlordForId = -1;
let peaceSelection1 = null;
let isPainting = false;
let lastPaintLatLng = null;
let brushSize = 0.5;
let isCustomTerrain = false;
let cinematicMode = false;
let mediaRecorder = null;
let recordedChunks = [];

// Overlay System State
let customSatelliteUrl = null;
let customSatelliteImg = null;
let referenceImageUrl = null;
let referenceOverlay = null; // L.imageOverlay
let refHandles = []; // Array of Leaflet markers
let refOpacity = 0.5;
let refScale = 1.0;
let refAboveTerrain = false;
let paintMaskId = -1; // -1 means no mask, >= 0 restricts painting to that ID
let peaceTreatiesDisabled = false;
let bombsDisabled = false;
let activeRebellion = null; // { rebelId, overlordId }
let mountainsEnabled = true;
let provincesEnabled = false;
let showUnitsVisually = true;
let disableCountryGradient = false;
let cityEditMode = null; // 'CREATE' | 'MOVE' | null
let animationFrameId = null;
let backgroundTickId = null;
let simFrameCount = 0;
let simSpeed = 0.5;
let isPaused = false;
let frameAccumulator = 0;
let lastTreatyTime = 0;
let sideACasualties = 0;
let sideBCasualties = 0;
let countryCasualties = new Map();
let initialCombatants = []; // Tracks nations that started the war for stable casualty menu display
let room = null;
let currentUsername = null;
let flagCodes = null;
let isMuted = false;
let currentScenarioContext = null; // { id, name, ownerUsername }
let godModeActive = false;
let preGodModeState = 'SIMULATING';
let latestCountryStats = new Map();

// Grid dimensions calculated after settings choice
let gridWidth, gridHeight, worldControlMap, deJureMap, provinceMap, occupationMap, primaryOccupierMap, landMask, biomeMask, terrainMask;
// Snapshots of borders at scenario start for quick restart
let initialWorldControlMapSnapshot = null;
let initialDeJureMapSnapshot = null;
let initialProvinceMapSnapshot = null;
let initialLandMaskSnapshot = null;
let initialBiomeMaskSnapshot = null;
// Snapshots for releasables and metadata at scenario start so annexed nations are still releasable on quick restart
let initialCountryMetadataSnapshot = null;
let initialCitiesSnapshot = null;
let flagProcessedBuffer, flagOwnerBuffer, flagSovereignBuffer, sovereignProcessedBuffer;
let countryMetadata = []; // Stores {feature, color, id}

// UI Elements
const addSideBtn = document.getElementById('add-side-btn');
const ffaToggleBtn = document.getElementById('ffa-toggle-btn');
const randomWarBtn = document.getElementById('random-war-btn');

// Disable dynamic side-adding / FFA UI so the game always uses exactly two sides
if (addSideBtn) addSideBtn.style.display = 'none';
if (ffaToggleBtn) ffaToggleBtn.style.display = 'none';
const sidesContainer = document.getElementById('sides-container');
const editorToolbox = document.getElementById('editor-toolbox');
const editorCreateBtn = document.getElementById('editor-create-btn');
const editorTestBtn = document.getElementById('editor-test-btn');
const editorUpdateBtn = document.getElementById('editor-update-btn');
const editorSaveBtn = document.getElementById('editor-save-btn');
const editorLoadBtn = document.getElementById('editor-load-btn');
const editorShareBtn = document.getElementById('editor-share-btn');
const editorHubBtn = document.getElementById('editor-hub-btn');
const editorLibraryBtn = document.getElementById('editor-library-btn');
const editorFlagLibraryBtn = document.getElementById('editor-flag-library-btn');
const editorPaintBtn = document.getElementById('editor-paint-btn');
const editorFillBtn = document.getElementById('editor-fill-btn');
const editorUnclaimBtn = document.getElementById('editor-unclaim-btn');
const editorTerrainBtn = document.getElementById('editor-terrain-btn');
const terrainTypeSelect = document.getElementById('terrain-type-select');
const terrainControls = document.getElementById('terrain-controls');
const editorPlaceDivisionBtn = document.getElementById('editor-place-division-btn');
const editorSaveMultiBtn = document.getElementById('editor-save-multi-btn');
const editorSaveAllZipBtn = document.getElementById('editor-save-all-zip-btn');
const editorLoadZipBtn = document.getElementById('editor-load-zip-btn');
const editorImportCountryBtn = document.getElementById('editor-import-country-from-scenario-btn');
const editorCityNewBtn = document.getElementById('editor-city-new-btn');
const editorCityClearBtn = document.getElementById('editor-city-clear-btn');
const editorToolsPage1Btn = document.getElementById('editor-tools-page-1-btn');
const editorToolsPage2Btn = document.getElementById('editor-tools-page-2-btn');
const editorToolsPage3Btn = document.getElementById('editor-tools-page-3-btn');
const editorToolsPage4Btn = document.getElementById('editor-tools-page-4-btn');
const editorToolsPage5Btn = document.getElementById('editor-tools-page-5-btn');
const editorExitBtn = document.getElementById('editor-exit-btn');
const editorMapSettingsBtn = document.getElementById('editor-map-settings-btn');
const brushControls = document.getElementById('brush-controls');
const brushSizeSlider = document.getElementById('brush-size-slider');
const brushSizeVal = document.getElementById('brush-size-val');
const viewModeBtn = document.getElementById('view-mode-btn');
const arrowsToggleBtn = document.getElementById('arrows-toggle-btn');
const battlesToggleBtn = document.getElementById('battles-toggle-btn');
const labelsToggleBtn = document.getElementById('labels-toggle-btn');

// Hide deprecated arrows toggle; arrows are no longer rendered.
if (arrowsToggleBtn) {
    arrowsToggleBtn.style.display = 'none';
}



const scenarioHubModal = document.getElementById('scenario-hub-modal');
const hubList = document.getElementById('hub-list');
const libraryList = document.getElementById('library-list');
const flagLibraryList = document.getElementById('flag-library-list');
const closeHubBtn = document.getElementById('close-hub-btn');
const tabScenariosBtn = document.getElementById('tab-scenarios-btn');
const tabCountriesBtn = document.getElementById('tab-countries-btn');
const tabFlagsBtn = document.getElementById('tab-flags-btn');

 // Item details + comments modal elements
const itemCommentModal = document.getElementById('item-comment-modal');
const itemModalTitle = document.getElementById('item-modal-title');
const itemModalDesc = document.getElementById('item-modal-desc');
const itemModalPreview = document.getElementById('item-modal-preview');
const itemCommentsList = document.getElementById('item-comments-list');
const itemCommentInput = document.getElementById('item-comment-input');
const itemCommentSubmit = document.getElementById('item-comment-submit');
const itemReplyIndicator = document.getElementById('item-reply-indicator');
const itemCancelReplyBtn = document.getElementById('item-comment-cancel-reply');
const closeItemModalBtn = document.getElementById('close-item-modal-btn');
const itemModalActions = document.getElementById('item-modal-actions');
const itemModalPlayBtn = document.getElementById('item-modal-play');
const itemModalRemixBtn = document.getElementById('item-modal-remix');

// Global chat modal elements
const globalChatModal = document.getElementById('global-chat-modal');
const globalChatList = document.getElementById('global-chat-list');
const globalChatInput = document.getElementById('global-chat-input');
const globalChatSend = document.getElementById('global-chat-send');
const globalChatClose = document.getElementById('global-chat-close');

// Hub caches for item details
let hubScenarioCache = {};
let hubCountryCache = {};
let hubFlagCache = {};

 // Comment state
let currentCommentItemType = null;
let currentCommentItemId = null;
let currentReplyParentId = null;
let currentEditingCommentId = null;
let commentsUnsubscribe = null;

// Global chat state
let globalChatUnsubscribe = null;

const uploadDetailsModal = document.getElementById('upload-details-modal');
const confirmUploadBtn = document.getElementById('confirm-upload-btn');
const cancelUploadBtn = document.getElementById('cancel-upload-btn');
const uploadNameInput = document.getElementById('upload-scenario-name');
const uploadDescInput = document.getElementById('upload-scenario-desc');

const shareCountryModal = document.getElementById('share-country-modal');
const confirmShareCountryBtn = document.getElementById('confirm-share-country-btn');
const cancelShareCountryBtn = document.getElementById('cancel-share-country-btn');
const shareCountryNameInput = document.getElementById('share-country-name');
const shareCountryDescInput = document.getElementById('share-country-desc');

const shareFlagModal = document.getElementById('share-flag-modal');
const releaseModal = document.getElementById('release-modal');
const releasableListContainer = document.getElementById('releasable-list');
const closeReleaseModalBtn = document.getElementById('close-release-modal');
const confirmShareFlagBtn = document.getElementById('confirm-share-flag-btn');
const cancelShareFlagBtn = document.getElementById('cancel-share-flag-btn');
const shareFlagNameInput = document.getElementById('share-flag-name');
const shareFlagDescInput = document.getElementById('share-flag-desc');
const shareFlagBtn = document.getElementById('share-flag-btn');

const createCountryModal = document.getElementById('create-country-modal');
const confirmCreateBtn = document.getElementById('confirm-create-btn');
const cancelCreateBtn = document.getElementById('cancel-create-btn');
const newCountryNameInput = document.getElementById('new-country-name');
const newCountryColorInput = document.getElementById('new-country-color');
const newCountryFlagInput = document.getElementById('new-country-flag');

const countryInspector = document.getElementById('country-inspector');
const inspectNameInput = document.getElementById('inspect-name-input');
const inspectFlagInput = document.getElementById('inspect-flag-input');
const inspectFetchFlagBtn = document.getElementById('inspect-fetch-flag-btn');
const inspectHubFlagBtn = document.getElementById('inspect-hub-flag-btn');
const inspectFlagPreview = document.getElementById('inspect-flag-preview');
const inspectColorSwatch = document.getElementById('inspect-color-swatch');
const inspectColorPicker = document.getElementById('inspect-color-picker');
const inspectPaintBtn = document.getElementById('inspect-paint-btn');
const inspectAnnexClickBtn = document.getElementById('inspect-annex-click-btn');
const shareCountryBtn = document.getElementById('share-country-btn');
const closeInspectorBtn = document.getElementById('close-inspector-btn');
const inspectBuffBtn = document.getElementById('inspect-buff-btn');
const annexCountryInput = document.getElementById('annex-country-input');
const annexCountryBtn = document.getElementById('annex-country-btn');

  // City inspector elements
const cityInspector = document.getElementById('city-inspector');

 // Import-from-scenario modal elements
const importCountryModal = document.getElementById('import-country-modal');
const importScenarioSelect = document.getElementById('import-scenario-select');
const importScenarioFileInput = document.getElementById('import-scenario-file');
const importCountrySearch = document.getElementById('import-country-search');
const importCountryCardList = document.getElementById('import-country-card-list');
const importCountryConfirmBtn = document.getElementById('import-country-confirm-btn');
const importCountryCancelBtn = document.getElementById('import-country-cancel-btn');

 // Temporary holder for loaded scenario used for country import
let importScenarioBuffer = null; // { metadata, mapData, gridRes }
let selectedImportCountryId = null;
let importScenarioCountriesCache = []; // [{id,name,tiles,flagUrl}]
// Remember which scenario option was last used for import (e.g. builtin:modern_2022)
let lastImportScenarioKey = null;

function renderImportCountryCards(filterText = '') {
    if (!importCountryCardList) return;
    const ft = (filterText || '').toLowerCase();
    const filtered = importScenarioCountriesCache.filter(c =>
        !ft || c.name.toLowerCase().includes(ft)
    );

    if (!filtered.length) {
        importCountryCardList.innerHTML = `
            <div style="font-size:11px; color:#777; text-align:center; padding:10px;">
                No countries match that search.
            </div>
        `;
        return;
    }

    importCountryCardList.innerHTML = filtered.map(c => {
        const selectedClass = (c.id === selectedImportCountryId) ? ' selected' : '';
        const tilesLabel = c.tiles.toLocaleString();
        const flagHtml = c.flagUrl
            ? `<img src="${c.flagUrl}" class="import-country-flag">`
            : `<div class="import-country-flag" style="background:#000;"></div>`;
        return `
            <div class="import-country-card${selectedClass}" data-country-id="${c.id}">
                ${flagHtml}
                <div style="flex:1; min-width:0;">
                    <div class="import-country-name">${c.name}</div>
                    <div class="import-country-tiles">${tilesLabel} tiles</div>
                </div>
            </div>
        `;
    }).join('');

    // Wire selection handlers
    importCountryCardList.querySelectorAll('.import-country-card').forEach(card => {
        card.addEventListener('click', () => {
            const id = parseInt(card.getAttribute('data-country-id') || '0', 10);
            if (!id) return;
            selectedImportCountryId = id;
            importCountryCardList.querySelectorAll('.import-country-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
        });
    });
}

// Hook search box once
if (importCountrySearch) {
    importCountrySearch.addEventListener('input', () => {
        renderImportCountryCards(importCountrySearch.value);
    });
}
const cityNameInput = document.getElementById('city-name-input');
const cityOwnerSelect = document.getElementById('city-owner-select');
const cityCapitalCheckbox = document.getElementById('city-capital-checkbox');
const cityMoveBtn = document.getElementById('city-move-btn');
const cityDeleteBtn = document.getElementById('city-delete-btn');
const cityCloseBtn = document.getElementById('city-close-btn');


const presetLowBtn = document.getElementById('preset-low-btn');
const presetDefaultBtn = document.getElementById('preset-default-btn');
const launchBtn = document.getElementById('launch-btn');
const musicVolumeSlider = document.getElementById('music-volume-slider');
const musicVolVal = document.getElementById('music-vol-val');
const saveSkipCheckbox = document.getElementById('save-skip-checkbox');
const mapResSelect = document.getElementById('map-res-select');
const gridResSelect = document.getElementById('grid-res-select');
const unitLimitSelect = document.getElementById('unit-limit-select');
const customTrackInput = document.getElementById('custom-track-input');
const clearCustomTrackBtn = document.getElementById('clear-custom-track-btn');
const disableUnitsVisuallyCheckbox = document.getElementById('disable-units-visually-checkbox');
const disableCountryGradientCheckbox = document.getElementById('disable-country-gradient-checkbox');

const settingsOverlay = document.getElementById('settings-overlay');
const mainMenu = document.getElementById('main-menu');
const loadingOverlay = document.getElementById('loading-overlay');
const loadingStatus = document.getElementById('loading-status');
const loadingBar = document.getElementById('loading-bar-progress');
const loadingTip = document.getElementById('loading-tip');
const playModeBtn = document.getElementById('play-mode-btn');
const editorModeBtn = document.getElementById('editor-mode-btn');
const editorChoiceModal = document.getElementById('editor-choice-modal');
const choiceIngameEditor = document.getElementById('choice-ingame-editor');
const choiceExternalEditor = document.getElementById('choice-external-editor');
const cancelEditorChoice = document.getElementById('cancel-editor-choice');

const editorSourceModal = document.getElementById('editor-source-modal');
const choiceSourceEarth = document.getElementById('choice-source-earth');
const choiceSourceBlank = document.getElementById('choice-source-blank');
const cancelSourceChoice = document.getElementById('cancel-source-choice');

const mapSettingsModal = document.getElementById('map-settings-modal');
const mapSettingsNameInput = document.getElementById('map-settings-name-input');
const mapSettingsWidthInput = document.getElementById('map-settings-width-input');
const mapSettingsHeightInput = document.getElementById('map-settings-height-input');
const mapSettingsMissilesCheckbox = document.getElementById('map-settings-missiles-checkbox');
const mapSettingsApplyBtn = document.getElementById('map-settings-apply-btn');
const mapSettingsCancelBtn = document.getElementById('map-settings-cancel-btn');

const conquestChoiceModal = document.getElementById('conquest-choice-modal');
const eraModernTabBtn = document.getElementById('era-tab-modern');
const eraWarsTabBtn = document.getElementById('era-tab-wars');
const eraHistoryTabBtn = document.getElementById('era-tab-history');
const eraStatesTabBtn = document.getElementById('era-tab-states');

const eraPageModern = document.getElementById('era-page-modern');
const eraPageWars = document.getElementById('era-page-wars');
const eraPageHistory = document.getElementById('era-page-history');
const eraPageStates = document.getElementById('era-page-states');
const choiceModernDay = document.getElementById('choice-modern-day');
const choice1936Scenario = document.getElementById('choice-1936-scenario');
const choice1942Scenario = document.getElementById('choice-1942-scenario');
const choiceWW1Scenario = document.getElementById('choice-ww1-1914');
const choice1804Scenario = document.getElementById('choice-1804-scenario');
const choice1492Scenario = document.getElementById('choice-1492-scenario');
const choice1ADScenario = document.getElementById('choice-1ad-scenario');
const choice1948Scenario = document.getElementById('choice-1948-scenario');
const choice1974Scenario = document.getElementById('choice-1974-scenario');
const choiceUSStates = document.getElementById('choice-us-states');
const choiceCanadaStates = document.getElementById('choice-canada-states');
const cancelConquestChoice = document.getElementById('cancel-conquest-choice');
const menuLoadPlayBtn = document.getElementById('menu-load-play-btn');
const mainSettingsBtn = document.getElementById('main-settings-btn');
const minimizeSetupBtn = document.getElementById('minimize-setup-btn');
const minimizeStatsBtn = document.getElementById('minimize-stats-btn');
const minimizeStatusBtn = document.getElementById('minimize-status-btn');
const muteBtn = document.getElementById('mute-btn');
const ingameSettingsBtn = document.getElementById('ingame-settings-btn');
const menuHubBtn = document.getElementById('menu-hub-btn');
const discordBtn = document.getElementById('discord-server-btn');
const donateBtn = document.getElementById('donate-btn');
const globalChatBtn = document.getElementById('global-chat-btn');
const tutorialBtn = document.getElementById('tutorial-btn');
const creditsBtn = document.getElementById('credits-btn');
const creditsModal = document.getElementById('credits-modal');
const closeCreditsBtn = document.getElementById('close-credits-btn');

const tutorialOverlay = document.getElementById('tutorial-overlay');
const tutorialStepContainer = document.getElementById('tutorial-step-container');
const tutorialPrevBtn = document.getElementById('tutorial-prev-btn');
const tutorialNextBtn = document.getElementById('tutorial-next-btn');
const tutorialDotsContainer = document.getElementById('tutorial-dots');

let currentTutorialStep = 0;
let tutorialActive = false;
let activeTutorialSet = [];
let activeTutorialKey = 'mw_tutorial_finished';

const conquestTutorialSteps = [
    {
        icon: "⚔️",
        title: "Welcome Commander",
        content: "Modern Wars is a grand strategy simulation of <b>organic frontlines</b>. Let's walk through a basic engagement setup.",
        actionRequired: "CLICK_NEXT"
    },
    {
        icon: "🌍",
        title: "Initialize World",
        content: "First, let's load the global theater. Click 'Next' to initialize the engine.",
        actionRequired: "LOAD_MAP"
    },
    {
        icon: "🇩🇪",
        title: "Recruit Side A",
        content: "We need an aggressor. Find <b>Germany</b> on the map and click it to recruit for Side A.",
        actionRequired: "SELECT_GERMANY"
    },
    {
        icon: "🇵🇱",
        title: "Recruit Side B",
        content: "Now for the opposition. Switch to <b>Side B</b> in the setup panel, then click <b>Poland</b> on the map.",
        actionRequired: "SELECT_POLAND"
    },
    {
        icon: "⚔️",
        title: "Launch Operation",
        content: "Both sides are ready. Click <b>Inaugurate Conflict</b> to begin the simulation.",
        actionRequired: "START_WAR"
    },
    {
        icon: "🛡️",
        title: "The Frontline",
        content: "The war is live! Units will now push borders organically. You can use <b>God Mode</b> to edit the map while the simulation runs. Good luck, Commander.",
        actionRequired: "CLICK_FINISH"
    }
];

const editorTutorialSteps = [
    {
        icon: "🛠️",
        title: "World Builder",
        content: "Welcome to the <b>Satellite Editor</b>. Here you can redraw history or create entirely new worlds from scratch.",
        actionRequired: "CLICK_NEXT"
    },
    {
        icon: "🏳️",
        title: "Establish Nations",
        content: "First, click the <b>New Nation</b> button in the top-left toolbox. Define its name and color, then <b>click on the map</b> to establish its capital.",
        actionRequired: "CLICK_NEXT"
    },
    {
        icon: "🎨",
        title: "Painting Borders",
        content: "Once a nation exists, <b>select it</b> on the map to open the <b>Inspector</b>. Use the <b>Manual Paint</b> tool to grow its territory cell by cell.",
        actionRequired: "CLICK_NEXT"
    },
    {
        icon: "📐",
        title: "Annexation Tool",
        content: "Want modern borders instantly? Use the <b>Annex Tool</b> in the Inspector. Type a name like <b>'France'</b> to absorb its real-world territory.",
        actionRequired: "CLICK_NEXT"
    },
    {
        icon: "📥",
        title: "The Library",
        content: "Don't build alone. The <b>Country Library</b> lets you import nations designed by the community directly into your map.",
        actionRequired: "CLICK_NEXT"
    },
    {
        icon: "💾",
        title: "Share Your Vision",
        content: "Once your map is complete, use <b>Save Preset</b> to keep it locally, or <b>Share to Hub</b> for others to play and remix!",
        actionRequired: "CLICK_FINISH"
    }
];

function updateTutorialUI() {
    const step = activeTutorialSet[currentTutorialStep];
    if (!step) return;

    tutorialStepContainer.innerHTML = `
        <div class="tutorial-step">
            <div class="tutorial-header">
                <span class="tutorial-icon">${step.icon}</span>
                <h2 class="tutorial-title">${step.title}</h2>
            </div>
            <div class="tutorial-body">${step.content}</div>
        </div>
    `;

    tutorialPrevBtn.style.visibility = currentTutorialStep === 0 ? 'hidden' : 'visible';
    tutorialNextBtn.innerText = currentTutorialStep === activeTutorialSet.length - 1 ? 'Finish' : 'Next';
    
    const needsAction = step.actionRequired !== "CLICK_NEXT" && 
                        step.actionRequired !== "CLICK_FINISH" && 
                        step.actionRequired !== "LOAD_MAP";
    tutorialNextBtn.disabled = needsAction;
    tutorialNextBtn.style.opacity = needsAction ? "0.5" : "1";

    tutorialDotsContainer.innerHTML = activeTutorialSet.map((_, i) => 
        `<div class="dot ${i === currentTutorialStep ? 'active' : ''}"></div>`
    ).join('');
    
    if (step.actionRequired === "LOAD_MAP") {
        tutorialNextBtn.onclick = () => {
            // Automatically trigger Modern Day scenario loading to skip the selection modal
            choiceModernDay.click();
            advanceTutorial();
        };
    } else {
        tutorialNextBtn.onclick = () => {
            if (currentTutorialStep < activeTutorialSet.length - 1) {
                currentTutorialStep++;
                updateTutorialUI();
            } else {
                endTutorial();
            }
        };
    }
}

function advanceTutorial() {
    if (currentTutorialStep < activeTutorialSet.length - 1) {
        currentTutorialStep++;
        updateTutorialUI();
    }
}

function endTutorial() {
    tutorialOverlay.style.display = 'none';
    tutorialActive = false;
    setCookie(activeTutorialKey, 'true');
}

function startTutorial(set, key) {
    activeTutorialSet = set;
    activeTutorialKey = key;
    currentTutorialStep = 0;
    tutorialActive = true;
    updateTutorialUI();
    tutorialOverlay.style.display = 'flex';
}

document.getElementById('tutorial-skip-btn').onclick = () => {
    endTutorial();
};

tutorialPrevBtn.onclick = () => {
    if (currentTutorialStep > 0) {
        currentTutorialStep--;
        updateTutorialUI();
    }
};

tutorialBtn.onclick = () => {
    startTutorial(conquestTutorialSteps, 'mw_tutorial_finished');
};
const mapUi = document.getElementById('main-ui');
const statusText = document.getElementById('status-text');
const setupPanel = document.getElementById('setup-panel');
const setupOptions = document.getElementById('setup-options');
const sideAList = document.getElementById('side-a-list');
const sideBList = document.getElementById('side-b-list');
const btnSideA = document.getElementById('btn-side-a');
const btnSideB = document.getElementById('btn-side-b');
const buffP1Btn = document.getElementById('buff-p1-btn');
const startBtn = document.getElementById('start-btn');
const rebellionBtn = document.getElementById('rebellion-btn');
if (rebellionBtn) {
    // Rebellions are disabled; hide the button and prevent use.
    rebellionBtn.style.display = 'none';
}
const densitySlider = document.getElementById('density-slider');
const noPeaceCheckbox = document.getElementById('no-peace-checkbox');
const disableBombsCheckbox = document.getElementById('disable-bombs-checkbox');
const cityFocusCheckbox = document.getElementById('city-focus-checkbox');
const setupDisableMountainsCheckbox = document.getElementById('setup-disable-mountains-checkbox');
const setupDisableProvincesCheckbox = document.getElementById('setup-disable-provinces-checkbox');
const disablePuppetsCheckbox = document.getElementById('disable-puppets-checkbox');
const mainDisableMountainsCheckbox = document.getElementById('disable-mountains-checkbox');
const mainDisableProvincesCheckbox = document.getElementById('disable-provinces-checkbox');

const casualtyPanel = document.getElementById('casualty-panel');
const casFlagA = document.getElementById('cas-flag-a');
const casFlagB = document.getElementById('cas-flag-b');
const casValA = document.getElementById('cas-val-a');
const casValB = document.getElementById('cas-val-b');

const leaderboardOverlay = document.getElementById('leaderboard-overlay');
const leaderboardList = document.getElementById('leaderboard-list');
const closeLeaderboardBtn = document.getElementById('close-leaderboard-btn');

// Status & control panels
const statsPanel = document.getElementById('stats-panel');
const restartScenarioBtn = document.getElementById('restart-scenario-btn');
const quickRestartBtn = document.getElementById('quick-restart-btn');
const resetBtn = document.getElementById('reset-btn');

// Buttons use clear text, ensure visibility is correct
if (quickRestartBtn) {
    quickRestartBtn.textContent = 'QUICK RESTART';
}
if (resetBtn) {
    resetBtn.textContent = 'RESET';
}
const mainMenuBtn = document.getElementById('main-menu-btn');
const leaderboardBtn = document.getElementById('leaderboard-btn');

function updateRestartVisibility() {
    if (!restartScenarioBtn || !mainMenuBtn || !quickRestartBtn) return;
    const inEditorLikeMode = (gameMode === 'EDITOR' || godModeActive);
    const hasSnapshots = !!(initialWorldControlMapSnapshot && initialDeJureMapSnapshot);

    // Hide restart + menu + leaderboard while in editor / godmode, show them during normal scenarios
    if (inEditorLikeMode) {
        restartScenarioBtn.style.display = 'none';
        quickRestartBtn.style.display = 'none';
        mainMenuBtn.style.display = 'none';
        if (leaderboardBtn) leaderboardBtn.style.display = 'none';
    } else {
        restartScenarioBtn.style.display = 'block';
        // Only show quick restart if we have the data to do it instantly
        quickRestartBtn.style.display = hasSnapshots ? 'block' : 'none';
        mainMenuBtn.style.display = 'block';
        if (leaderboardBtn) leaderboardBtn.style.display = 'block';
    }
}
const ffBtn = document.getElementById('ff-btn');
const pauseBtn = document.getElementById('pause-btn');
const speedDownBtn = document.getElementById('speed-down-btn');
const speedUpBtn = document.getElementById('speed-up-btn');
const godModeBtn = document.getElementById('god-mode-btn');
const forcePeaceBtn = document.getElementById('force-peace-btn');
const progressBar = document.getElementById('progress-bar');
const p1NameDisp = document.getElementById('p1-name');
const p2NameDisp = document.getElementById('p2-name');
const p1ControlDisp = document.getElementById('p1-control');
const p2ControlDisp = document.getElementById('p2-control');
const coordsDisplay = document.getElementById('coords');
const unitCountsDiv = document.getElementById('unit-counts');
const p1UnitsDisp = document.getElementById('p1-units');
const p2UnitsDisp = document.getElementById('p2-units');
const p1CitiesDisp = document.getElementById('p1-cities');
const p2CitiesDisp = document.getElementById('p2-cities');
const treatyAlert = document.getElementById('treaty-alert');
const treatyMsg = document.getElementById('treaty-msg');
const acceptTreatyBtn = document.getElementById('accept-treaty-btn');
const rejectTreatyBtn = document.getElementById('reject-treaty-btn');
const timeSystemCheckbox = document.getElementById('enable-time-checkbox');
const timeYearInput = document.getElementById('time-year-input');
const timeMonthInput = document.getElementById('time-month-input');
const timeDayInput = document.getElementById('time-day-input');
const gameDateDisplay = document.getElementById('game-date-display');

/**
 * INITIALIZATION
 */
const map = L.map('map', {
    zoomControl: false,
    center: [20, 0],
    zoom: 3,
    minZoom: 2,
    maxZoom: 12,
    worldCopyJump: true,
    dragging: true,
    // Use viscosity so panning against the world-size box feels smooth instead of snapping back
    maxBoundsViscosity: 1.0
});

let baseImageryLayer = null;
const imagerySelect = document.getElementById('imagery-select');

function setImageryProvider(provider, persist = true) {
    if (!provider || provider === 'undefined') provider = 'arcgis';

    if (baseImageryLayer) {
        map.removeLayer(baseImageryLayer);
        baseImageryLayer = null;
    }

    if (provider === 'arcgis') {
        baseImageryLayer = L.tileLayer(
            'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
            { maxZoom: 19, attribution: 'Tiles &copy; Esri', crossOrigin: 'anonymous' }
        );
        baseImageryLayer.addTo(map);
    } else if (provider === 'google') {
        baseImageryLayer = L.tileLayer(
            'https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
            { opacity: 0.9, maxZoom: 19, attribution: '&copy; Google', crossOrigin: 'anonymous' }
        );
        baseImageryLayer.addTo(map);
    }
    // 'wargames' / simplified mode has no tile layer, so baseImageryLayer stays null.

    if (persist) {
        setCookie('mw_imagery', provider);
    }
    
    if (imagerySelect) imagerySelect.value = provider;
    
    const c = map.getContainer();
    if (c) c.style.background = '#000';

    if (influenceLayer) {
        influenceLayer._forceRender = true;
        if (typeof influenceLayer._update === 'function') influenceLayer._update();
    }
}

/*
 * Initialize imagery style based on saved preference.
 */
setImageryProvider(getCookie('mw_imagery') || 'arcgis');

if (imagerySelect) {
    imagerySelect.addEventListener('change', (e) => {
        setImageryProvider(e.target.value);
    });
}

const ControlMapLayer = L.Layer.extend({
    onAdd: function(map) {
        // Create a canvas that is viewport-locked rather than layer-locked to ensure
        // screen-space coordinates (container points) map 1:1 without parent transform interference.
        this._container = L.DomUtil.create('canvas', '');
        this._container.style.position = 'absolute';
        this._container.style.top = '0';
        this._container.style.left = '0';
        this._container.style.pointerEvents = 'none';
        this._container.style.zIndex = '400';
        
        this._lastZoom = map.getZoom();
        this._renderRequested = false;
        this._visitId = 0;
        this._zooming = false;
        
        // Append to map container directly to avoid double-transforms from mapPane/overlayPane
        map.getContainer().appendChild(this._container);
        
        this._update();

        this._onMove = () => {
            if (!this._renderRequested) {
                this._renderRequested = true;
                requestAnimationFrame(() => {
                    this._update();
                    this._renderRequested = false;
                });
            }
        };

        map.on('move', this._onMove, this);
        map.on('moveend', this._onMove, this);
        map.on('zoomstart', () => { this._zooming = true; }, this);
        map.on('zoomend', () => { 
            this._zooming = false; 
            this._update(); 
            // Satellite stabilization: trigger a delayed cleanup render to ensure 
            // grid projection aligns with final post-zoom viewport coordinates.
            setTimeout(() => {
                this._forceRender = true;
                this._onMove();
            }, 100);
        }, this);
    },
    onRemove: function(map) {
        if (this._container && this._container.parentNode) {
            this._container.parentNode.removeChild(this._container);
        }
        map.off('move', this._onMove, this);
        map.off('zoomstart');
        map.off('zoomend');
    },
    _update: function() {
        const size = map.getSize();
        const dpr = window.devicePixelRatio || 1;
        const newW = Math.round(size.x * dpr);
        const newH = Math.round(size.y * dpr);

        if (this._container.width !== newW || this._container.height !== newH) {
            this._container.width = newW;
            this._container.height = newH;
            this._container.style.width = size.x + 'px';
            this._container.style.height = size.y + 'px';
        }

        const isSimulating = (gameState === 'SIMULATING' || (godModeActive && preGodModeState === 'SIMULATING')) && !isPaused;
        const mapMoved = !this._lastBounds || !this._lastBounds.equals(map.getBounds());
        
        if (isSimulating || mapMoved || this._forceRender) {
            this.render();
            this._lastBounds = map.getBounds();
            this._forceRender = false;
        }
    },
    render: function() {
        if (!worldControlMap || !landMask) return;
        const bounds = map.getBounds();
        const res = CONFIG.GRID_RES;
        const currentZoom = map.getZoom();
        
        // SATELLITE ENGINE STABILIZATION:
        // Handle longitude wrap-around (e.g. crossing the 180 meridian).
        // If the viewport wraps or is zoomed out enough to see the whole world, 
        // we default to the full horizontal grid span to prevent negative width RangeErrors.
        let xMin = Math.max(0, Math.floor((bounds.getWest() + 180) / res));
        let xMax = Math.min(gridWidth - 1, Math.ceil((bounds.getEast() + 180) / res));
        
        if (xMin > xMax || (bounds.getEast() - bounds.getWest() >= 360)) {
            xMin = 0;
            xMax = gridWidth - 1;
        }

        const yMin = Math.max(0, Math.floor((bounds.getSouth() + 90) / res));
        const yMax = Math.min(gridHeight - 1, Math.ceil((bounds.getNorth() + 90) / res));

        const terrain = terrainMask;
        const ctx = this._container.getContext('2d');
        const dpr = window.devicePixelRatio || 1;
        const isWar = gameState === 'SIMULATING' || (godModeActive && preGodModeState === 'SIMULATING');
        // Use the active dropdown value rather than the cookie to support non-persisted session-only mode switches
        const currentImagery = imagerySelect ? imagerySelect.value : (getCookie('mw_imagery') || 'arcgis');
        const isSimplifiedMode = currentImagery === 'wargames';
        // Custom terrain maps always use the Simplified/WarGames base (ocean/neutral land) for visual clarity
        const useSimplifiedBase = isSimplifiedMode || isCustomTerrain;

        ctx.clearRect(0, 0, this._container.width, this._container.height);
        ctx.save();
        ctx.scale(dpr, dpr);

        // --- COMPOSITE LEAFLET TILES INTO CANVAS ---
        // This ensures the map background is included in WebM recordings and Hub previews.
        if (!useSimplifiedBase) {
            const tilePane = map.getPane('tilePane');
            if (tilePane) {
                const tiles = tilePane.querySelectorAll('img.leaflet-tile');
                const mapRect = map.getContainer().getBoundingClientRect();
                tiles.forEach(tile => {
                    if (tile.complete && tile.naturalWidth > 0) {
                        const rect = tile.getBoundingClientRect();
                        const x = rect.left - mapRect.left;
                        const y = rect.top - mapRect.top;
                        
                        // Only draw tiles that are actually visible in the viewport
                        if (x + rect.width > 0 && y + rect.height > 0 && x < mapRect.width && y < mapRect.height) {
                            const opacity = window.getComputedStyle(tile).opacity;
                            ctx.globalAlpha = parseFloat(opacity) || 1.0;
                            try {
                                ctx.drawImage(tile, x, y, rect.width, rect.height);
                            } catch (e) {
                                // Silent catch for CORS/Tainted canvas issues (common with Google tiles)
                            }
                            ctx.globalAlpha = 1.0;
                        }
                    }
                });
            }
        }
        
        // Optimization: Pre-calculate pole map for faster lookups in render loop
        // Optimization: Pre-calculate pole map for faster lookups in render loop
        const metaMaxId = countryMetadata.reduce((max, m) => m ? Math.max(max, m.id) : max, 0);
        const sovereignPoleMap = new Int8Array(metaMaxId + 1); // 1 for A, -1 for B, 0 otherwise
        sides.forEach((side, idx) => {
            const pole = (idx % 2 === 0) ? 1 : -1;
            side.forEach(c => {
                if (c.id > 0) sovereignPoleMap[c.id] = pole;
            });
        });

        if (useSimplifiedBase) {
            const size = map.getSize();
            // Always render the procedural ocean/land gradient; custom satellite imagery is disabled.
            const centerLng = map.getCenter().lng;
            const grad = ctx.createLinearGradient(0, 0, 0, size.y);
            
            // Generate a latitude-aware gradient by sampling the viewport's geographic coordinates
            const stops = 12;
            for (let i = 0; i <= stops; i++) {
                const pct = i / stops;
                const screenY = size.y * pct;
                let lat = 0;
                try {
                    // Convert screen position to latitude for color calculation
                    lat = map.containerPointToLatLng([0, screenY]).lat;
                } catch(e) {}
                
                // Add noise to the equator logic so transitions aren't perfectly uniform
                // Noise is tied to longitude and screen stop index for a dynamic, non-perfect feel
                const noise = Math.sin(i * 0.7 + centerLng * 0.04) * 3.5;
                const absLat = Math.min(90, Math.max(0, Math.abs(lat) + noise));
                const t = Math.min(1, Math.max(0, absLat / 90));
                
                // Narrower, more subtle ocean color spectrum
                // Equator (0): rgb(5, 52, 72)
                // Poles (1): rgb(2, 18, 34)
                const r = Math.round(5 * (1 - t) + 2 * t);
                const g = Math.round(52 * (1 - t) + 18 * t);
                const b = Math.round(72 * (1 - t) + 34 * t);
                
                grad.addColorStop(pct, `rgb(${r},${g},${b})`);
            }
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, size.x, size.y);
        }

        // Draw reference image underneath terrain/countries but above ocean/background
        // when "Draw Above Terrain" is disabled. This now runs after both tile and
        // simplified ocean rendering so the guide is never hidden by the water layer.
        if (
            !this._isCapturing &&
            !refAboveTerrain &&
            referenceImageUrl &&
            referenceOverlay &&
            (gameMode === 'EDITOR' || gameMode === 'EDITOR_TEST' || godModeActive)
        ) {
            const img = referenceOverlay.getElement();
            if (img && img.complete && img.naturalWidth > 0) {
                const b = referenceOverlay.getBounds();
                const pTL = map.latLngToContainerPoint(b.getNorthWest());
                const pBR = map.latLngToContainerPoint(b.getSouthEast());
                ctx.save();
                ctx.globalAlpha = refOpacity;
                ctx.drawImage(img, pTL.x, pTL.y, pBR.x - pTL.x, pBR.y - pTL.y);
                ctx.restore();
            }
        }

        // Performance optimization: Downsample grid sampling dynamically.
        // During active zoom animations, we use a much coarser step to keep the main thread free.
        let step = 1;
        
        // Dynamic sampling based on zoom level and engine load
        const isEditing = gameMode === 'EDITOR' || gameMode === 'EDITOR_TEST' || godModeActive;
        if (isEditing) {
            step = 1;
        } else if (this._zooming) {
            // Keep step constant during zoom transitions to prevent index-based pixel shifting
            step = currentZoom < 3 ? 4 : (currentZoom < 5 ? 2 : 1);
        } else {
            if (currentZoom < 3) step = 4;
            else if (currentZoom < 5) step = 2;
            else step = 1;
        }

        const getGridPoint = (gx, gy) => {
            const lat = (gy * CONFIG.GRID_RES) - 90;
            const lng = (gx * CONFIG.GRID_RES) - 180;
            return map.latLngToContainerPoint([lat, lng]);
        };

        // --- REGION SEGMENTATION & DATA COLLECTION ---
        // Performance Fix: "only render parts of flags that are onscreen"
        // We limit contiguous blob detection to a slightly padded viewport and use global metadata 
        // bounds for UV mapping, preventing the engine from walking entire massive nations like Russia.
        const regions = [];
        
        if ((viewMode === 'FLAG' || showCountryLabels) && flagOwnerBuffer && flagProcessedBuffer) {
            this._visitId = (this._visitId || 0) + 1;
            const visitId = this._visitId;

            // In FLAG view we always sample at full resolution to avoid blocky / dotted flags.
            // For label-only mode we still downsample for performance when zoomed out.
            let samplingStep = 1;
            if (viewMode !== 'FLAG') {
                if (currentZoom < 4) samplingStep = 4;
                else if (currentZoom < 6) samplingStep = 2;
            }

            const startX = Math.floor(xMin / samplingStep) * samplingStep;
            const startY = Math.floor(yMin / samplingStep) * samplingStep;

            for (let y = startY; y <= yMax; y += samplingStep) {
                const rowOffset = y * gridWidth;
                for (let x = startX; x <= xMax; x += samplingStep) {
                    const idx = rowOffset + x;
                    if (flagProcessedBuffer[idx] === visitId) continue;

                    const sovereignId = worldControlMap[idx];
                    if (sovereignId <= 0) continue;
                    
                    let effectiveOwner = sovereignId;
                    if (isWar && landMask[idx] === 2) {
                        const occ = occupationMap[idx];
                        const sPole = sovereignPoleMap[sovereignId] || 0;
                        const isOccupiedByEnemy = (sPole === 1) ? (occ < -0.1) : (occ > 0.1);
                        if (isOccupiedByEnemy) {
                            effectiveOwner = primaryOccupierMap[idx] || effectiveOwner;
                        }
                    }
                    
                    if (effectiveOwner > 0) {
                        const regionPixels = [];
                        const queue = [idx];
                        flagProcessedBuffer[idx] = visitId;
                        
                        let latSum = 0, lngSum = 0, count = 0;
                        
                        // Contiguous search limited to viewport + padding to fulfill "only onscreen" directive
                        const pad = 25; 
                        const vXMin = Math.max(0, xMin - pad);
                        const vXMax = Math.min(gridWidth - 1, xMax + pad);
                        const vYMin = Math.max(0, yMin - pad);
                        const vYMax = Math.min(gridHeight - 1, yMax + pad);

                        while (queue.length > 0) {
                            const curr = queue.pop();
                            const cy = Math.floor(curr / gridWidth);
                            const cx = curr % gridWidth;
                            
                            if (cx >= xMin && cx <= xMax && cy >= yMin && cy <= yMax) {
                                regionPixels.push(curr);
                            }
                            
                            const lat = (cy * CONFIG.GRID_RES) - 90;
                            const lng = (cx * CONFIG.GRID_RES) - 180;
                            latSum += lat; lngSum += lng; count++;

                            const neighbors = [curr + samplingStep, curr - samplingStep, curr + gridWidth * samplingStep, curr - gridWidth * samplingStep];
                            for (const nIdx of neighbors) {
                                if (nIdx < 0 || nIdx >= gridWidth * gridHeight || flagProcessedBuffer[nIdx] === visitId) continue;
                                
                                const ny = Math.floor(nIdx / gridWidth);
                                const nx = nIdx % gridWidth;
                                if (nx < vXMin || nx > vXMax || ny < vYMin || ny > vYMax) continue;

                                const nSovereign = worldControlMap[nIdx];
                                let nEffectiveOwner = nSovereign;
                                if (isWar && landMask[nIdx] === 2) {
                                    const occ = occupationMap[nIdx];
                                    const sPole = sovereignPoleMap[nSovereign] || 0;
                                    const isOccupiedByEnemy = (sPole === 1) ? (occ < -0.1) : (occ > 0.1);
                                    if (isOccupiedByEnemy) nEffectiveOwner = primaryOccupierMap[nIdx] || nEffectiveOwner;
                                }

                                if (nEffectiveOwner === effectiveOwner) {
                                    flagProcessedBuffer[nIdx] = visitId;
                                    queue.push(nIdx);
                                }
                            }
                        }

                        if (regionPixels.length > 0) {
                            // Calculate local Lat/Lng bounds for label scaling
                            let minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
                            let regMinX = Infinity, regMaxX = -Infinity, regMinY = Infinity, regMaxY = -Infinity;
                            regionPixels.forEach(pxIdx => {
                                const py = Math.floor(pxIdx / gridWidth);
                                const px = pxIdx % gridWidth;
                                const lat = (py * CONFIG.GRID_RES) - 90;
                                const lng = (px * CONFIG.GRID_RES) - 180;
                                if (lat < minLat) minLat = lat; if (lat > maxLat) maxLat = lat;
                                if (lng < minLng) minLng = lng; if (lng > maxLng) maxLng = lng;
                                if (px < regMinX) regMinX = px;
                                if (px > regMaxX) regMaxX = px;
                                if (py < regMinY) regMinY = py;
                                if (py > regMaxY) regMaxY = py;
                            });

                            // Build 4 bins along the region's width so each disconnected landmass
                            // gets its own curved label spine independent of overseas territories.
                            const bins = Array.from({ length: 4 }, () => ({ latSum: 0, lngSum: 0, count: 0 }));
                            const width = Math.max(1, regMaxX - regMinX + 1);
                            regionPixels.forEach(pxIdx => {
                                const py = Math.floor(pxIdx / gridWidth);
                                const px = pxIdx % gridWidth;
                                const lat = (py * CONFIG.GRID_RES) - 90;
                                const lng = (px * CONFIG.GRID_RES) - 180;
                                const rel = (px - regMinX) / width;
                                const binIdx = Math.max(0, Math.min(3, Math.floor(rel * 4)));
                                const b = bins[binIdx];
                                b.latSum += lat;
                                b.lngSum += lng;
                                b.count++;
                            });

                            // Fallback for empty bins: interpolate from neighbors or region center
                            const centerLat = latSum / count;
                            const centerLng = lngSum / count;
                            for (let i = 0; i < 4; i++) {
                                if (bins[i].count === 0) {
                                    let left = null, right = null;
                                    for (let j = i - 1; j >= 0; j--) {
                                        if (bins[j].count > 0) { left = bins[j]; break; }
                                    }
                                    for (let j = i + 1; j < 4; j++) {
                                        if (bins[j].count > 0) { right = bins[j]; break; }
                                    }
                                    if (left && right) {
                                        bins[i].latSum = (left.latSum / left.count + right.latSum / right.count) / 2;
                                        bins[i].lngSum = (left.lngSum / left.count + right.lngSum / right.count) / 2;
                                        bins[i].count = 1;
                                    } else if (left && left.count > 0) {
                                        bins[i].latSum = left.latSum;
                                        bins[i].lngSum = left.lngSum;
                                        bins[i].count = left.count;
                                    } else if (right && right.count > 0) {
                                        bins[i].latSum = right.latSum;
                                        bins[i].lngSum = right.lngSum;
                                        bins[i].count = right.count;
                                    } else {
                                        bins[i].latSum = centerLat;
                                        bins[i].lngSum = centerLng;
                                        bins[i].count = 1;
                                    }
                                }
                            }

                            regions.push({
                                id: effectiveOwner,
                                sovereignId: sovereignId,
                                pixels: regionPixels,
                                latSum, lngSum, count,
                                minLat, maxLat, minLng, maxLng,
                                regMinX,
                                regMaxX,
                                regMinY,
                                regMaxY,
                                bins
                            });
                        }
                    }
                }
            }
        }

        // PASS 1: Base Background & Topography Rendering (Greedy Meshing)
        {
            // GREEDY MESHING (2D) for Political and Flag View background
            const vWidth = xMax - xMin + 1;
            const vHeight = yMax - yMin + 1;
            const viewportFills = new Array(vWidth * vHeight).fill(null);
            
            // 1. Pass: Pre-calculate fill styles and Label Data
            // Align sampling specifically to the greedy meshing steps
            for (let vy = 0; vy < vHeight; vy += step) {
                const y = yMin + vy;
                const rowOffset = vy * vWidth;
                for (let vx = 0; vx < vWidth; vx += step) {
                    const x = xMin + vx;
                    if (x >= gridWidth || y >= gridHeight) continue;
                    
                    const idx = y * gridWidth + x;
                    const sovereignId = worldControlMap[idx];
                    const occ = occupationMap[idx];
                    const lMask = landMask[idx];
                    const isWarZone = lMask === 2;
                    const isStable = lMask === 1;

                    if (isWarZone || isStable) {
                        let fillStyle = null;
                        let baseRgba = [150, 150, 150];
                        let alpha = (isSimplifiedMode && !isCustomTerrain) ? 1.0 : 0.65;
                        let effectiveId = sovereignId;

                        // FLAG MODE OVERRIDE: Render all land using the neutral "Map" palette so topography
                        // and biomes are visible behind the country flags.
                        let isBackgroundPass = viewMode === 'FLAG';

                        if (sovereignId === 0 || isBackgroundPass) {
                            if (useSimplifiedBase) {
                                const isDesert = biomeMask[idx] === 1;
                                baseRgba = isDesert ? [140, 120, 70] : [20, 38, 20];
                                alpha = 1.0;
                            } else if (!isBackgroundPass) {
                                continue;
                            }
                        }
                        
                        if (sovereignId > 0 && !isBackgroundPass) {
                            let meta = countryMetadata[sovereignId - 1];
                            if (!meta) {
                                baseRgba = [150, 150, 150];
                                alpha = 0.600;
                            } else {
                                let effectiveRgba = meta.rgba;
                                if (meta.overlordId) {
                                    const overlordMeta = countryMetadata[meta.overlordId - 1];
                                    if (overlordMeta) {
                                        effectiveRgba = [
                                            Math.round(overlordMeta.rgba[0] * 0.75 + meta.rgba[0] * 0.25),
                                            Math.round(overlordMeta.rgba[1] * 0.75 + meta.rgba[1] * 0.25),
                                            Math.round(overlordMeta.rgba[2] * 0.75 + meta.rgba[2] * 0.25),
                                            meta.rgba[3] || 1
                                        ];
                                    }
                                }

                                baseRgba = [effectiveRgba[0], effectiveRgba[1], effectiveRgba[2]];
                                alpha = (isSimplifiedMode && !isCustomTerrain) ? 1.0 : 0.65;

                                if (isWar && isWarZone && Math.abs(occ) > 0.01) {
                                    const isTeamAOccupying = occ > 0;
                                    const sPole = sovereignPoleMap[sovereignId] || 0;
                                    const isOccupiedLand = isTeamAOccupying ? sPole !== 1 : sPole !== -1;

                                    if (isOccupiedLand) {
                                        const occupierId = primaryOccupierMap[idx];
                                        const occMeta = occupierId > 0 ? countryMetadata[occupierId - 1] : null;
                                        if (occupierId > 0) effectiveId = occupierId;
                                        const occColor = occMeta ? occMeta.rgba : (isTeamAOccupying ? [255, 50, 50, 0.5] : [50, 100, 255, 0.5]);
                                        baseRgba = [
                                            Math.round(occColor[0] * 0.7 + 255 * 0.3),
                                            Math.round(occColor[1] * 0.7 + 255 * 0.3),
                                            Math.round(occColor[2] * 0.7 + 255 * 0.3)
                                        ];
                                        alpha = 0.85;
                                    } else {
                                        alpha = 0.7;
                                    }
                                } 
                            }
                        }

                        // Apply mountain visuals across all states (War or Peace), including neutral land
                        if (mountainsEnabled && terrain && terrain[idx] > 0) {
                            const intensity = terrain[idx];
                            
                            if (useSimplifiedBase && sovereignId === 0) {
                                // In Simplified Mode on neutral land, use a "highlight" for mountains to make them pop
                                // instead of just darkening, since the base color is already quite dark.
                                const lift = intensity * 42;
                                baseRgba[0] = Math.min(255, baseRgba[0] + lift);
                                baseRgba[1] = Math.min(255, baseRgba[1] + lift * 1.1);
                                baseRgba[2] = Math.min(255, baseRgba[2] + lift);
                                alpha = 0.95;
                            } else {
                                const dim = 0.7 - (intensity * 0.25);
                                baseRgba[0] = Math.floor(baseRgba[0] * dim);
                                baseRgba[1] = Math.floor(baseRgba[1] * dim);
                                baseRgba[2] = Math.floor(baseRgba[2] * dim);
                                
                                if (isWar) {
                                    alpha *= 0.75; 
                                } else {
                                    alpha = 0.75; 
                                }
                            }
                        }

                        if (useSimplifiedBase) {
                             fillStyle = `WG_${effectiveId}_${baseRgba.join(',')}_${alpha.toFixed(3)}_${biomeMask[idx]}`;
                        } else {
                             fillStyle = `rgba(${baseRgba[0]},${baseRgba[1]},${baseRgba[2]},${alpha.toFixed(3)})`;
                        }
                        viewportFills[rowOffset + vx] = fillStyle;
                    }
                }
            }

            // 2. Pass: Greedy Mesh Rendering
            const processed = new Uint8Array(vWidth * vHeight).fill(0);
            const gridXPositions = new Float32Array(vWidth + 1);
            const gridYPositions = new Float32Array(vHeight + 1);
            for (let x = 0; x <= vWidth; x++) gridXPositions[x] = getGridPoint(xMin + x, yMin).x;
            for (let y = 0; y <= vHeight; y++) gridYPositions[y] = getGridPoint(xMin, yMin + y).y;

            for (let vy = 0; vy < vHeight; vy += step) {
                const rowOffset = vy * vWidth;
                for (let vx = 0; vx < vWidth; vx += step) {
                    const vIdx = rowOffset + vx;
                    const fill = viewportFills[vIdx];
                    if (fill === null || processed[vIdx]) continue;

                    // Mesh Width (respecting sampling step)
                    let mw = step;
                    while (vx + mw < vWidth && viewportFills[rowOffset + vx + mw] === fill && !processed[rowOffset + vx + mw]) {
                        mw += step;
                    }
                    if (vx + mw > vWidth) mw = vWidth - vx;

                    // Mesh Height (respecting sampling step)
                    let mh = step;
                    while (vy + mh < vHeight) {
                        let rowMatch = true;
                        const nextRowOffset = (vy + mh) * vWidth;
                        for (let k = 0; k < mw; k += step) {
                            if (viewportFills[nextRowOffset + vx + k] !== fill || processed[nextRowOffset + vx + k]) {
                                rowMatch = false;
                                break;
                            }
                        }
                        if (!rowMatch) break;
                        mh += step;
                    }
                    if (vy + mh > vHeight) mh = vHeight - vy;

                    // Draw Mesh
                    const pX1 = gridXPositions[vx];
                    const pX2 = gridXPositions[vx + mw];
                    const pY1 = gridYPositions[vy];
                    const pY2 = gridYPositions[vy + mh];
                    
                    const drawX = Math.min(pX1, pX2);
                    const drawY = Math.min(pY1, pY2);
                    const drawW = Math.abs(pX2 - pX1);
                    const drawH = Math.abs(pY2 - pY1);

                    if (drawW > 0 && drawH > 0) {
                        if (typeof fill === 'string' && fill.startsWith('WG_')) {
                            const parts = fill.split('_');
                            const sid = parseInt(parts[1]);
                            const colorParts = parts[2].split(',').map(Number);
                            const a = parts[3] || '1';
                            const biome = parseInt(parts[4]) || 0;

                            if (biome === 1) {
                                // Apply desert tint to country color: lighter, yellower, and desaturated
                                colorParts[0] = Math.min(255, colorParts[0] * 1.1 + 30);
                                colorParts[1] = Math.min(255, colorParts[1] * 1.1 + 10);
                                colorParts[2] = Math.max(0, colorParts[2] * 0.85);
                            }

                            const meta = countryMetadata[sid - 1];
                            if (!disableCountryGradient && meta && meta.bounds) {
                                const pTop = getGridPoint(0, meta.bounds.minY).y;
                                const pBottom = getGridPoint(0, meta.bounds.maxY).y;
                                const g = ctx.createLinearGradient(0, pTop, 0, pBottom);
                                g.addColorStop(0, `rgba(${Math.min(255, colorParts[0] + 25)},${Math.min(255, colorParts[1] + 25)},${Math.min(255, colorParts[2] + 25)},${a})`);
                                g.addColorStop(0.3, `rgba(${colorParts[0]},${colorParts[1]},${colorParts[2]},${a})`);
                                g.addColorStop(1, `rgba(${Math.floor(colorParts[0] * 0.65)},${Math.floor(colorParts[1] * 0.65)},${Math.floor(colorParts[2] * 0.65)},${a})`);
                                ctx.fillStyle = g;
                            } else {
                                ctx.fillStyle = `rgba(${colorParts[0]},${colorParts[1]},${colorParts[2]},${a})`;
                            }
                        } else {
                            ctx.fillStyle = fill;
                        }
                        // Removed Math.floor to allow smooth subpixel rendering, relying on larger 
                        // overlap (+0.5px) to ensure no gaps appear during camera transitions.
                        ctx.fillRect(drawX - 0.25, drawY - 0.25, drawW + 0.5, drawH + 0.5);
                    }

                    // Mark as processed
                    for (let j = 0; j < mh; j += step) {
                        const targetRowOffset = (vy + j) * vWidth;
                        for (let i = 0; i < mw; i += step) {
                            processed[targetRowOffset + vx + i] = 1;
                        }
                    }
                }
            }
        }

        // PASS 1.5: Flag Overlays (Only in Flag View)
        if (viewMode === 'FLAG') {
            regions.forEach(region => {
                const id = region.id;
                const pixels = region.pixels;
                const meta = countryMetadata[id - 1];
                if (!meta) return;

                ctx.save();
                ctx.beginPath();
                
                const pixelsByRow = new Map();
                let regMinX = Infinity, regMaxX = -Infinity, regMinY = Infinity, regMaxY = -Infinity;
                
                pixels.forEach(idx => {
                    const py = Math.floor(idx / gridWidth);
                    const px = idx % gridWidth;
                    if (!pixelsByRow.has(py)) pixelsByRow.set(py, []);
                    pixelsByRow.get(py).push(px);
                    regMinX = Math.min(regMinX, px); regMaxX = Math.max(regMaxX, px);
                    regMinY = Math.min(regMinY, py); regMaxY = Math.max(regMaxY, py);
                });

                pixelsByRow.forEach((rowPixels, py) => {
                    rowPixels.sort((a, b) => a - b);
                    let spanStart = rowPixels[0];
                    const pY1 = getGridPoint(0, py).y;
                    const pY2 = getGridPoint(0, py + step).y;
                    const drawY = Math.min(pY1, pY2);
                    const drawH = Math.abs(pY2 - pY1) + 0.5;

                    for (let i = 0; i < rowPixels.length; i++) {
                        if (i === rowPixels.length - 1 || rowPixels[i+1] !== rowPixels[i] + step) {
                            const pXStart = getGridPoint(spanStart, py).x;
                            const pXEnd = getGridPoint(rowPixels[i] + step, py).x;
                            ctx.rect(pXStart, drawY, (pXEnd - pXStart) + 0.5, drawH);
                            if (i < rowPixels.length - 1) spanStart = rowPixels[i+1];
                        }
                    }
                });
                ctx.clip();

                const p1 = getGridPoint(region.regMinX, region.regMinY);
                const p2 = getGridPoint(region.regMaxX + step, region.regMaxY + step);
                const drawX = Math.min(p1.x, p2.x);
                const drawY = Math.min(p1.y, p2.y);
                const drawW = Math.abs(p1.x - p2.x);
                const drawH = Math.abs(p1.y - p2.y);

                let flagImg = null;
                const isFrance = meta.name === 'France';
                const suppressFlag = isFrance && !isWar;

                if (!suppressFlag) {
                    const countryObj = sides.flat().find(c => c.id === id);
                    if (countryObj && countryObj.flag && countryObj.flag.complete && countryObj.flag.naturalWidth > 0) {
                        flagImg = countryObj.flag;
                    } else {
                        if (!meta.tempFlag && meta.flagUrl) {
                            meta.tempFlag = new Image();
                            meta.tempFlag.crossOrigin = "anonymous";
                            meta.tempFlag.onload = () => { if (influenceLayer) influenceLayer.render(); };
                            meta.tempFlag.src = meta.flagUrl;
                        }
                        if (meta.tempFlag && meta.tempFlag.complete && meta.tempFlag.naturalWidth > 0) {
                            flagImg = meta.tempFlag;
                        }
                    }
                }

                if (flagImg && drawW > 0 && drawH > 0 && isFinite(drawX) && isFinite(drawY)) {
                    const viewW = this._container.width / dpr;
                    const viewH = this._container.height / dpr;
                    
                    const vL = Math.max(0, drawX);
                    const vT = Math.max(0, drawY);
                    const vR = Math.min(viewW, drawX + drawW);
                    const vB = Math.min(viewH, drawY + drawH);
                    
                    const vW = vR - vL;
                    const vH = vB - vT;
                    
                    if (vW > 0 && vH > 0 && isFinite(vW) && isFinite(vH)) {
                        const sx = ((vL - drawX) / drawW) * flagImg.naturalWidth;
                        const sy = ((vT - drawY) / drawH) * flagImg.naturalHeight;
                        const sw = (vW / drawW) * flagImg.naturalWidth;
                        const sh = (vH / drawH) * flagImg.naturalHeight;
                        
                        if (isFinite(sx) && isFinite(sy) && isFinite(sw) && isFinite(sh) && sw > 0 && sh > 0) {
                            ctx.globalAlpha = 0.55; // Slightly increased for visibility against mountains
                            ctx.drawImage(flagImg, sx, sy, sw, sh, vL, vT, vW, vH);
                            ctx.globalAlpha = 1.0;
                        }
                    }
                } else if (isFinite(drawX) && isFinite(drawY) && isFinite(drawW) && isFinite(drawH)) {
                    const c = meta.rgba;
                    ctx.fillStyle = `rgba(${c[0]},${c[1]},${c[2]},0.35)`;
                    ctx.fillRect(drawX, drawY, drawW, drawH);
                }

                ctx.restore();
            });
        }

        // PASS 2: Frontlines (Organic borders during war)
        if (isWar) {
            ctx.strokeStyle = CONFIG.FRONTLINE_COLOR;
            // Adaptive line width: Thinner at distance to prevent "blobby" lines
            ctx.lineWidth = Math.max(1.2, 3.5 * (currentZoom / 5));
            ctx.lineJoin = 'round';
            ctx.lineCap = 'round';
            ctx.beginPath();

            for (let y = yMin; y < yMax; y++) {
                for (let x = xMin; x < xMax; x++) {
                    const i1 = y * gridWidth + x;
                    const i2 = y * gridWidth + (x + 1);
                    const i3 = (y + 1) * gridWidth + (x + 1);
                    const i4 = (y + 1) * gridWidth + x;

                    if (landMask[i1] !== 2 && landMask[i2] !== 2 && landMask[i3] !== 2 && landMask[i4] !== 2) continue;

                    const v1 = occupationMap[i1];
                    const v2 = occupationMap[i2];
                    const v3 = occupationMap[i3];
                    const v4 = occupationMap[i4];

                    const b1 = v1 >= 0 ? 1 : 0;
                    const b2 = v2 >= 0 ? 1 : 0;
                    const b3 = v3 >= 0 ? 1 : 0;
                    const b4 = v4 >= 0 ? 1 : 0;

                    // Split each quad into two triangles for more organic Marching Triangles calculation
                    // Triangle 1: Corners (v1, v2, v4) - Top Left
                    // Triangle 2: Corners (v2, v3, v4) - Bottom Right
                    const lerp = (a, b) => {
                        const t = Math.abs(a) / (Math.abs(a) + Math.abs(b));
                        return isNaN(t) ? 0.5 : t;
                    };

                    const pT = getGridPoint(x + lerp(v1, v2), y);
                    const pR = getGridPoint(x + 1, y + lerp(v2, v3));
                    const pB = getGridPoint(x + lerp(v4, v3), y + 1);
                    const pL = getGridPoint(x, y + lerp(v1, v4));
                    const pD = getGridPoint(x + 1 - lerp(v2, v4), y + lerp(v2, v4)); // Point on common diagonal (v2 to v4)

                    // Tri 1 Analysis
                    const b1p = v1 >= 0 ? 1 : 0;
                    const b2p = v2 >= 0 ? 1 : 0;
                    const b4p = v4 >= 0 ? 1 : 0;
                    const id1 = (b1p << 2) | (b2p << 1) | b4p;
                    if (id1 !== 0 && id1 !== 7) {
                        switch (id1) {
                            case 1: case 6: ctx.moveTo(pL.x, pL.y); ctx.lineTo(pD.x, pD.y); break;
                            case 2: case 5: ctx.moveTo(pT.x, pT.y); ctx.lineTo(pD.x, pD.y); break;
                            case 3: case 4: ctx.moveTo(pT.x, pT.y); ctx.lineTo(pL.x, pL.y); break;
                        }
                    }

                    // Tri 2 Analysis
                    const b2pp = v2 >= 0 ? 1 : 0;
                    const b3pp = v3 >= 0 ? 1 : 0;
                    const b4pp = v4 >= 0 ? 1 : 0;
                    const id2 = (b2pp << 2) | (b3pp << 1) | b4pp;
                    if (id2 !== 0 && id2 !== 7) {
                        switch (id2) {
                            case 1: case 6: ctx.moveTo(pB.x, pB.y); ctx.lineTo(pD.x, pD.y); break;
                            case 2: case 5: ctx.moveTo(pR.x, pR.y); ctx.lineTo(pB.x, pB.y); break;
                            case 3: case 4: ctx.moveTo(pR.x, pR.y); ctx.lineTo(pD.x, pD.y); break;
                        }
                    }
                }
            }
            ctx.stroke();
        }

        // PASS 2.5: Operational Strategic Arrows (Group movement)
        // Deprecated: operational arrows have been removed from the visualization layer.
        // if (isWar && showOperationalArrows) {
        //     this.drawOperationalArrows(ctx);
        // }

        // PASS 3: Borders
        // PASS 3: Dynamic Borders & Coastlines
        // Outlines of annexed nations disappear because they now share the same owner ID in the grid.
        const isFlag = viewMode === 'FLAG';
        ctx.strokeStyle = isFlag ? 'rgba(255,255,255,0.45)' : 'rgba(0,0,0,0.3)';
        ctx.lineWidth = isFlag ? 1.5 : 1;
        ctx.beginPath();
        
        const borderStep = currentZoom < 5 ? 2 : 1;

        const getEffectiveId = (idx) => {
            if (idx < 0 || idx >= worldControlMap.length || landMask[idx] === 0) return -1; // -1 represents water
            if (!isFlag) return worldControlMap[idx];
            
            const sovereignId = worldControlMap[idx];
            if (sovereignId <= 0) return 0;
            if (isWar && landMask[idx] === 2) {
                const occ = occupationMap[idx];
                const sPole = sovereignPoleMap[sovereignId] || 0;
                const isOccupiedByEnemy = (sPole === 1) ? (occ < -0.1) : (occ > 0.1);
                if (isOccupiedByEnemy) return primaryOccupierMap[idx] || sovereignId;
            }
            return sovereignId;
        };

        for (let y = yMin; y < yMax; y += borderStep) {
            for (let x = xMin; x < xMax; x += borderStep) {
                const i = y * gridWidth + x;
                const id = getEffectiveId(i);

                if (x + borderStep < gridWidth) {
                    const idR = getEffectiveId(i + borderStep);
                    // Draw if IDs differ and at least one is land
                    if (id !== idR && (id !== -1 || idR !== -1)) {
                        const p1 = getGridPoint(x + borderStep, y);
                        const p2 = getGridPoint(x + borderStep, y + borderStep);
                        ctx.moveTo(p1.x, p1.y);
                        ctx.lineTo(p2.x, p2.y);
                    }
                }
                if (y + borderStep < gridHeight) {
                    const idD = getEffectiveId(i + gridWidth * borderStep);
                    if (id !== idD && (id !== -1 || idD !== -1)) {
                        const p1 = getGridPoint(x, y + borderStep);
                        const p2 = getGridPoint(x + borderStep, y + borderStep);
                        ctx.moveTo(p1.x, p1.y);
                        ctx.lineTo(p2.x, p2.y);
                    }
                }
            }
        }
        ctx.stroke();

        

        // Pass 4: Selection Highlight
        if (gameState !== 'SIMULATING') {
            const drawInspectorHighlight = (id) => {
                if (id <= 0) return;
                ctx.beginPath();
                ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
                ctx.setLineDash([5, 5]);
                ctx.lineWidth = 2;
                for (let y = yMin; y < yMax; y++) {
                    for (let x = xMin; x < xMax; x++) {
                        const i1 = y * gridWidth + x;
                        const i2 = y * gridWidth + (x + 1);
                        const i3 = (y + 1) * gridWidth + (x + 1);
                        const i4 = (y + 1) * gridWidth + x;
                        const b1 = worldControlMap[i1] === id ? 1 : 0;
                        const b2 = worldControlMap[i2] === id ? 1 : 0;
                        const b3 = worldControlMap[i3] === id ? 1 : 0;
                        const b4 = worldControlMap[i4] === id ? 1 : 0;
                        
                        const pT = getGridPoint(x + 0.5, y);
                        const pR = getGridPoint(x + 1, y + 0.5);
                        const pB = getGridPoint(x + 0.5, y + 1);
                        const pL = getGridPoint(x, y + 0.5);
                        const pD = getGridPoint(x + 0.5, y + 0.5);

                        // Split quad highlight into triangles for smoother inspector visuals
                        const id1 = (b1 << 2) | (b2 << 1) | b4;
                        if (id1 !== 0 && id1 !== 7) {
                            switch (id1) {
                                case 1: case 6: ctx.moveTo(pL.x, pL.y); ctx.lineTo(pD.x, pD.y); break;
                                case 2: case 5: ctx.moveTo(pT.x, pT.y); ctx.lineTo(pD.x, pD.y); break;
                                case 3: case 4: ctx.moveTo(pT.x, pT.y); ctx.lineTo(pL.x, pL.y); break;
                            }
                        }
                        const id2 = (b2 << 2) | (b3 << 1) | b4;
                        if (id2 !== 0 && id2 !== 7) {
                            switch (id2) {
                                case 1: case 6: ctx.moveTo(pB.x, pB.y); ctx.lineTo(pD.x, pD.y); break;
                                case 2: case 5: ctx.moveTo(pR.x, pR.y); ctx.lineTo(pB.x, pB.y); break;
                                case 3: case 4: ctx.moveTo(pR.x, pR.y); ctx.lineTo(pD.x, pD.y); break;
                            }
                        }
                    }
                }
                ctx.stroke();
                ctx.setLineDash([]);
            };

            if (editingCountryId > 0) drawInspectorHighlight(editingCountryId);

            const drawSelectionHighlight = (input, team) => {
                let id = -1;
                if (typeof input === 'number') {
                    id = input;
                } else if (input && input.properties) {
                    id = countryMetadata.findIndex(m => m.feature === input) + 1;
                }
                if (id <= 0) return;

                ctx.beginPath();
                ctx.strokeStyle = team === 'A' ? teamAColor.replace(/[\d.]+\)$/g, '1)') : teamBColor.replace(/[\d.]+\)$/g, '1)');
                ctx.lineWidth = 3;

                for (let y = yMin; y < yMax; y++) {
                    for (let x = xMin; x < xMax; x++) {
                        const i1 = y * gridWidth + x;
                        const i2 = y * gridWidth + (x + 1);
                        const i3 = (y + 1) * gridWidth + (x + 1);
                        const i4 = (y + 1) * gridWidth + x;
                        const b1 = worldControlMap[i1] === id ? 1 : 0;
                        const b2 = worldControlMap[i2] === id ? 1 : 0;
                        const b3 = worldControlMap[i3] === id ? 1 : 0;
                        const b4 = worldControlMap[i4] === id ? 1 : 0;
                        const mid = (b1 << 3) | (b2 << 2) | (b3 << 1) | b4;
                        if (mid === 0 || mid === 15) continue;
                        const pT = getGridPoint(x + 0.5, y); const pR = getGridPoint(x + 1, y + 0.5);
                        const pB = getGridPoint(x + 0.5, y + 1); const pL = getGridPoint(x, y + 0.5);
                        switch (mid) {
                            case 1: case 14: ctx.moveTo(pL.x, pL.y); ctx.lineTo(pB.x, pB.y); break;
                            case 2: case 13: ctx.moveTo(pR.x, pR.y); ctx.lineTo(pB.x, pB.y); break;
                            case 3: case 12: ctx.moveTo(pL.x, pL.y); ctx.lineTo(pR.x, pR.y); break;
                            case 4: case 11: ctx.moveTo(pT.x, pT.y); ctx.lineTo(pR.x, pR.y); break;
                            case 5: ctx.moveTo(pL.x, pL.y); ctx.lineTo(pT.x, pT.y); ctx.moveTo(pR.x, pR.y); ctx.lineTo(pB.x, pB.y); break;
                            case 6: case 9: ctx.moveTo(pT.x, pT.y); ctx.lineTo(pB.x, pB.y); break;
                            case 7: case 8: ctx.moveTo(pL.x, pL.y); ctx.lineTo(pT.x, pT.y); break;
                            case 10: ctx.moveTo(pT.x, pT.y); ctx.lineTo(pR.x, pR.y); ctx.moveTo(pL.x, pL.y); ctx.lineTo(pB.x, pB.y); break;
                        }
                    }
                }
                ctx.stroke();
            };
            sides.forEach((side, idx) => {
                const pole = (idx % 2 === 0) ? 'A' : 'B';
                side.forEach(c => {
                    if (c.feature) drawSelectionHighlight(c.feature, pole);
                    else if (c.id) drawSelectionHighlight(c.id, pole);
                });
            });
        }

        // Draw Explosions
        explosions.forEach(exp => {
            if (isNaN(exp.lat) || isNaN(exp.lng)) return;
            let p;
            try {
                p = map.latLngToContainerPoint([exp.lat, exp.lng]);
            } catch(e) { return; }
            
            const lifePct = exp.life / 30; // 30 frames life
            const radius = exp.maxRadius * (1 - lifePct) * (map.getZoom() / 5);
            
            ctx.beginPath();
            ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
            const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, radius);
            gradient.addColorStop(0, `rgba(255, 255, 255, ${lifePct})`);
            gradient.addColorStop(0.3, `rgba(255, 200, 50, ${lifePct * 0.8})`);
            gradient.addColorStop(1, `rgba(255, 50, 0, 0)`);
            ctx.fillStyle = gradient;
            ctx.fill();
        });



        // Draw Bombs
        bombs.forEach(b => {
            if (isNaN(b.currentLat) || isNaN(b.currentLng)) return;
            let p, pn;
            try {
                p = map.latLngToContainerPoint([b.currentLat, b.currentLng]);
                pn = map.latLngToContainerPoint([b.nextLat ?? b.currentLat, b.nextLng ?? b.currentLng]);
            } catch(e) { return; }
            const zoomScale = Math.pow(1.2, map.getZoom() - 3);
            
            // Draw trail - Improved glowing plume with better tapering
            b.trail.forEach((t, i) => {
                const tp = map.latLngToContainerPoint([t.lat, t.lng]);
                const progress = i / b.trail.length;
                const opacity = progress * 0.7;
                const baseRadius = 2.5 * zoomScale * progress;
                
                // Outer Glow
                ctx.beginPath();
                ctx.arc(tp.x, tp.y, baseRadius * 3, 0, Math.PI * 2);
                ctx.fillStyle = b.team === 'A' ? `rgba(255, 70, 0, ${opacity * 0.2})` : `rgba(0, 130, 255, ${opacity * 0.2})`;
                ctx.fill();

                // Core Plume
                ctx.beginPath();
                ctx.arc(tp.x, tp.y, baseRadius, 0, Math.PI * 2);
                ctx.fillStyle = b.team === 'A' ? `rgba(255, 180, 80, ${opacity})` : `rgba(100, 210, 255, ${opacity})`;
                ctx.fill();

                // White-hot core
                if (progress > 0.8) {
                    ctx.beginPath();
                    ctx.arc(tp.x, tp.y, baseRadius * 0.5, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
                    ctx.fill();
                }
            });

            // Draw Bomb (Missile shape)
            ctx.save();
            ctx.translate(p.x, p.y);
            
            // Calculate smooth rotation based on screen-space trajectory
            const angle = Math.atan2(pn.y - p.y, pn.x - p.x);
            ctx.rotate(angle);
            
            // Bomb Body
            ctx.fillStyle = '#fff';
            ctx.strokeStyle = b.team === 'A' ? '#ff4757' : '#2e86de';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(10 * zoomScale, 0); // Nose
            ctx.lineTo(-2 * zoomScale, -4 * zoomScale); // Top fin
            ctx.lineTo(-6 * zoomScale, -4 * zoomScale); // Back top
            ctx.lineTo(-6 * zoomScale, 4 * zoomScale); // Back bottom
            ctx.lineTo(-2 * zoomScale, 4 * zoomScale); // Bottom fin
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Engine Glow
            ctx.beginPath();
            ctx.arc(-6 * zoomScale, 0, 3 * zoomScale, 0, Math.PI * 2);
            ctx.fillStyle = b.team === 'A' ? '#ff4757' : '#2e86de';
            ctx.fill();
            
            ctx.restore();
        });

        // Calculate theater stats
        if (isWar && animationFrameId % 10 === 0) {
            let p1T = 0, p2T = 0;
            for (let i = 0; i < occupationMap.length; i++) {
                if (landMask[i] === 2) {
                    if (occupationMap[i] > 0.05) p1T++;
                    else if (occupationMap[i] < -0.05) p2T++;
                }
            }
            const total = p1T + p2T;
            if (total > 0) {
                const p1Percent = Math.round((p1T / total) * 100);
                p1ControlDisp.innerText = `${p1Percent}%`;
                p2ControlDisp.innerText = `${100 - p1Percent}%`;
                progressBar.style.width = `${p1Percent}%`;
            }
        }

        // Draw Bases (Missile Silos & Airports)
        if (isWar) {
            const zoom = map.getZoom();
            const baseSize = Math.max(4, zoom * 1.5);
            
            bases.forEach(base => {
                const p = map.latLngToContainerPoint([base.lat, base.lng]);
                ctx.beginPath();
                ctx.arc(p.x, p.y, baseSize * 1.2, 0, Math.PI * 2);
                ctx.fillStyle = base.team === 'A' ? 'rgba(255, 71, 87, 0.3)' : 'rgba(46, 134, 222, 0.3)';
                ctx.fill();
                ctx.fillStyle = '#fff';
                ctx.strokeStyle = base.team === 'A' ? '#ff4757' : '#2e86de';
                ctx.lineWidth = 2;
                ctx.fillRect(p.x - baseSize/2, p.y - baseSize/2, baseSize, baseSize);
                ctx.strokeRect(p.x - baseSize/2, p.y - baseSize/2, baseSize, baseSize);
                ctx.beginPath();
                ctx.moveTo(p.x - baseSize/2, p.y); ctx.lineTo(p.x + baseSize/2, p.y);
                ctx.moveTo(p.x, p.y - baseSize/2); ctx.lineTo(p.x, p.y + baseSize/2);
                ctx.stroke();
            });


        }

        // Draw cities
        const zoom = map.getZoom();
        const citySize = Math.max(2, zoom - 2);
        const viewBounds = map.getBounds();
        
        // Show all cities if zoomed in, or major cities/theater cities if zoomed out
        let citiesToDraw = [];
        if (zoom >= 6) {
            citiesToDraw = cities.filter(c => viewBounds.contains([c.lat, c.lng]));
        } else if (zoom >= 3) {
            const minPop = zoom === 5 ? 100000 : (zoom === 4 ? 400000 : 1000000);
            citiesToDraw = cities.filter(c => (c.pop > minPop && viewBounds.contains([c.lat, c.lng])) || activeTheaterCities.includes(c));
        } else {
            citiesToDraw = activeTheaterCities;
        }

        citiesToDraw.forEach(city => {
            let p;
            try {
                p = map.latLngToContainerPoint([city.lat, city.lng]);
            } catch(e) { return; }
            const val = getControlValue(city.lat, city.lng);
            const isCapital = city.isCapital;
            const actualSize = isCapital ? citySize * 1.6 : citySize;
            
            ctx.beginPath();
            ctx.arc(p.x, p.y, actualSize, 0, Math.PI * 2);
            
            if (val > 0.3) {
                ctx.fillStyle = teamAColor.replace(/[\d.]+\)$/g, '1)');
                ctx.strokeStyle = 'rgba(0,0,0,0.4)';
            } else if (val < -0.3) {
                ctx.fillStyle = teamBColor.replace(/[\d.]+\)$/g, '1)');
                ctx.strokeStyle = 'rgba(0,0,0,0.4)';
            } else {
                ctx.fillStyle = '#fff';
                ctx.strokeStyle = 'rgba(0,0,0,0.6)';
            }
            
            ctx.lineWidth = 1;
            ctx.fill();
            ctx.stroke();

            // City labels at high zoom
            if (zoom >= 6) {
                ctx.fillStyle = '#fff';
                ctx.font = 'bold 10px monospace';
                ctx.shadowBlur = 4;
                ctx.shadowColor = 'black';
                ctx.fillText(city.name, p.x + citySize + 2, p.y + 4);
                ctx.shadowBlur = 0;
            }
        });

        // Draw units - Small flags for land, ships for water
        if (showUnitsVisually) {
            const viewBounds = map.getBounds();
            const vS = viewBounds.getSouth() - 0.1;
            const vN = viewBounds.getNorth() + 0.1;
            const vW = viewBounds.getWest() - 0.1;
            const vE = viewBounds.getEast() + 0.1;
            const isWrapped = vW > vE;

            const currentZoom = map.getZoom();
            const zoomScale = Math.pow(1.3, currentZoom - 3);
            const w = 7 * zoomScale;
            const h = 4.5 * zoomScale;

            // Unit thinning at low zoom to prevent the "grid of flags" mess
            // When zoomed out, we only draw a fraction of units to keep the map readable
            const drawProb = currentZoom < 3 ? 0.2 : (currentZoom < 4 ? 0.5 : 1.0);

            units.forEach(u => {
                // Performance Culling: Skip units that are currently outside the map's viewport
                if (u.lat < vS || u.lat > vN) return;
                if (isWrapped) {
                    if (u.lng < vW && u.lng > vE) return;
                } else {
                    if (u.lng < vW || u.lng > vE) return;
                }

                if (drawProb < 1.0 && (u.id % 1) > drawProb) return;
                // Safety: Skip invalid units to prevent rendering artifacts
                if (isNaN(u.lat) || isNaN(u.lng)) return;

                let p;
                try {
                    p = map.latLngToContainerPoint([u.lat, u.lng]);
                } catch(e) { return; }
                
                // Safety: check resulting container points
                if (isNaN(p.x) || isNaN(p.y) || !isFinite(p.x) || !isFinite(p.y)) return;

                const idx = getGridIndex(u.lat, u.lng);
                const isAtSea = idx === -1 || landMask[idx] === 0;
                const isMountain = idx !== -1 && terrainMask[idx] > 0;
                const mountainIntensity = isMountain ? terrainMask[idx] : 0;

                if (isAtSea) {
                    // Draw a simple ship icon
                    ctx.fillStyle = u.team === 'A' ? '#ff4757' : '#2e86de';
                    ctx.beginPath();
                    ctx.moveTo(p.x - w/2, p.y + h/4);
                    ctx.lineTo(p.x + w/2, p.y + h/4);
                    ctx.lineTo(p.x + w/4, p.y + h/2);
                    ctx.lineTo(p.x - w/4, p.y + h/2);
                    ctx.closePath();
                    ctx.fill();
                    // Sail
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y + h/4);
                    ctx.lineTo(p.x, p.y - h/2);
                    ctx.lineTo(p.x + w/3, p.y + h/8);
                    ctx.closePath();
                    ctx.fillStyle = 'white';
                    ctx.fill();
                } else {
                    let country = null;

                    // Mountain Visuals: Units are "snow-capped" for visibility
                    const sw = w;
                    const sh = h;

                    // Robust lookup: first try assigned side, then search all sides as fallback
                    if (u.sideIndex !== undefined && sides[u.sideIndex]) {
                        country = sides[u.sideIndex].find(c => c.id === u.sovereignId);
                    }
                    
                    if (!country) {
                        // Deep search fallback
                        for (let s = 0; s < sides.length; s++) {
                            country = sides[s].find(c => c.id === u.sovereignId);
                            if (country) break;
                        }
                    }

                    // If still not found, try searching the metadata (for dead countries)
                    if (!country && u.sovereignId > 0) {
                        const meta = countryMetadata[u.sovereignId - 1];
                        if (meta) country = { flag: meta.tempFlag, name: meta.name };
                    }

                    const flag = country?.flag || country?.tempFlag;
                    if (flag && flag.complete && flag.naturalWidth > 0) {
                        ctx.drawImage(flag, p.x - sw/2, p.y - sh/2, sw, sh);
                        ctx.strokeStyle = 'rgba(0,0,0,0.3)';
                        ctx.lineWidth = Math.max(0.3, 0.3 * zoomScale);
                        ctx.strokeRect(p.x - sw/2, p.y - sh/2, sw, sh);
                    } else {
                        ctx.fillStyle = u.team === 'A' ? '#ff4757' : '#2e86de';
                        ctx.fillRect(p.x - sw/2, p.y - sh/2, sw, sh);
                    }



                    // Victory Boost Visual (Star)
                    if (showBattleIndicators && u.victoryBoostTicks > 0) {
                        ctx.save();
                        const starSize = 10 * zoomScale;
                        ctx.font = `${starSize}px serif`;
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.shadowBlur = 6;
                        ctx.shadowColor = 'gold';
                        ctx.fillText('⭐', p.x, p.y - sh - 2);
                        ctx.restore();
                    }

                    if (isMountain) {
                        // Floating triangle indicator well above the unit to signify mountain traversal
                        const triSize = 5 * zoomScale;
                        const triOffset = 10 * zoomScale;
                        ctx.fillStyle = `rgba(255, 255, 255, ${0.7 + (mountainIntensity * 0.3)})`;
                        ctx.beginPath();
                        ctx.moveTo(p.x, p.y - sh/2 - triOffset);
                        ctx.lineTo(p.x - triSize/2, p.y - sh/2 - triOffset + triSize);
                        ctx.lineTo(p.x + triSize/2, p.y - sh/2 - triOffset + triSize);
                        ctx.closePath();
                        ctx.fill();
                        
                        // Subtle outline for visibility against various backgrounds
                        ctx.strokeStyle = 'rgba(0,0,0,0.6)';
                        ctx.lineWidth = 0.5 * zoomScale;
                        ctx.stroke();
                    }
                }
            });
        }

        // PASS 5: Battle Clusters (Sword Emojis)
        if (isWar && showBattleIndicators) {
            const zoomScale = Math.pow(1.3, map.getZoom() - 3);
            activeBattles.forEach(b => {
                let p;
                try {
                    p = map.latLngToContainerPoint([b.lat, b.lng]);
                } catch(e) { return; }

                ctx.save();
                // Scale based on zoom and number of units in the battle
                const sizeMult = Math.min(2.0, 1.0 + (b.participants / 15));
                const emojiSize = Math.max(18, 26 * zoomScale * sizeMult);
                
                ctx.font = `${emojiSize}px serif`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                
                ctx.shadowBlur = 10;
                ctx.shadowColor = 'rgba(255,255,255,0.4)';
                ctx.shadowOffsetX = 0;
                ctx.shadowOffsetY = 0;
                
                // Pulsing animation
                const pulse = 0.9 + Math.sin(simFrameCount * 0.2) * 0.1;
                ctx.translate(p.x, p.y);
                ctx.scale(pulse, pulse);
                
                ctx.fillText('⚔️', 0, 0);
                ctx.restore();
            });
        }

        // PASS 6: Curved Soldier Labels (HOI4 Style)
        // Drawn AFTER units so they appear on top
        if (isWar) {
            this.drawCurvedLabel(ctx, 'A');
            this.drawCurvedLabel(ctx, 'B');
            // Only bake the casualty list into the map canvas during Cinematic Mode
            // so it appears in the WebM recording while the standard HTML UI is hidden.
            if (cinematicMode) {
                this.drawCasualtiesOnCanvas(ctx);
            }
        }

        // PASS 7: Country Labels (HOI4 Curved Style)
        // Drawn per contiguous region so overseas territories get their own labels,
        // recomputed every frame in map-space so they move naturally with the camera.
        if (showCountryLabels && regions && regions.length && countryMetadata) {
            const mapSize = map.getSize();
            const viewBounds = map.getBounds();
            const res = CONFIG.GRID_RES;

            const safeLatLngToPoint = (lat, lng) => {
                if (isNaN(lat) || isNaN(lng)) return null;
                try {
                    return map.latLngToContainerPoint([lat, lng]);
                } catch (e) {
                    return null;
                }
            };

            regions.forEach((region) => {
                const meta = countryMetadata[region.id - 1];
                if (!meta) return;

                const centerLat = region.latSum / region.count;
                const centerLng = region.lngSum / region.count;

                // Skip regions far from the current view
                if (!viewBounds.pad(0.5).contains([centerLat, centerLng])) return;
                const pCenter = safeLatLngToPoint(centerLat, centerLng);
                if (!pCenter ||
                    pCenter.x < -400 || pCenter.x > mapSize.x + 400 ||
                    pCenter.y < -400 || pCenter.y > mapSize.y + 400) {
                    return;
                }

                const nameRaw = meta.displayName || meta.name || "Unknown";
                const name = nameRaw.toUpperCase();

                // Area scale based on this region only
                const pMin = safeLatLngToPoint((region.regMinY * res) - 90, (region.regMinX * res) - 180);
                const pMax = safeLatLngToPoint((region.regMaxY * res) - 90, (region.regMaxX * res) - 180);
                if (!pMin || !pMax) return;
                const areaScale = Math.sqrt(Math.abs(pMax.x - pMin.x) * Math.abs(pMax.y - pMin.y));

                const zoom = map.getZoom();
                let fontSize = Math.max(8, Math.min(zoom * 12, areaScale / 4.5));

                // Build control points from region bins in lat/lng -> screen space
                const points = (region.bins || []).map(bin => {
                    if (!bin || bin.count <= 0) return null;
                    const lat = bin.latSum / bin.count;
                    const lng = bin.lngSum / bin.count;
                    return safeLatLngToPoint(lat, lng);
                });

                if (!points || points.length < 4) return;

                // Fill any missing points by interpolating neighbours, or fall back to center
                for (let i = 0; i < 4; i++) {
                    if (!points[i]) {
                        let left = null, right = null;
                        for (let j = i - 1; j >= 0; j--) {
                            if (points[j]) { left = { p: points[j], idx: j }; break; }
                        }
                        for (let j = i + 1; j < 4; j++) {
                            if (points[j]) { right = { p: points[j], idx: j }; break; }
                        }
                        if (left && right) {
                            const t = (i - left.idx) / (right.idx - left.idx);
                            points[i] = {
                                x: left.p.x + (right.p.x - left.p.x) * t,
                                y: left.p.y + (right.p.y - left.p.y) * t
                            };
                        } else if (left) {
                            points[i] = { ...left.p };
                        } else if (right) {
                            points[i] = { ...right.p };
                        } else {
                            points[i] = { ...pCenter };
                        }
                    }
                }

                // Measure curve length to fit text nicely
                let pathLength = 0;
                let prev = points[0];
                for (let i = 1; i <= 10; i++) {
                    const curr = this.getBezierPoint(i / 10, points[0], points[1], points[2], points[3]);
                    pathLength += Math.sqrt((curr.x - prev.x) ** 2 + (curr.y - prev.y) ** 2);
                    prev = curr;
                }

                const charFactor = 0.65;
                const spacingFactor = 0.35;
                const idealFontSize = (pathLength * 0.9) / (name.length * (charFactor + spacingFactor));
                fontSize = Math.min(idealFontSize, fontSize);
                if (fontSize < 7) return;

                this.drawTextOnCurve(
                    ctx,
                    name,
                    points[0],
                    points[1],
                    points[2],
                    points[3],
                    fontSize,
                    fontSize * spacingFactor
                );
            });
        }

        // Draw a white frame around the custom map extent so you can see where the world ends.
        // For custom maps, this should match the world size set before the map loads:
        // use explicit maxBounds if configured (blank canvas size), otherwise the full world.
        if (isCustomTerrain) {
            let boundsToUse = null;
            if (map.options.maxBounds) {
                boundsToUse = map.options.maxBounds;
            } else {
                const halfW = (worldWidthDeg || 360) / 2;
                const halfH = (worldHeightDeg || 180) / 2;
                boundsToUse = L.latLngBounds(
                    L.latLng(-halfH, -halfW),
                    L.latLng(halfH, halfW)
                );
            }

            if (boundsToUse) {
                try {
                    const nw = boundsToUse.getNorthWest();
                    const ne = boundsToUse.getNorthEast();
                    const se = boundsToUse.getSouthEast();
                    const sw = boundsToUse.getSouthWest();

                    const pNW = map.latLngToContainerPoint(nw);
                    const pNE = map.latLngToContainerPoint(ne);
                    const pSE = map.latLngToContainerPoint(se);
                    const pSW = map.latLngToContainerPoint(sw);

                    ctx.save();
                    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
                    ctx.lineWidth = 2.0;
                    ctx.setLineDash([6, 4]);
                    ctx.beginPath();
                    ctx.moveTo(pNW.x, pNW.y);
                    ctx.lineTo(pNE.x, pNE.y);
                    ctx.lineTo(pSE.x, pSE.y);
                    ctx.lineTo(pSW.x, pSW.y);
                    ctx.closePath();
                    ctx.stroke();
                    ctx.restore();
                } catch (e) {
                    // If projection fails (e.g. bounds offscreen), just skip drawing the frame.
                }
            }
        }

        // Draw Reference Image Guide (Over everything) when "Draw Above Terrain" is enabled.
        // Hidden during preview capture to ensure clean Hub thumbnails and exports.
        // This pass runs last so the reference image sits on top of terrain, countries, oceans, and units.
        if (
            !this._isCapturing &&
            refAboveTerrain &&
            referenceImageUrl &&
            referenceOverlay &&
            (gameMode === 'EDITOR' || gameMode === 'EDITOR_TEST' || godModeActive)
        ) {
            const img = referenceOverlay.getElement();
            if (img && img.complete && img.naturalWidth > 0) {
                const b = referenceOverlay.getBounds();
                const pTL = map.latLngToContainerPoint(b.getNorthWest());
                const pBR = map.latLngToContainerPoint(b.getSouthEast());
                ctx.save();
                ctx.globalAlpha = refOpacity;
                ctx.drawImage(img, pTL.x, pTL.y, pBR.x - pTL.x, pBR.y - pTL.y);
                ctx.restore();
            }
        }

        ctx.restore();
    },

    drawCurvedLabel: function(ctx, team) {
        // Only consider units that are currently within the map's viewport
        const viewBounds = map.getBounds();
        const vS = viewBounds.getSouth();
        const vN = viewBounds.getNorth();
        const vW = viewBounds.getWest();
        const vE = viewBounds.getEast();
        const isWrapped = vW > vE;

        const teamUnits = units.filter(u => {
            if (u.team !== team) return false;
            if (u.lat < vS || u.lat > vN) return false;
            if (isWrapped) {
                if (u.lng < vW && u.lng > vE) return false;
            } else {
                if (u.lng < vW || u.lng > vE) return false;
            }
            return true;
        });
        
        if (teamUnits.length < 1) return;

        // Calculate centroid and current active manpower of the visible unit cluster
        let avgLat = 0, avgLng = 0;
        let clusterManpower = 0;
        const sp = (team === 'A' ? (soldiersPerUnitA || CONFIG.UNIT_TO_SOLDIER_RATIO) : (soldiersPerUnitB || CONFIG.UNIT_TO_SOLDIER_RATIO));

        teamUnits.forEach(u => { 
            avgLat += u.lat; 
            avgLng += u.lng; 
            // Factor in current health for the manpower display
            clusterManpower += (u.health / CONFIG.UNIT_HEALTH) * sp;
        });
        avgLat /= teamUnits.length;
        avgLng /= teamUnits.length;

        if (isNaN(avgLat) || isNaN(avgLng)) return;
        let p;
        try {
            p = map.latLngToContainerPoint([avgLat, avgLng]);
        } catch(e) { return; }
        const zoom = map.getZoom();
        
        // Stable label height offset
        const yOffset = -Math.max(30, zoom * 5);

        // Determine general trend of the unit cluster for rotation
        let angle = 0;
        if (teamUnits.length > 5) {
            // Find two points that represent the "spread"
            let furthest = teamUnits[0];
            let maxDist = -1;
            teamUnits.forEach(u => {
                const d = (u.lat - avgLat)**2 + (u.lng - avgLng)**2;
                if (d > maxDist) { maxDist = d; furthest = u; }
            });
            const pStart = map.latLngToContainerPoint([avgLat, avgLng]);
            const pEnd = map.latLngToContainerPoint([furthest.lat, furthest.lng]);
            angle = Math.atan2(pEnd.y - pStart.y, pEnd.x - pStart.x);
            
            // Normalize angle to be horizontal-ish and upright
            if (angle > Math.PI/2) angle -= Math.PI;
            if (angle < -Math.PI/2) angle += Math.PI;
            // Dampen rotation to prevent extreme jitters
            angle *= 0.3; 
        }

        // Show a minimum of 1 if there are still units in the cluster
        const text = this.formatSoldiers(clusterManpower > 0 && clusterManpower < 1 ? 1 : clusterManpower);
        
        ctx.save();
        ctx.translate(p.x, p.y + yOffset);
        ctx.rotate(angle);
        
        const fontSize = Math.max(12, zoom * 4);
        ctx.font = `900 ${fontSize}px "Segoe UI", Roboto, Helvetica, Arial, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Background stroke for maximum legibility
        ctx.shadowBlur = 8;
        ctx.shadowColor = 'rgba(0,0,0,0.8)';
        ctx.strokeStyle = 'black';
        ctx.lineWidth = 5;
        ctx.strokeText(text, 0, 0);
        
        ctx.fillStyle = team === 'A' ? '#ff4757' : '#2e86de';
        ctx.fillText(text, 0, 0);
        
        ctx.restore();
    },

    getBezierPoint: function(t, p0, p1, p2, p3) {
        const cx = 3 * (p1.x - p0.x);
        const bx = 3 * (p2.x - p1.x) - cx;
        const ax = p3.x - p0.x - cx - bx;
        const cy = 3 * (p1.y - p0.y);
        const by = 3 * (p2.y - p1.y) - cy;
        const ay = p3.y - p0.y - cy - by;
        const x = (ax * Math.pow(t, 3)) + (bx * Math.pow(t, 2)) + (cx * t) + p0.x;
        const y = (ay * Math.pow(t, 3)) + (by * Math.pow(t, 2)) + (cy * t) + p0.y;
        return { x, y };
    },

    getBezierTangent: function(t, p0, p1, p2, p3) {
        const cx = 3 * (p1.x - p0.x);
        const bx = 3 * (p2.x - p1.x) - cx;
        const ax = p3.x - p0.x - cx - bx;
        const cy = 3 * (p1.y - p0.y);
        const by = 3 * (p2.y - p1.y) - cy;
        const ay = p3.y - p0.y - cy - by;
        const dx = (3 * ax * Math.pow(t, 2)) + (2 * bx * t) + cx;
        const dy = (3 * ay * Math.pow(t, 2)) + (2 * by * t) + cy;
        return Math.atan2(dy, dx);
    },

    drawTextOnCurve: function(ctx, text, p0, p1, p2, p3, fontSize, letterSpacing) {
        if (!text || isNaN(fontSize) || fontSize <= 0) return;
        ctx.font = `bold ${fontSize}px "Times New Roman", Times, serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        const chars = text.split('');
        const charCount = chars.length;
        
        // Calculate total path length roughly
        const samples = 10;
        let length = 0;
        let prev = p0;
        for (let i = 1; i <= samples; i++) {
            const curr = this.getBezierPoint(i / samples, p0, p1, p2, p3);
            length += Math.sqrt((curr.x - prev.x)**2 + (curr.y - prev.y)**2);
            prev = curr;
        }

        const charWidth = fontSize * 0.6;
        const totalTextWidth = charCount * (charWidth + letterSpacing);
        
        // Center the text on the path
        const startT = 0.5 - (totalTextWidth / length) * 0.5;
        const stepT = (totalTextWidth / length) / charCount;

        const isZooming = this._zooming;
        chars.forEach((char, i) => {
            const t = startT + i * stepT + stepT/2;
            if (t < 0 || t > 1) return;
            
            const pos = this.getBezierPoint(t, p0, p1, p2, p3);
            const angle = this.getBezierTangent(t, p0, p1, p2, p3);
            
            ctx.save();
            ctx.translate(pos.x, pos.y);
            ctx.rotate(angle);
            
            // Optimization: Skip expensive stroke operations for labels during active zoom/pan
            if (!isZooming) {
                ctx.strokeStyle = 'rgba(0,0,0,0.8)';
                ctx.lineWidth = Math.max(2, fontSize / 5);
                ctx.strokeText(char, 0, 0);
            }
            ctx.fillStyle = 'white';
            ctx.fillText(char, 0, 0);
            
            ctx.restore();
        });
    },

    formatSoldiers: function(n) {
        return Math.floor(Math.max(0, n)).toLocaleString();
    },

    drawCasualtiesOnCanvas: function(ctx) {
        if (gameState !== 'SIMULATING' && gameState !== 'WAR_OVER') return;

        const padding = 15;
        const boxWidth = 160;
        const entryHeight = 25;
        const dpr = window.devicePixelRatio || 1;
        
        // Background for casualties panel
        const drawSidePanel = (poleIdx, x, y) => {
            let entries = initialCombatants.filter(c => c.pole === poleIdx);
            // Check for mid-war joiners
            sides.forEach((side, sIdx) => {
                if (sIdx % 2 === poleIdx) {
                    side.forEach(c => {
                        if (!entries.some(e => e.id === c.id)) {
                            entries.push({ id: c.id, name: c.name, pole: poleIdx });
                        }
                    });
                }
            });

            if (entries.length === 0) return 0;

            const totalHeight = 30 + (entries.length * entryHeight);
            
            ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            // Fallback for roundRect which is missing in some older browsers/webviews
            if (typeof ctx.roundRect === 'function') {
                ctx.roundRect(x, y, boxWidth, totalHeight, 8);
            } else {
                ctx.rect(x, y, boxWidth, totalHeight);
            }
            ctx.fill();
            ctx.stroke();

            ctx.fillStyle = '#fff';
            ctx.font = '900 12px "Segoe UI", Arial';
            ctx.textAlign = 'center';
            ctx.fillText('CASUALTIES', x + boxWidth / 2, y + 20);

            entries.forEach((c, i) => {
                const casualties = countryCasualties.get(c.id) || 0;
                const formatted = this.formatSoldiers(casualties);
                const isDefeated = !sides.flat().some(active => active && active.id === c.id);
                const isPrimary = (i === 0 && !isDefeated);
                const itemY = y + 45 + (i * entryHeight);

                ctx.save();
                if (isDefeated) ctx.globalAlpha = 0.45;

                // Draw Flag
                const meta = countryMetadata[c.id - 1];
                const flag = meta?.tempFlag;
                if (flag && flag.complete && flag.naturalWidth > 0) {
                    const fw = isPrimary ? 28 : 20;
                    const fh = isPrimary ? 16 : 12;
                    ctx.drawImage(flag, x + 10, itemY - fh / 2 - 2, fw, fh);
                }

                // Draw Value
                ctx.fillStyle = poleIdx === 0 ? '#ff4757' : '#2e86de';
                ctx.font = `900 ${isPrimary ? '16px' : '11px'} monospace`;
                ctx.textAlign = 'left';
                ctx.fillText(formatted, x + 45, itemY);

                ctx.restore();
            });

            return totalHeight;
        };

        const mapSize = map.getSize();
        const startY = mapSize.y * 0.15;
        const startX = mapSize.x * 0.05;
        
        const hA = drawSidePanel(0, startX, startY);
        drawSidePanel(1, startX, startY + hA + 15);
    },

    drawOperationalArrows: function(ctx) {
        if (gameState !== 'SIMULATING') return;
        
        const sideGroups = new Map();
        const activeKeys = new Set();
        
        units.forEach(u => {
            // Group by side, sovereign, and spatial proximity
            const clusterRes = 4; 
            const cLat = Math.round(u.lat / clusterRes) * clusterRes;
            const cLng = Math.round(u.lng / clusterRes) * clusterRes;
            
            const key = `${u.sideIndex}-${u.sovereignId}-${cLat}-${cLng}`;
            if (!sideGroups.has(key)) sideGroups.set(key, []);
            sideGroups.get(key).push(u);
            activeKeys.add(key);
        });

        // Cleanup operations that no longer have unit clusters
        operationStarts.forEach((_, key) => {
            if (!activeKeys.has(key)) operationStarts.delete(key);
        });

        sideGroups.forEach((group, key) => {
            if (group.length < 5) {
                operationStarts.delete(key);
                return;
            }

            const parts = key.split('-');
            const sovereignId = parseInt(parts[1]);
            const team = group[0].team;
            const meta = countryMetadata[sovereignId - 1];
            
            let baseColor = team === 'A' ? 'rgba(255, 71, 87, 0.65)' : 'rgba(46, 134, 222, 0.65)';
            if (meta) {
                 const c = meta.rgba;
                 baseColor = `rgba(${c[0]}, ${c[1]}, ${c[2]}, 0.65)`;
            }

            let currentLat = 0, currentLng = 0;
            let targetLat = 0, targetLng = 0;
            let attackingCount = 0;

            group.forEach(u => {
                currentLat += u.lat; currentLng += u.lng;
                if (u.activeTargetPos) {
                    targetLat += u.activeTargetPos.lat;
                    targetLng += u.activeTargetPos.lng;
                    attackingCount++;
                }
            });

            currentLat /= group.length; currentLng /= group.length;
            
            if (attackingCount < group.length * 0.4) {
                operationStarts.delete(key);
                return;
            }

            targetLat /= attackingCount; targetLng /= attackingCount;

            // Initialize or update the persistent start point
            if (!operationStarts.has(key)) {
                operationStarts.set(key, { 
                    lat: currentLat, 
                    lng: currentLng,
                    lastTargetLat: targetLat,
                    lastTargetLng: targetLng
                });
            }

            const startPos = operationStarts.get(key);
            
            // Plan Change Detection: If the target has shifted significantly, reset the anchor
            const targetShiftSq = (targetLat - startPos.lastTargetLat)**2 + (targetLng - startPos.lastTargetLng)**2;
            if (targetShiftSq > 0.5) { // Plan has moved significantly
                startPos.lat = currentLat;
                startPos.lng = currentLng;
                startPos.lastTargetLat = targetLat;
                startPos.lastTargetLng = targetLng;
            }

            // Dynamic Anchor: Pull the start point forward if the group moves too far ahead
            // This keeps the arrow trailing the group rather than staying at the spawn point forever
            const distFromStartSq = (currentLat - startPos.lat)**2 + (currentLng - startPos.lng)**2;
            if (distFromStartSq > 6.0) { // Max arrow tail length
                const pullFactor = 0.05; // Smoothly pull tail forward
                startPos.lat += (currentLat - startPos.lat) * pullFactor;
                startPos.lng += (currentLng - startPos.lng) * pullFactor;
            }

            const dLat = targetLat - startPos.lat;
            const dLng = targetLng - startPos.lng;
            const distSq = dLat*dLat + dLng*dLng;
            
            // Draw arrows if target is sufficiently far from start position
            if (distSq > 0.05) { 
                this.drawHoi4Arrow(ctx, [startPos.lat, startPos.lng], [targetLat, targetLng], baseColor);
            }
        });
    },

    drawHoi4Arrow: function(ctx, start, end, color) {
        let pStart, pEnd;
        try {
            pStart = map.latLngToContainerPoint(start);
            pEnd = map.latLngToContainerPoint(end);
        } catch(e) { return; }

        const dx = pEnd.x - pStart.x;
        const dy = pEnd.y - pStart.y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < 20) return;

        const zoom = map.getZoom();
        const baseWidth = Math.max(12, zoom * 4.5); // Thicker arrows
        
        // Control point for HOI4-style arc
        const midX = (pStart.x + pEnd.x) / 2;
        const midY = (pStart.y + pEnd.y) / 2;
        const perpX = -dy / dist * (dist * 0.15); 
        const perpY = dx / dist * (dist * 0.15);
        const cp = { x: midX + perpX, y: midY + perpY };

        ctx.save();
        
        // Body Gradient: Fade from transparent to solid color
        const grad = ctx.createLinearGradient(pStart.x, pStart.y, pEnd.x, pEnd.y);
        grad.addColorStop(0, color.replace(/[\d.]+\)$/g, '0.0)'));
        grad.addColorStop(0.2, color.replace(/[\d.]+\)$/g, '0.5)'));
        grad.addColorStop(1, color.replace(/[\d.]+\)$/g, '0.9)'));
        
        ctx.shadowBlur = 10;
        ctx.shadowColor = 'rgba(0,0,0,0.6)';

        // Arrow Body (Quadratic curve)
        ctx.beginPath();
        ctx.moveTo(pStart.x, pStart.y);
        ctx.quadraticCurveTo(cp.x, cp.y, pEnd.x, pEnd.y);
        ctx.lineWidth = baseWidth;
        ctx.lineCap = 'butt';
        ctx.strokeStyle = grad;
        ctx.stroke();

        // Central Spine highlight for a "pressed" look
        ctx.beginPath();
        ctx.moveTo(pStart.x, pStart.y);
        ctx.quadraticCurveTo(cp.x, cp.y, pEnd.x, pEnd.y);
        ctx.lineWidth = baseWidth * 0.15;
        ctx.strokeStyle = 'rgba(255,255,255,0.4)';
        ctx.stroke();

        // Animated Pulse effect on the arrow (moving towards the target)
        const pulse = (simFrameCount % 40) / 40;
        const pulsePos = this.getBezierPoint(pulse, pStart, cp, cp, pEnd); // Approximating quad as cubic for existing helper
        ctx.beginPath();
        ctx.arc(pulsePos.x, pulsePos.y, baseWidth * 0.4, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.fill();

        // Solid Arrowhead
        const angle = Math.atan2(pEnd.y - cp.y, pEnd.x - cp.x);
        const headLen = baseWidth * 2.2;
        ctx.beginPath();
        ctx.moveTo(pEnd.x, pEnd.y);
        ctx.lineTo(pEnd.x - headLen * Math.cos(angle - 0.45), pEnd.y - headLen * Math.sin(angle - 0.45));
        ctx.lineTo(pEnd.x - headLen * Math.cos(angle + 0.45), pEnd.y - headLen * Math.sin(angle + 0.45));
        ctx.closePath();
        ctx.fillStyle = color.replace(/[\d.]+\)$/g, '1.0)');
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.8)';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.restore();
    }
});

influenceLayer = new ControlMapLayer().addTo(map);

// Create dedicated pane for reference images to ensure they stay behind the control map but above base imagery
map.createPane('refImagePane');
map.getPane('refImagePane').style.zIndex = 350;

/**
 * PERSISTENT GRID LOGIC
 */

/**
 * Completely remade province generation using multi-octave cellular noising.
 * Generates an organic, non-repeating province ID that is strictly unique to a specific sovereign country.
 */
function getProvinceId(x, y, countryId) {
    if (countryId <= 0) return 0;
    const res = CONFIG.GRID_RES;
    const lat = (y * res) - 90;
    const lng = (x * res) - 180;

    // Base coordinates scaled for province density
    const scale = 0.65;
    let nx = lng * scale;
    let ny = lat * scale;

    // Octave 1: Domain warping
    const w1 = Math.sin(nx * 0.8 + ny * 0.6 + countryId * 0.1) * 1.2;
    const w2 = Math.cos(nx * 0.5 - ny * 0.9 + countryId * 0.2) * 1.1;

    // Octave 2: High-frequency fractal noise composition
    const noise = (
        Math.sin((nx + w1) * 2.3) * 0.5 +
        Math.sin((ny + w2) * 1.9) * 0.5 +
        Math.sin(((nx + ny) * 1.4) + countryId) * 0.3 +
        Math.cos((nx * 3.1) - (ny * 2.7)) * 0.2
    );

    // Grid snap into "cells"
    const cellX = Math.floor(nx + w1 + noise);
    const cellY = Math.floor(ny + w2 + noise);

    // Unique hashing using prime pairing to ensure no two provinces share an ID, even across countries.
    // The countryId is a primary component of the hash, forcing province lines to reset at borders.
    const h1 = Math.abs(cellX * 73856093);
    const h2 = Math.abs(cellY * 19349663);
    const h3 = Math.abs(countryId * 83492791);
    
    return (h1 ^ h2 ^ h3) >>> 0; 
}

function generateProvinces() {
    if (!provinceMap || !worldControlMap) return;
    for (let y = 0; y < gridHeight; y++) {
        const rowOffset = y * gridWidth;
        for (let x = 0; x < gridWidth; x++) {
            const idx = rowOffset + x;
            provinceMap[idx] = getProvinceId(x, y, worldControlMap[idx]);
        }
    }
}

function applyWorldBounds(widthDeg, heightDeg, allowImagerySwitch = true) {
    // Clamp to safe ranges
    const w = Math.max(10, Math.min(360, widthDeg || 360));
    const h = Math.max(10, Math.min(180, heightDeg || 180));
    worldWidthDeg = w;
    worldHeightDeg = h;

    // If changing size while not in Simplified mode, force switch to Simplified (wargames)
    if (allowImagerySwitch && imagerySelect && imagerySelect.value !== 'wargames') {
        setImageryProvider('wargames', false);
        if (disableCountryGradientCheckbox) {
            disableCountryGradientCheckbox.checked = true;
            disableCountryGradient = true;
        }
    }

    const halfW = w / 2;
    const halfH = h / 2;
    const bounds = L.latLngBounds(
        L.latLng(-halfH, -halfW),
        L.latLng(halfH, halfW)
    );
    map.setMaxBounds(bounds);

    // If current center is outside new bounds, fit map into the new box
    if (!bounds.contains(map.getCenter())) {
        map.fitBounds(bounds, { animate: true });
    }

    // Force bounding box redraw
    if (influenceLayer) {
        influenceLayer._forceRender = true;
        if (typeof influenceLayer._update === 'function') {
            influenceLayer._update();
        } else {
            influenceLayer.render();
        }
    }
}

function isInsideWorldBoxLatLng(lat, lng) {
    if (!worldWidthDeg || !worldHeightDeg) return true;
    const halfW = worldWidthDeg / 2;
    const halfH = worldHeightDeg / 2;
    return lat >= -halfH && lat <= halfH && lng >= -halfW && lng <= halfW;
}

function getGridIndex(lat, lng) {
    // Normalize longitude to [-180, 180] before indexing to handle wrap-around coordinates
    let wrappedLng = ((lng + 180) % 360 + 360) % 360 - 180;
    const x = Math.floor((wrappedLng + 180) / CONFIG.GRID_RES);
    const y = Math.floor((lat + 90) / CONFIG.GRID_RES);
    if (x < 0 || x >= gridWidth || y < 0 || y >= gridHeight) return -1;
    return y * gridWidth + x;
}

function recalculateAllBounds() {
    if (!countryMetadata || !worldControlMap) return;
    const isWar = (gameState === 'SIMULATING' || (godModeActive && preGodModeState === 'SIMULATING'));
    
    countryMetadata.forEach(meta => {
        if (!meta) return;
        // Store last bounds for stable binning
        meta.prevBounds = meta.bounds ? { ...meta.bounds } : null;
        meta.bounds = { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity };
        meta.labelBins = Array.from({length: 4}, () => ({ latSum: 0, lngSum: 0, count: 0 }));
        meta.totalLatSum = 0;
        meta.totalLngSum = 0;
        meta.totalCount = 0;
    });

    const res = CONFIG.GRID_RES;
    for (let y = 0; y < gridHeight; y++) {
        const rowOffset = y * gridWidth;
        const lat = (y * res) - 90;
        for (let x = 0; x < gridWidth; x++) {
            const i = rowOffset + x;
            const lng = (x * res) - 180;
            let id = worldControlMap[i];
            
            if (isWar && landMask[i] === 2) {
                const occ = occupationMap[i];
                if (Math.abs(occ) > 0.05) {
                    const occupierId = primaryOccupierMap[i];
                    if (occupierId > 0) id = occupierId;
                }
            }

            if (id > 0 && id <= countryMetadata.length) {
                const meta = countryMetadata[id - 1];
                if (meta) {
                    const b = meta.bounds;
                    if (x < b.minX) b.minX = x;
                    if (x > b.maxX) b.maxX = x;
                    if (y < b.minY) b.minY = y;
                    if (y > b.maxY) b.maxY = y;

                    // Stable Label Data Accumulation
                    meta.totalLatSum += lat;
                    meta.totalLngSum += lng;
                    meta.totalCount++;

                    // Use prev bounds to determine stable binning during this pass
                    if (meta.prevBounds && meta.prevBounds.minX !== Infinity) {
                        const width = Math.max(1, meta.prevBounds.maxX - meta.prevBounds.minX);
                        const binIdx = Math.max(0, Math.min(3, Math.floor(((x - meta.prevBounds.minX) / width) * 4)));
                        const bin = meta.labelBins[binIdx];
                        bin.latSum += lat;
                        bin.lngSum += lng;
                        bin.count++;
                    }
                }
            }
        }
    }

    // Finalize stable centers
    countryMetadata.forEach(meta => {
        if (meta && meta.totalCount > 0) {
            meta.stableCenter = { lat: meta.totalLatSum / meta.totalCount, lng: meta.totalLngSum / meta.totalCount };
            // If prev bounds weren't available, the bins will be empty; Pass 7 will handle fallback
        }
    });
}

function getCountryColor(feature, alpha = 1) {
    if (!feature) return `rgba(150, 150, 150, ${alpha})`;
    const name = feature.properties.NAME || feature.properties.name || feature.properties.admin || feature.properties.NAME_LONG || "Unknown";
    
    // Check for predefined HOI4 colors
    if (CONFIG.HOI4_COLORS[name]) {
        const hex = CONFIG.HOI4_COLORS[name];
        // Convert hex to rgba
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    // Fallback to deterministic hash-based HSL
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
        hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    const h = Math.abs(hash % 360);
    const s = 60 + Math.abs((hash >> 8) % 30); // 60-90%
    const l = 45 + Math.abs((hash >> 16) % 20); // 45-65%
    return `hsla(${h}, ${s}%, ${l}%, ${alpha})`;
}

function getControlValue(lat, lng) {
    const idx = getGridIndex(lat, lng);
    if (idx === -1 || landMask[idx] === 0) return 0;
    // For combat logic, return occupation if in active warzone
    if (gameState === 'SIMULATING' && landMask[idx] === 2) return occupationMap[idx];
    return 0;
}

function estimateUnitsForCountry(countryId) {
    if (!worldControlMap || !worldControlMap.length || !countryId) return 0;

    // Count how many grid cells this country controls on the current map
    let cellCount = 0;
    for (let i = 0; i < worldControlMap.length; i++) {
        if (worldControlMap[i] === countryId) cellCount++;
    }
    if (cellCount === 0) return 0;

    const multiplier = parseFloat(densitySlider.value) || 1.0;
    const sizeFactor = Math.max(1, cellCount / 1500);
    const densityScale = 1.0 / Math.pow(sizeFactor, 0.45);

    let count = Math.floor(cellCount * CONFIG.UNIT_DENSITY_FACTOR * multiplier * densityScale);
    const flatFloor = 3;
    count = Math.max(flatFloor, Math.min(count, CONFIG.MAX_UNITS_PER_SIDE));

    return count * CONFIG.UNIT_TO_SOLDIER_RATIO;
}



function updateSidesUI() {
    sidesContainer.innerHTML = '';
    
    sides.forEach((sideList, sideIdx) => {
        const sideCol = document.createElement('div');
        sideCol.className = 'side-col';

        // Compute total estimated troops for this side/front
        const sideTotalTroops = sideList.reduce((sum, country) => {
            const est = estimateUnitsForCountry(country.id);
            return sum + (est || 0);
        }, 0);
        
        const sideHeader = document.createElement('div');
        sideHeader.className = `side-header ${activeSideIndex === sideIdx ? 'active' : ''}`;
        sideHeader.dataset.side = sideIdx;
        
        // Use A, B, C, D labels
        const sideLabel = String.fromCharCode(65 + sideIdx);
        if (sideList.length > 0 && sideTotalTroops > 0) {
            sideHeader.innerHTML = `
                <div style="font-size:11px; font-weight:900;">SIDE ${sideLabel}</div>
                <div style="font-size:9px; color:#777; margin-top:2px; text-transform:uppercase; letter-spacing:0.5px;">
                    ~ ${influenceLayer.formatSoldiers(sideTotalTroops)} troops
                </div>
            `;
        } else {
            sideHeader.innerText = `SIDE ${sideLabel}`;
        }
        sideHeader.style.color = sideIdx % 2 === 0 ? '#ff4757' : '#2e86de';
        if (activeSideIndex === sideIdx) {
            sideHeader.style.backgroundColor = sideIdx % 2 === 0 ? 'rgba(255, 71, 87, 0.2)' : 'rgba(46, 134, 222, 0.2)';
            sideHeader.style.borderColor = sideIdx % 2 === 0 ? '#ff4757' : '#2e86de';
        }

        sideHeader.onclick = () => {
            activeSideIndex = sideIdx;
            updateSidesUI();
        };

        const listContainer = document.createElement('div');
        listContainer.className = 'side-country-list';

        sideList.forEach((country, i) => {
            const meta = countryMetadata.find(m => m && m.id === country.id);
            const slot = document.createElement('div');
            slot.className = `setup-slot active-${sideIdx % 2 === 0 ? 'a' : 'b'}`;
            slot.style.borderColor = country.color.replace(/[\d.]+\)$/g, '1)');
            
            const buffState = country.buffState || 'none';
            const bMeta = BUFF_METADATA[buffState] || BUFF_METADATA['none'];

            // Find flag for setup UI from live object or metadata
            const flagUrl = country.flag?.src || meta?.flagUrl || '';

            // Estimated troop size based on current density slider and map ownership
            const estTroops = estimateUnitsForCountry(country.id);
            const estLabel = estTroops ? influenceLayer.formatSoldiers(estTroops) : 'UNKNOWN';

            const releasables = countryMetadata.filter(m => m && m.releasableBy === country.id);

            const displayName = getTranslation(country.name, getCookie('mw_lang') || 'en', 'NATIONS');
            slot.innerHTML = `
                <div class="slot-name" title="${country.name}" style="display: flex; flex-direction: column; gap: 2px; align-items: center; justify-content: center; margin-bottom: 5px;">
                    <div style="display: flex; align-items: center; gap: 8px; justify-content: center;">
                        ${flagUrl ? `<img src="${flagUrl}" style="width: 22px; height: 13px; object-fit: cover; border: 1px solid rgba(255,255,255,0.2); flex-shrink: 0; border-radius: 1px;">` : ''}
                        <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${displayName}</span>
                    </div>
                    <div style="font-size: 9px; color: #777; text-transform: uppercase; letter-spacing: 0.5px;">~ ${estLabel} troops</div>
                    <button class="mini-btn buff-toggle-btn" style="margin-top: 4px; background:${bMeta.color}; color:${bMeta.textColor}; font-size:8px; padding:2px 6px; display:flex; align-items:center; gap:4px; justify-content:center;" title="Adjust combat buffs: use ◀ / ▶ to move between CRIPPLED, WEAKENED, NONE, GOLIATH, DEITY, GODLY">
                        <span class="buff-arrow" data-dir="-1" style="font-size:10px;">◀</span>
                        <span class="buff-label">BUFF: ${bMeta.label}</span>
                        <span class="buff-arrow" data-dir="1" style="font-size:10px;">▶</span>
                    </button>
                    ${releasables.length > 0 ? `<button class="mini-btn release-btn" style="background: #27ae60; font-size: 8px; padding: 2px 6px; margin-top: 4px;" title="Release a releasable core from this country into the war.">RELEASE...</button>` : ''}
                </div>
                <div class="slot-controls">
                    <select class="mini-select role-select" title="OFF: Leads attacks and creates new fronts. SUP: Sends expeditionary support to allied offensives instead of opening its own invasions.">
                        <option value="OFFENSE" ${country.role === 'OFFENSE' ? 'selected' : ''} title="OFF: Offensive main participant, pushes its own fronts.">OFF</option>
                        <option value="SUPPORT" ${country.role === 'SUPPORT' ? 'selected' : ''} title="SUP: Support nation; mostly sends troops to help allies instead of starting new invasions.">SUP</option>
                    </select>
                    <select class="mini-select strategy-select" title="Per-country behavior: BAL = mixed; AGG = push hard; DEF = hold cores; BLZ = fast spearheads.">
                        <option value="BALANCED" ${country.strategy === 'BALANCED' ? 'selected' : ''} title="BAL: Balanced offense and defense along the whole front.">BAL</option>
                        <option value="AGGRESSIVE" ${country.strategy === 'AGGRESSIVE' ? 'selected' : ''} title="AGG: Very aggressive, tries to push hard even when risky.">AGG</option>
                        <option value="DEFENSIVE" ${country.strategy === 'DEFENSIVE' ? 'selected' : ''} title="DEF: Focuses on defending own cores and reclaiming lost land.">DEF</option>
                        <option value="BLITZ" ${country.strategy === 'BLITZ' ? 'selected' : ''} title="BLZ: Blitz-style spearheads that seek breakthroughs and deep pushes.">BLZ</option>
                    </select>
                    <button class="clear-slot-btn" title="Remove this country from the selected side.">×</button>
                </div>
            `;

            const buffBtn = slot.querySelector('.buff-toggle-btn');
            if (buffBtn) {
                const buffLabelEl = buffBtn.querySelector('.buff-label');
                const buffArrows = buffBtn.querySelectorAll('.buff-arrow');

                const applyBuffState = (newState) => {
                    country.buffState = newState;
                    if (meta) meta.buffState = newState;
                    const metaBuff = BUFF_METADATA[newState] || BUFF_METADATA['none'];
                    if (buffLabelEl) buffLabelEl.textContent = `BUFF: ${metaBuff.label}`;
                    buffBtn.style.background = metaBuff.color;
                    buffBtn.style.color = metaBuff.textColor;
                };

                buffArrows.forEach(span => {
                    span.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const dir = parseInt(span.getAttribute('data-dir'), 10) || 1;
                        const current = country.buffState || 'none';
                        const nextState = cycleBuffState(current, dir);
                        applyBuffState(nextState);
                    });
                });

                // Clicking the center label still cycles forward for convenience
                if (buffLabelEl) {
                    buffLabelEl.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const current = country.buffState || 'none';
                        const nextState = cycleBuffState(current, 1);
                        applyBuffState(nextState);
                    });
                }
            }

            slot.querySelector('.role-select').onchange = (e) => {
                country.role = e.target.value;
            };

            slot.querySelector('.strategy-select').onchange = (e) => {
                country.strategy = e.target.value;
            };
            
            slot.querySelector('.clear-slot-btn').onclick = (e) => {
                e.stopPropagation();
                sideList.splice(i, 1);
                updateSidesUI();
                influenceLayer.render();
            };

            const releaseBtn = slot.querySelector('.release-btn');
            if (releaseBtn) {
                releaseBtn.onclick = (e) => {
                    e.stopPropagation();
                    openReleaseModal(country.id, sideIdx);
                };
            }
            
            listContainer.appendChild(slot);
        });

        sideCol.appendChild(sideHeader);
        
        // Add "Delete Side" button for sides beyond the first two
        if (sides.length > 2) {
            const delBtn = document.createElement('button');
            delBtn.className = 'mini-btn';
            delBtn.innerText = 'Remove Side';
            delBtn.style.fontSize = '8px';
            delBtn.style.padding = '2px';
            delBtn.onclick = (e) => {
                e.stopPropagation();
                sides.splice(sideIdx, 1);
                if (activeSideIndex >= sides.length) activeSideIndex = sides.length - 1;
                updateSidesUI();
            };
            sideCol.appendChild(delBtn);
        }

        sideCol.appendChild(listContainer);
        sidesContainer.appendChild(sideCol);

        if (sideIdx < sides.length - 1) {
            const divider = document.createElement('div');
            divider.className = 'vs-divider';
            divider.innerText = 'VS';
            divider.style.alignSelf = 'center';
            sidesContainer.appendChild(divider);
        }
    });

    const activeSidesCount = sides.filter(s => s && s.length > 0).length;
    const allSelectedCountries = sides.flat().filter(c => !!c);
    
    // Rebellions are disabled: ensure button (if present) stays hidden and inert.
    if (rebellionBtn) {
        rebellionBtn.style.display = 'none';
        rebellionBtn.disabled = true;
    }

    setupOptions.style.display = (activeSidesCount >= 1) ? 'block' : 'none';
    const canStart = activeSidesCount >= 2;
    startBtn.disabled = !canStart;
    startBtn.style.opacity = canStart ? "1" : "0.5";
    startBtn.style.cursor = canStart ? "pointer" : "not-allowed";

    const attackers = sides[0] || [];
    const defenders = sides[1] || [];

    // Find the primary sides to display in the UI stats panel (p1NameDisp/p2NameDisp)
    // If indices 0 and 1 are empty (common in mid-game random wars), look for the first non-empty sides
    let primaryA = attackers;
    let primaryB = defenders;

    if (primaryA.length === 0 || primaryB.length === 0) {
        const activeSideIndices = [];
        sides.forEach((s, i) => { if (s.length > 0) activeSideIndices.push(i); });
        
        if (primaryA.length === 0 && activeSideIndices.length > 0) {
            primaryA = sides[activeSideIndices[0]];
        }
        if (primaryB.length === 0 && activeSideIndices.length > 1) {
            primaryB = sides[activeSideIndices[1]];
        }
    }

    if (primaryA.length > 0) {
        const main = primaryA[0];
        p1NameDisp.innerText = primaryA.length > 1 ? `${main.name} + ${primaryA.length-1}` : main.name;
        p1NameDisp.style.color = main.color.replace(/[\d.]+\)$/g, '1)');
    } else {
        p1NameDisp.innerText = "Side A";
        p1NameDisp.style.color = "#ff4757";
    }
    
    if (primaryB.length > 0) {
        const main = primaryB[0];
        p2NameDisp.innerText = primaryB.length > 1 ? `${main.name} + ${primaryB.length-1}` : main.name;
        p2NameDisp.style.color = main.color.replace(/[\d.]+\)$/g, '1)');
    } else {
        p2NameDisp.innerText = "Side B";
        p2NameDisp.style.color = "#2e86de";
    }
}

addSideBtn.onclick = () => {
    if (sides.length >= 8) {
        alert("Maximum 8 sides supported.");
        return;
    }
    sides.push([]);
    activeSideIndex = sides.length - 1;
    updateSidesUI();
};

ffaToggleBtn.onclick = () => {
    ffaMode = !ffaMode;
    ffaToggleBtn.style.border = ffaMode ? '2px solid #fff' : 'none';
    ffaToggleBtn.innerText = ffaMode ? 'FFA: ON' : 'FFA Mode';
    if (ffaMode) {
        // Explode all countries into their own sides
        const allCountries = sides.flat();
        sides = allCountries.map(c => [c]);
        if (sides.length < 2) sides = [[], []];
        activeSideIndex = 0;
    } else {
        // Group back into 2 sides if FFA turned off
        const allCountries = sides.flat();
        sides = [[], []];
        allCountries.forEach((c, i) => {
            sides[i % 2].push(c);
        });
    }
    updateSidesUI();
};

randomWarBtn.onclick = () => {
    randomWarMode = !randomWarMode;
    randomWarBtn.innerText = randomWarMode ? "Random War: ON" : "Random War: OFF";
    randomWarBtn.style.background = randomWarMode ? "#8e44ad" : "#9b59b6";
    
    if (randomWarMode && (gameState === 'SELECTING_P1' || gameState === 'SELECTING_P2')) {
        triggerRandomWar();
    }
};

function updatePersistentInfluence(p1Count, p2Count, countryToSideMap) {
    let baseInfluence = CONFIG.INFLUENCE_RATE;
    
    // Dynamic optimization: More sides => fewer expensive samples / unit updates
    const optimizationFactor = getOptimizationFactor();
    
    // Mobilization Ramp: Influence starts at 5% and climbs to 100% over 600 frames (~10 seconds)
    const rampDuration = 600;
    const rampScale = Math.min(1.0, 0.05 + (simFrameCount / rampDuration) * 0.95);
    baseInfluence *= rampScale;

    // Boost expansion when unopposed
    if (p1Count > 0 && p2Count === 0) baseInfluence *= 6;
    if (p2Count > 0 && p1Count === 0) baseInfluence *= 6;

    // Optimization: Interleave unit influence updates to prevent frame spikes
    // Each unit only updates its influence 1 in 3 ticks.
    const frameStride = 3;
    const currentTickOffset = simFrameCount % frameStride;

    // Territory Diffusion Pass: Spread occupation laterally to prevent thin "fingers" and jagged borders
    // Increased samples and blur strength to ensure smoother, more solid frontline shapes.
    const smoothingBase = 60000;
    const smoothingSamples = Math.max(5000, Math.floor(smoothingBase / optimizationFactor));
    for (let s = 0; s < smoothingSamples; s++) {
        const idx = Math.floor(Math.random() * landMask.length);
        if (landMask[idx] !== 2) continue;
        
        const y = Math.floor(idx / gridWidth);
        const x = idx % gridWidth;
        if (x <= 0 || x >= gridWidth - 1 || y <= 0 || y >= gridHeight - 1) continue;

        let sum = 0;
        let count = 0;
        for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
                const nIdx = idx + dy * gridWidth + dx;
                if (nIdx >= 0 && nIdx < occupationMap.length) {
                    sum += occupationMap[nIdx];
                    count++;
                }
            }
        }
        
        const blur = 0.25; // Increased from 0.15 for stronger lateral smoothing
        occupationMap[idx] = (occupationMap[idx] * (1 - blur)) + ((sum / count) * blur);
    }

    // Strategic Batching: Process a fixed max number of units per frame for influence
    // This prevents framerate drops when unit counts explode (e.g. 1000+ units)
    const maxUnitsBase = 300;
    const maxUnitsToProcess = Math.max(50, Math.floor(maxUnitsBase / optimizationFactor)); 
    let unitsProcessed = 0;
    
    // Start index rotates through the unit list
    const startIndex = (simFrameCount * 30) % Math.max(1, units.length);

    for (let i = 0; i < units.length; i++) {
        const idx = (startIndex + i) % units.length;
        const u = units[idx];
        if (u.deployTicks > 0) continue;
        
        unitsProcessed++;
        if (unitsProcessed > maxUnitsToProcess) break;

        if (u.deployTicks > 0) continue;
        let r = CONFIG.INFLUENCE_RADIUS;
        let teamMult = 1.0;

        const gridIdx = getGridIndex(u.lat, u.lng);
        const isAtSea = gridIdx === -1 || landMask[gridIdx] === 0;
        const mountainIntensity = (mountainsEnabled && gridIdx !== -1) ? terrainMask[gridIdx] : 0;
        
        // Naval units exert less influence on territory capture than land units
        if (isAtSea) teamMult *= 0.4;

        if (mountainIntensity > 0) {
            // Nerf advancement size (radius) and expansion rate (influence power) in mountains
            // Higher intensity mountains require units to be significantly closer to the border to flip it
            r *= (1.0 - (mountainIntensity * 0.65));
            teamMult *= (1.0 - (mountainIntensity * 0.5));
        }

        const sideList = sides[u.sideIndex] || [];
        const countryObj = sideList.find(c => c.id === u.sovereignId);
        const role = countryObj?.role || 'OFFENSE';
        
        if (countryObj) {
            if (countryObj.buffState === 'buff') teamMult = 2.5;
            else if (countryObj.buffState === 'super') teamMult = 8.0;
            else if (countryObj.buffState === 'godly') { teamMult = 45.0; r *= 0.5; }
            else if (countryObj.buffState === 'weakened') teamMult = 0.7;
            else if (countryObj.buffState === 'crippled') teamMult = 0.4;

            // Apply continuous attack modifier to influence strength as well
            const atkPct = typeof countryObj.attackBuffPercent === 'number' ? countryObj.attackBuffPercent : 0;
            const atkFactor = 1 + (atkPct / 100);
            if (atkFactor > 0) teamMult *= atkFactor;
        }

        if (u.victoryBoostTicks > 0) {
            teamMult *= 3.0; // Buffed influence capture power
            r *= 1.4;        // Increased capture radius
        }

        // Organic Push: Randomize push intensity per unit to create ragged, non-linear salients
        const organicNoise = 0.8 + (Math.sin(u.id * 1000 + simFrameCount * 0.05) * 0.4);
        const delta = (u.team === 'A' ? baseInfluence : -baseInfluence) * teamMult * organicNoise;
        const isTeamA = u.team === 'A';
        const mySide = sides[u.sideIndex];
        
        // Ragged Frontiers: Perturb the influence radius slightly to create "fingers" and "bubbles"
        const rVar = r * (0.9 + Math.sin(u.id * 500 + simFrameCount * 0.1) * 0.2);

        const startLat = Math.max(0, Math.floor((u.lat - rVar + 90) / CONFIG.GRID_RES));
        const endLat = Math.min(gridHeight - 1, Math.floor((u.lat + rVar + 90) / CONFIG.GRID_RES));
        const startLng = Math.max(0, Math.floor((u.lng - rVar + 180) / CONFIG.GRID_RES));
        const endLng = Math.min(gridWidth - 1, Math.floor((u.lng + rVar + 180) / CONFIG.GRID_RES));

        for (let y = startLat; y <= endLat; y++) {
            for (let x = startLng; x <= endLng; x++) {
                const idx = y * gridWidth + x;
                if (idx < 0 || idx >= landMask.length || landMask[idx] === 0) continue;

                // Units claim unclaimed pixels on touch
                if (worldControlMap[idx] === 0) {
                    const cellLat = (y * CONFIG.GRID_RES) - 90;
                    const cellLng = (x * CONFIG.GRID_RES) - 180;
                    const dSq = (u.lat - cellLat) ** 2 + (u.lng - cellLng) ** 2;
                    // Use a tight "touch" radius (~1.2 cells) to claim neutral territory
                    if (dSq < (CONFIG.GRID_RES * CONFIG.GRID_RES * 1.5)) {
                        const creditId = u.beneficiaryId || u.sovereignId;
                        if (creditId > 0) {
                            worldControlMap[idx] = creditId;
                            landMask[idx] = 2; // Activate cell as warzone
                            occupationMap[idx] = (u.team === 'A' ? 1.0 : -1.0);
                            primaryOccupierMap[idx] = creditId;
                            provinceMap[idx] = getProvinceId(x, y, creditId);
                        }
                    }
                    continue;
                }

                if (landMask[idx] !== 2) continue;
                
                // City Resistance: Cells containing cities are much harder for frontlines to pass through
                let cellDelta = delta;
                const cellHasCity = activeTheaterCities.some(c => getGridIndex(c.lat, c.lng) === idx);
                if (cellHasCity) cellDelta *= 0.35;

                const cellLat = (y * CONFIG.GRID_RES) - 90;
                const cellLng = (x * CONFIG.GRID_RES) - 180;
                const dSq = (u.lat - cellLat) ** 2 + (u.lng - cellLng) ** 2;
                if (dSq < rVar * rVar) {
                    const dist = Math.sqrt(dSq);
                    // Strategic Concentration: Units push harder when clustered or in spearheads
                    const concentrationBonus = Math.min(2.5, (u.lastAllyCount || 1) / 5);
                    const weight = Math.pow(1 - dist / rVar, 2.0) * concentrationBonus;
                    
                    let newVal = occupationMap[idx] + cellDelta * weight;
                    if (newVal > 1) newVal = 1;
                    else if (newVal < -1) newVal = -1;

                    // Restriction for rebels: Do not expand influence into land that is not your de jure territory
                    const isRebelUnit = activeRebellion && u.sovereignId === activeRebellion.rebelId;
                    if (isRebelUnit && deJureMap[idx] !== activeRebellion.rebelId) {
                        // Rebels only push borders within their own historical land.
                        // They can defend themselves (delta logic prevents enemy from taking their land),
                        // but they won't push forward into the overlord's core territory.
                        if (u.team === 'A' ? newVal > occupationMap[idx] : newVal < occupationMap[idx]) {
                            newVal = occupationMap[idx];
                        }
                    }
                    
                    const ownerId = worldControlMap[idx];
                    const isOwnerAlly = mySide.some(c => c.id === ownerId);
                    
                    // If owner is a SUPPORT nation on the other side and we are OFFENSE, don't invade (skip influence)
                    // unless we already have established some occupation in that cell.
                    if (!isOwnerAlly && ownerId > 0 && role === 'OFFENSE') {
                        const ownerSideIdx = countryToSideMap.get(ownerId);
                        if (ownerSideIdx !== undefined && (ownerSideIdx % 2 !== u.sideIndex % 2)) {
                            const ownerObj = sides[ownerSideIdx].find(c => c.id === ownerId);
                            if (ownerObj?.role === 'SUPPORT') {
                                const occ = occupationMap[idx];
                                const isAlreadyInvaded = (isTeamA && occ > 0.1) || (!isTeamA && occ < -0.1);
                                if (!isAlreadyInvaded) continue;
                            }
                        }
                    }

                    const currentOccupierId = primaryOccupierMap[idx];
                    const oldVal = occupationMap[idx];
                    
                    if (!isOwnerAlly) {
                        // Support System: Use beneficiaryId instead of sovereignId for land credit
                        const creditToId = u.beneficiaryId || u.sovereignId;
                        
                        // Prevent flickering between allies:
                        // Only update the occupier tag if the cell is neutral or occupied by an enemy.
                        const currentOccSideIdx = countryToSideMap.get(currentOccupierId);
                        const isCurrentOccAlly = currentOccSideIdx !== undefined && (currentOccSideIdx % 2 === u.sideIndex % 2);

                        if (!isCurrentOccAlly) {
                            // AGGRESSIVE ALLIED CONSOLIDATION:
                            // To prevent border gore, we force units to expand existing allied fronts 
                            // rather than creating many tiny isolated pixels of their own color.
                            const counts = new Map();
                            const checkDirs = [[0,1],[0,-1],[1,0],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]];
                            for (const [dx, dy] of checkDirs) {
                                const nx = x + dx; const ny = y + dy;
                                if (nx >= 0 && nx < gridWidth && ny >= 0 && ny < gridHeight) {
                                    const nId = primaryOccupierMap[ny * gridWidth + nx];
                                    const nSide = countryToSideMap.get(nId);
                                    if (nId > 0 && nSide !== undefined && (nSide % 2 === u.sideIndex % 2)) {
                                        counts.set(nId, (counts.get(nId) || 0) + 1);
                                    }
                                }
                            }

                            let bestAllyId = 0;
                            let maxCount = 0;
                            counts.forEach((count, id) => {
                                // If a neighboring ally has 3 or more adjacent cells, they take the "credit"
                                // for this expansion to keep the map color-blocks contiguous.
                                if (count > maxCount && count >= 3) { maxCount = count; bestAllyId = id; }
                            });
                            
                            const finalCreditId = bestAllyId || creditToId;

                            // Restriction: Rebels cannot get land credit outside their de jure territory
                            const isRebelFinalCredit = activeRebellion && finalCreditId === activeRebellion.rebelId;
                            const canReceiveCredit = !isRebelFinalCredit || deJureMap[idx] === activeRebellion.rebelId;

                            if (canReceiveCredit) {
                                if (isTeamA && (newVal > oldVal) && (newVal >= 0.05 || currentOccupierId === 0)) {
                                    primaryOccupierMap[idx] = finalCreditId;
                                } else if (!isTeamA && (newVal < oldVal) && (newVal <= -0.05 || currentOccupierId === 0)) {
                                    primaryOccupierMap[idx] = finalCreditId;
                                }
                            }
                        }
                    }
                    
                    occupationMap[idx] = newVal;
                }
            }
        }
    }
}

/**
 * Simple Point-In-Polygon check for GeoJSON features
 */
function isPointInFeature(lat, lng, feature) {
    const point = [lng, lat];
    const type = feature.geometry.type;
    const coords = feature.geometry.coordinates;

    const isPointInRing = (ring, pt) => {
        let inside = false;
        for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
            const xi = ring[i][0], yi = ring[i][1];
            const xj = ring[j][0], yj = ring[j][1];
            const intersect = ((yi > pt[1]) !== (yj > pt[1])) &&
                (pt[0] < (xj - xi) * (pt[1] - yi) / (yj - yi) + xi);
            if (intersect) inside = !inside;
        }
        return inside;
    };

    const checkPolygon = (polygon, pt) => {
        // Exterior ring
        if (!isPointInRing(polygon[0], pt)) return false;
        // Interior holes
        for (let i = 1; i < polygon.length; i++) {
            if (isPointInRing(polygon[i], pt)) return false;
        }
        return true;
    };

    if (type === 'Polygon') {
        return checkPolygon(coords, point);
    } else if (type === 'MultiPolygon') {
        return coords.some(part => checkPolygon(part, point));
    }
    return false;
}

async function updateLandMask(features, maskValue = 1, isBlank = false) {
    isCustomTerrain = isBlank;
    if (!isBlank) {
        countryMetadata = features.map((f, i) => {
            const color = getCountryColor(f);
            const name = f.properties.NAME || f.properties.name || f.properties.admin || f.properties.NAME_LONG || "Unknown";
            
            const getCode = (feat) => {
                if (!feat || !feat.properties) return null;
                const p = feat.properties;
                let code = p.ISO_A2 || p.iso_a2 || p.ISO_A2_EH || p.iso_a2_eh || p.ADDR_A2 || null;
                if (code === "-99") return null;
                return code;
            };

            const code = findCodeByName(name) || getCode(f);
            return {
                id: i + 1,
                name: name,
                feature: f,
                color: color,
                rgba: parseColorToRGBA(color),
                flagUrl: getFlagUrl(code, name),
                bounds: { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity }
            };
        });
    } else {
        countryMetadata = [];
    }

    const total = features.length;
    for (let i = 0; i < features.length; i++) {
        const feature = features[i];
        const id = i + 1;
        
        // Update loading UI every 10 countries to keep it responsive
        if (i % 10 === 0) {
            const percent = Math.floor((i / total) * 100);
            if (loadingBar) loadingBar.style.width = `${percent}%`;
            if (loadingStatus) loadingStatus.innerText = isBlank ? `Scanning Landmasses: ${percent}%` : `Mapping Borders: ${percent}%`;
            // Brief pause to allow UI update
            await new Promise(resolve => setTimeout(resolve, 0));
        }

        const bounds = L.geoJSON(feature).getBounds();
        const startLat = Math.max(0, Math.floor((bounds.getSouth() + 90) / CONFIG.GRID_RES));
        const endLat = Math.min(gridHeight - 1, Math.ceil((bounds.getNorth() + 90) / CONFIG.GRID_RES));
        const startLng = Math.max(0, Math.floor((bounds.getWest() + 180) / CONFIG.GRID_RES));
        const endLng = Math.min(gridWidth - 1, Math.ceil((bounds.getEast() + 180) / CONFIG.GRID_RES));

        for (let y = startLat; y <= endLat; y++) {
            for (let x = startLng; x <= endLng; x++) {
                const lat = (y * CONFIG.GRID_RES) - 90 + (CONFIG.GRID_RES * 0.5);
                const lng = (x * CONFIG.GRID_RES) - 180 + (CONFIG.GRID_RES * 0.5);
                if (isPointInFeature(lat, lng, feature)) {
                    const idx = y * gridWidth + x;
                    if (idx >= 0 && idx < landMask.length) {
                        landMask[idx] = maskValue;
                        // Always populate De Jure map as a historical reference for rebellions, even in "blank" editor mode
                        deJureMap[idx] = id;
                        if (!isBlank) {
                            worldControlMap[idx] = id;
                            const meta = countryMetadata[id - 1];
                            if (meta) {
                                meta.bounds.minX = Math.min(meta.bounds.minX, x);
                                meta.bounds.maxX = Math.max(meta.bounds.maxX, x);
                                meta.bounds.minY = Math.min(meta.bounds.minY, y);
                                meta.bounds.maxY = Math.max(meta.bounds.maxY, y);
                            }
                        }
                    }
                }
            }
        }
    }
    
    if (loadingBar) loadingBar.style.width = `100%`;
    if (loadingStatus) loadingStatus.innerText = `Optimization Complete`;

    // Automatically apply desert biomes to Earth-based scenarios for visual depth in Simple Mode
    if (!isCustomTerrain) {
        applyEarthDeserts();
    }
}

/**
 * Procedurally generates desert biomes based on known global geographical coordinates.
 * This provides visual variety in 'Simplified Mode' for real-earth scenarios.
 */
function applyEarthDeserts() {
    if (!biomeMask) return;
    
    // Bounding boxes for major global deserts
    const deserts = [
        { lat: [14, 31], lng: [-17, 35] },   // Sahara
        { lat: [12, 32], lng: [35, 59] },    // Arabian
        { lat: [36, 48], lng: [75, 115] },   // Gobi / Taklamakan
        { lat: [-34, -18], lng: [114, 150] },// Australian Outback
        { lat: [-30, -18], lng: [14, 28] },  // Kalahari / Namib
        { lat: [23, 37], lng: [-118, -102] },// Mojave / Sonoran / Chihuahuan
        { lat: [-27, -15], lng: [-72, -66] }, // Atacama
        { lat: [24, 32], lng: [68, 77] },    // Thar
        { lat: [35, 45], lng: [52, 72] }     // Central Asian (Kyzylkum/Kara-Kum)
    ];

    for (let i = 0; i < landMask.length; i++) {
        if (landMask[i] === 0) continue; 

        const y = Math.floor(i / gridWidth);
        const x = i % gridWidth;
        const lat = (y * CONFIG.GRID_RES) - 90;
        const lng = (x * CONFIG.GRID_RES) - 180;

        for (const d of deserts) {
            if (lat >= d.lat[0] && lat <= d.lat[1] && lng >= d.lng[0] && lng <= d.lng[1]) {
                // Apply a sinus-based noise threshold to prevent perfectly rectangular deserts
                const n = Math.sin(lat * 3.5) * Math.cos(lng * 3.5);
                if (n > -0.85) { 
                    biomeMask[i] = 1;
                }
                break;
            }
        }
    }
}

function prepareTheater(feature, team, forcedId = null) {
    // Legacy function - logic integrated into optimized startWar pass
    return;
    const isTeamA = team === 'A';
    const targetVal = isTeamA ? 1.0 : -1.0;
    
    let meta = null;
    let sovereignId = forcedId;
    
    if (sovereignId === null) {
        if (feature) {
            sovereignId = countryMetadata.findIndex(m => m.feature === feature) + 1;
            meta = countryMetadata[sovereignId - 1];
        } else {
            sovereignId = isTeamA ? teamAId : -1;
            meta = countryMetadata[sovereignId - 1];
        }
    }

    let startLat = 0, endLat = gridHeight - 1, startLng = 0, endLng = gridWidth - 1;
    
    if (feature || meta?.feature) {
        const bounds = L.geoJSON(feature || meta.feature).getBounds();
        const res = CONFIG.GRID_RES;
        startLat = Math.max(0, Math.floor((bounds.getSouth() + 90) / res));
        endLat = Math.min(gridHeight - 1, Math.ceil((bounds.getNorth() + 90) / res));
        startLng = Math.max(0, Math.floor((bounds.getWest() + 180) / res));
        endLng = Math.min(gridWidth - 1, Math.ceil((bounds.getEast() + 180) / res));
    }

    const seeds = [];
    for (let y = startLat; y <= endLat; y++) {
        for (let x = startLng; x <= endLng; x++) {
            const idx = y * gridWidth + x;
            if (idx < 0 || idx >= landMask.length) continue;
            if (worldControlMap[idx] === sovereignId) {
                landMask[idx] = 2;
                occupationMap[idx] = targetVal;
                primaryOccupierMap[idx] = sovereignId;
                seeds.push({x, y});
            }
        }
    }

    if (seeds.length > 0) {
        const queue = [...seeds];
        const visited = new Uint8Array(gridWidth * gridHeight);
        seeds.forEach(s => visited[s.y * gridWidth + s.x] = 1);
        while (queue.length > 0) {
            const {x, y} = queue.shift();
            for (const {nx, ny} of [{nx:x+1,ny:y}, {nx:x-1,ny:y}, {nx:x,ny:y+1}, {nx:x,ny:y-1}]) {
                if (nx < 0 || nx >= gridWidth || ny < 0 || ny >= gridHeight) continue;
                const nIdx = ny * gridWidth + nx;
                if (!visited[nIdx] && worldControlMap[nIdx] === sovereignId) {
                    visited[nIdx] = 1;
                    landMask[nIdx] = 2;
                    occupationMap[nIdx] = targetVal;
                    primaryOccupierMap[nIdx] = sovereignId;
                    queue.push({x: nx, y: ny});
                }
            }
        }
    }
}

async function loadTerrain(res) {
    try {
        loadingStatus.innerText = "Scanning Topography...";
        // Fallback to 50m if 10m is selected for physical features, as 10m physical data is often missing/split differently
        const terrainRes = res === '110m' ? '110m' : '50m';
        const terrainUrl = `${CONFIG.GEOJSON_BASE}${terrainRes}/physical/ne_${terrainRes}_geography_regions_polys.json`;
        const response = await fetch(terrainUrl);
        const data = await response.json();
        
        const features = data.features;
        const mountains = [];
        const lowlands = [];

        features.forEach(f => {
            const p = f.properties;
            const name = (p.name || p.name_en || "").toLowerCase();
            const type = (p.featurecla || "").toLowerCase();
            
            const isMt = type.includes('mountain') || 
                         type.includes('range') ||
                         name.includes('mountain') || 
                         name.includes('alps') || 
                         name.includes('himalaya') || 
                         name.includes('karakoram') ||
                         name.includes('kunlun') ||
                         name.includes('pamir') ||
                         name.includes('tibet') ||
                         name.includes('hindu kush') ||
                         name.includes('tian shan') ||
                         name.includes('andes') ||
                         name.includes('rockies') ||
                         name.includes('carpathian') ||
                         name.includes('caucasus') ||
                         name.includes('atlas') ||
                         name.includes('pyrenees');

            // Categorize basins and depressions as lowlands to act as "holes" in larger mountain ranges
            const isLow = name.includes('basin') || 
                          name.includes('depression') || 
                          name.includes('plain') || 
                          name.includes('lowland') || 
                          name.includes('valley') ||
                          name.includes('transylvania') ||
                          name.includes('pannonian') ||
                          name.includes('carpathian basin');

            if (isMt) mountains.push(f);
            if (isLow) lowlands.push(f);
        });

        terrainMask.fill(0);
        
        // Pass 1: Draw Mountains
        const totalMt = mountains.length;
        for (let i = 0; i < totalMt; i++) {
            if (i % 10 === 0) {
                const pct = Math.floor((i / totalMt) * 80);
                loadingBar.style.width = `${pct}%`;
                loadingStatus.innerText = `Mapping Rugged Peaks: ${pct}%`;
                await new Promise(r => setTimeout(r, 0));
            }
            
            const feature = mountains[i];
            const bounds = L.geoJSON(feature).getBounds();
            const sLat = Math.max(0, Math.floor((bounds.getSouth() + 90) / CONFIG.GRID_RES));
            const eLat = Math.min(gridHeight - 1, Math.ceil((bounds.getNorth() + 90) / CONFIG.GRID_RES));
            const sLng = Math.max(0, Math.floor((bounds.getWest() + 180) / CONFIG.GRID_RES));
            const eLng = Math.min(gridWidth - 1, Math.ceil((bounds.getEast() + 180) / CONFIG.GRID_RES));

            for (let y = sLat; y <= eLat; y++) {
                for (let x = sLng; x <= eLng; x++) {
                    const lat = (y * CONFIG.GRID_RES) - 90;
                    const lng = (x * CONFIG.GRID_RES) - 180;
                    if (isPointInFeature(lat, lng, feature)) {
                        const idx = y * gridWidth + x;
                        if (idx >= 0 && idx < terrainMask.length) {
                            const rank = feature.properties.scalerank || 5;
                            const intensity = Math.max(0.3, (11 - rank) / 10); 
                            terrainMask[idx] = Math.max(terrainMask[idx], intensity);
                        }
                    }
                }
            }
        }

        // Pass 2: Clear Lowlands (Holes in ranges like the Transylvanian Depression)
        const totalLow = lowlands.length;
        for (let i = 0; i < totalLow; i++) {
            const feature = lowlands[i];
            const bounds = L.geoJSON(feature).getBounds();
            const sLat = Math.max(0, Math.floor((bounds.getSouth() + 90) / CONFIG.GRID_RES));
            const eLat = Math.min(gridHeight - 1, Math.ceil((bounds.getNorth() + 90) / CONFIG.GRID_RES));
            const sLng = Math.max(0, Math.floor((bounds.getWest() + 180) / CONFIG.GRID_RES));
            const eLng = Math.min(gridWidth - 1, Math.ceil((bounds.getEast() + 180) / CONFIG.GRID_RES));

            for (let y = sLat; y <= eLat; y++) {
                for (let x = sLng; x <= eLng; x++) {
                    const lat = (y * CONFIG.GRID_RES) - 90;
                    const lng = (x * CONFIG.GRID_RES) - 180;
                    if (isPointInFeature(lat, lng, feature)) {
                        const idx = y * gridWidth + x;
                        if (idx >= 0 && idx < terrainMask.length) {
                            // Set mountain intensity to 0 for identified basins/lowlands
                            terrainMask[idx] = 0;
                        }
                    }
                }
            }
        }
    } catch (e) {
        console.warn("Failed to load terrain data", e);
    }
}

async function loadFlagCodes() {
    if (flagCodes) return;
    try {
        const resp = await fetch('https://flagcdn.com/en/codes.json');
        flagCodes = await resp.json();
    } catch (e) {
        console.error("Failed to load flag codes", e);
    }
}

const FLAG_CDN_MAPPING = {
    "ad": "Andorra",
    "ae": "United Arab Emirates",
    "af": "Afghanistan",
    "ag": "Antigua and Barbuda",
    "ai": "Anguilla",
    "al": "Albania",
    "am": "Armenia",
    "ao": "Angola",
    "aq": "Antarctica",
    "ar": "Argentina",
    "as": "American Samoa",
    "at": "Austria",
    "au": "Australia",
    "aw": "Aruba",
    "ax": "Åland Islands",
    "az": "Azerbaijan",
    "ba": "Bosnia and Herzegovina",
    "bb": "Barbados",
    "bd": "Bangladesh",
    "be": "Belgium",
    "bf": "Burkina Faso",
    "bg": "Bulgaria",
    "bh": "Bahrain",
    "bi": "Burundi",
    "bj": "Benin",
    "bl": "Saint Barthélemy",
    "bm": "Bermuda",
    "bn": "Brunei",
    "bo": "Bolivia",
    "bq": "Caribbean Netherlands",
    "br": "Brazil",
    "bs": "Bahamas",
    "bt": "Bhutan",
    "bv": "Bouvet Island",
    "bw": "Botswana",
    "by": "Belarus",
    "bz": "Belize",
    "ca": "Canada",
    "cc": "Cocos (Keeling) Islands",
    "cd": "DR Congo",
    "cf": "Central African Republic",
    "cg": "Republic of the Congo",
    "ch": "Switzerland",
    "ci": "Côte d'Ivoire (Ivory Coast)",
    "ck": "Cook Islands",
    "cl": "Chile",
    "cm": "Cameroon",
    "cn": "China",
    "co": "Colombia",
    "cr": "Costa Rica",
    "cu": "Cuba",
    "cv": "Cape Verde",
    "cw": "Curaçao",
    "cx": "Christmas Island",
    "cy": "Cyprus",
    "cz": "Czechia",
    "de": "Germany",
    "dj": "Djibouti",
    "dk": "Denmark",
    "dm": "Dominica",
    "do": "Dominican Republic",
    "dz": "Algeria",
    "ec": "Ecuador",
    "ee": "Estonia",
    "eg": "Egypt",
    "eh": "Western Sahara",
    "er": "Eritrea",
    "es": "Spain",
    "et": "Ethiopia",
    "eu": "European Union",
    "fi": "Finland",
    "fj": "Fiji",
    "fk": "Falkland Islands",
    "fm": "Micronesia",
    "fo": "Faroe Islands",
    "fr": "France",
    "ga": "Gabon",
    "gb": "United Kingdom",
    "gb-eng": "England",
    "gb-nir": "Northern Ireland",
    "gb-sct": "Scotland",
    "gb-wls": "Wales",
    "gd": "Grenada",
    "ge": "Georgia",
    "gf": "French Guiana",
    "gg": "Guernsey",
    "gh": "Ghana",
    "gi": "Gibraltar",
    "gl": "Greenland",
    "gm": "Gambia",
    "gn": "Guinea",
    "gp": "Guadeloupe",
    "gq": "Equatorial Guinea",
    "gr": "Greece",
    "gs": "South Georgia",
    "gt": "Guatemala",
    "gu": "Guam",
    "gw": "Guinea-Bissau",
    "gy": "Guyana",
    "hk": "Hong Kong",
    "hm": "Heard Island and McDonald Islands",
    "hn": "Honduras",
    "hr": "Croatia",
    "ht": "Haiti",
    "hu": "Hungary",
    "id": "Indonesia",
    "ie": "Ireland",
    "il": "Israel",
    "im": "Isle of Man",
    "in": "India",
    "io": "British Indian Ocean Territory",
    "iq": "Iraq",
    "ir": "Iran",
    "is": "Iceland",
    "it": "Italy",
    "je": "Jersey",
    "jm": "Jamaica",
    "jo": "Jordan",
    "jp": "Japan",
    "ke": "Kenya",
    "kg": "Kyrgyzstan",
    "kh": "Cambodia",
    "ki": "Kiribati",
    "km": "Comoros",
    "kn": "Saint Kitts and Nevis",
    "kp": "North Korea",
    "kr": "South Korea",
    "kw": "Kuwait",
    "ky": "Cayman Islands",
    "kz": "Kazakhstan",
    "la": "Laos",
    "lb": "Lebanon",
    "lc": "Saint Lucia",
    "li": "Liechtenstein",
    "lk": "Sri Lanka",
    "lr": "Liberia",
    "ls": "Lesotho",
    "lt": "Lithuania",
    "lu": "Luxembourg",
    "lv": "Latvia",
    "ly": "Libya",
    "ma": "Morocco",
    "mc": "Monaco",
    "md": "Moldova",
    "me": "Montenegro",
    "mf": "Saint Martin",
    "mg": "Madagascar",
    "mh": "Marshall Islands",
    "mk": "North Macedonia",
    "ml": "Mali",
    "mm": "Myanmar",
    "mn": "Mongolia",
    "mo": "Macau",
    "mp": "Northern Mariana Islands",
    "mq": "Martinique",
    "mr": "Mauritania",
    "ms": "Montserrat",
    "mt": "Malta",
    "mu": "Mauritius",
    "mv": "Maldives",
    "mw": "Malawi",
    "mx": "Mexico",
    "my": "Malaysia",
    "mz": "Mozambique",
    "na": "Namibia",
    "nc": "New Caledonia",
    "ne": "Niger",
    "nf": "Norfolk Island",
    "ng": "Nigeria",
    "ni": "Nicaragua",
    "nl": "Netherlands",
    "no": "Norway",
    "np": "Nepal",
    "nr": "Nauru",
    "nu": "Niue",
    "nz": "New Zealand",
    "om": "Oman",
    "pa": "Panama",
    "pe": "Peru",
    "pf": "French Polynesia",
    "pg": "Papua New Guinea",
    "ph": "Philippines",
    "pk": "Pakistan",
    "pl": "Poland",
    "pm": "Saint Pierre and Miquelon",
    "pn": "Pitcairn Islands",
    "pr": "Puerto Rico",
    "ps": "Palestine",
    "pt": "Portugal",
    "pw": "Palau",
    "py": "Paraguay",
    "qa": "Qatar",
    "re": "Réunion",
    "ro": "Romania",
    "rs": "Serbia",
    "ru": "Russia",
    "rw": "Rwanda",
    "sa": "Saudi Arabia",
    "sb": "Solomon Islands",
    "sc": "Seychelles",
    "sd": "Sudan",
    "se": "Sweden",
    "sg": "Singapore",
    "sh": "Saint Helena, Ascension and Tristan da Cunha",
    "si": "Slovenia",
    "sj": "Svalbard and Jan Mayen",
    "sk": "Slovakia",
    "sl": "Sierra Leone",
    "sm": "San Marino",
    "sn": "Senegal",
    "so": "Somalia",
    "sr": "Suriname",
    "ss": "South Sudan",
    "st": "São Tomé and Príncipe",
    "sv": "El Salvador",
    "sx": "Sint Maarten",
    "sy": "Syria",
    "sz": "Eswatini (Swaziland)",
    "tc": "Turks and Caicos Islands",
    "td": "Chad",
    "tf": "French Southern and Antarctic Lands",
    "tg": "Togo",
    "th": "Thailand",
    "tj": "Tajikistan",
    "tk": "Tokelau",
    "tl": "Timor-Leste",
    "tm": "Turkmenistan",
    "tn": "Tunisia",
    "to": "Tonga",
    "tr": "Turkey",
    "tt": "Trinidad and Tobago",
    "tv": "Tuvalu",
    "tw": "Taiwan",
    "tz": "Tanzania",
    "ua": "Ukraine",
    "ug": "Uganda",
    "um": "United States Minor Outlying Islands",
    "un": "United Nations",
    "us": "United States",
    "us-ak": "Alaska",
    "us-al": "Alabama",
    "us-ar": "Arkansas",
    "us-az": "Arizona",
    "us-ca": "California",
    "us-co": "Colorado",
    "us-ct": "Connecticut",
    "us-de": "Delaware",
    "us-fl": "Florida",
    "us-ga": "Georgia",
    "us-hi": "Hawaii",
    "us-ia": "Iowa",
    "us-id": "Idaho",
    "us-il": "Illinois",
    "us-in": "Indiana",
    "us-ks": "Kansas",
    "us-ky": "Kentucky",
    "us-la": "Louisiana",
    "us-ma": "Massachusetts",
    "us-md": "Maryland",
    "us-me": "Maine",
    "us-mi": "Michigan",
    "us-mn": "Minnesota",
    "us-mo": "Missouri",
    "us-ms": "Mississippi",
    "us-mt": "Montana",
    "us-nc": "North Carolina",
    "us-nd": "North Dakota",
    "us-ne": "Nebraska",
    "us-nh": "New Hampshire",
    "us-nj": "New Jersey",
    "us-nm": "New Mexico",
    "us-nv": "Nevada",
    "us-ny": "New York",
    "us-oh": "Ohio",
    "us-ok": "Oklahoma",
    "us-or": "Oregon",
    "us-pa": "Pennsylvania",
    "us-ri": "Rhode Island",
    "us-sc": "South Carolina",
    "us-sd": "South Dakota",
    "us-tn": "Tennessee",
    "us-tx": "Texas",
    "us-ut": "Utah",
    "us-va": "Virginia",
    "us-vt": "Vermont",
    "us-wa": "Washington",
    "us-wi": "Wisconsin",
    "us-wv": "West Virginia",
    "us-wy": "Wyoming",
    "uy": "Uruguay",
    "uz": "Uzbekistan",
    "va": "Vatican City (Holy See)",
    "vc": "Saint Vincent and the Grenadines",
    "ve": "Venezuela",
    "vg": "British Virgin Islands",
    "vi": "United States Virgin Islands",
    "vn": "Vietnam",
    "vu": "Vanuatu",
    "wf": "Wallis and Futuna",
    "ws": "Samoa",
    "xk": "Kosovo",
    "ye": "Yemen",
    "yt": "Mayotte",
    "za": "South Africa",
    "zm": "Zambia",
    "zw": "Zimbabwe"
};

function findCodeByName(name) {
    if (!name) return null;
    const search = name.toLowerCase().trim();
    
    // Check comprehensive static mapping first
    for (const [code, fullName] of Object.entries(FLAG_CDN_MAPPING)) {
        if (fullName.toLowerCase() === search) return code;
    }

    // Then check dynamically fetched codes if available
    if (flagCodes) {
        for (const [code, fullName] of Object.entries(flagCodes)) {
            if (fullName.toLowerCase() === search) return code;
        }
    }
    
    // Also check for common aliases or shortened names
    const aliases = {
        "united states": "us",
        "united states of america": "us",
        "russia": "ru",
        "russian federation": "ru",
        "soviet union": "ru",
        "united kingdom": "gb",
        "great britain": "gb",
        "britain": "gb",
        "south korea": "kr",
        "north korea": "kp",
        "vietnam": "vn",
        "iran": "ir",
        "syria": "sy",
        "czech republic": "cz",
        "ivory coast": "ci",
        "republic of the congo": "cg",
        "democratic republic of the congo": "cd",
        "congo, republic of the": "cg",
        "congo, democratic republic of the": "cd",
        "czechia": "cz",
        "eswatini": "sz",
        "swaziland": "sz"
    };
    return aliases[search] || null;
}

async function loadCities() {
    try {
        // Upgrade to 50m resolution for a significantly higher city count (thousands vs hundreds)
        const response = await fetch('https://raw.githubusercontent.com/martynafford/natural-earth-geojson/master/50m/cultural/ne_50m_populated_places_simple.json');
        const data = await response.json();
        cities = data.features.map((f, idx) => ({
            id: idx + 1,
            name: f.properties.name || f.properties.NAME || "City",
            lat: f.geometry.coordinates[1],
            lng: f.geometry.coordinates[0],
            pop: f.properties.pop_max || 0,
            isCapital: f.properties.adm0cap === 1,
            ownerId: null,
            isCustom: false
        }));

        // Apply historical renames for the 1936 WW2 scenario
        if (currentScenarioContext && (currentScenarioContext.id === 'ww2_1936')) {
            cities.forEach(city => {
                if (city.name === 'Kaliningrad') {
                    city.name = 'Koenisberg';
                }
                if (city.name === 'Gdańsk' || city.name === 'Gdansk') {
                    city.name = 'Danzig';
                }
            });
        }
    } catch (err) {
        console.error("Failed to load cities", err);
    }
}

async function loadCountries(url, isBlank = false, suppressUi = false) {
    try {
        if (!suppressUi) {
            loadingOverlay.style.display = 'flex';
            mapUi.style.display = 'none';
            mainMenu.style.display = 'none';
        }
        loadingStatus.innerText = "Downloading GeoData...";
        loadingBar.style.width = "10%";
        
        await Promise.all([loadCities(), loadFlagCodes()]);
        loadingBar.style.width = "20%";
        loadingTip.innerText = "Refining city coordinates for strategic deployment...";
        
        const response = await fetch(url);
        const data = await response.json();
        rawGeoJsonData = data;
        loadingBar.style.width = "30%";
        loadingStatus.innerText = isBlank ? "Acquiring Topography..." : "Processing Geopolitics...";
        
        // Static countriesLayer removed to prevent outlines of annexed nations from persisting.
        // Borders and coastlines are now entirely handled by the dynamic canvas overlay.

        // Pre-compute basic landmask for better performance
        loadingTip.innerText = isBlank ? "Cleaning political data..." : "Calculating terrain influence grids...";
        await updateLandMask(data.features, 1, isBlank);
        
        // Generate provinces after landmask is set and worldControlMap is populated
        generateProvinces();

        // Generate initial country centers and label data
        recalculateAllBounds();

        // Reset adjacency cache
        adjacencyCache = null;

        // Capture Instant Quick Restart Snapshots for the base map load
        if (worldControlMap) {
            initialWorldControlMapSnapshot = new Int32Array(worldControlMap);
            initialDeJureMapSnapshot = new Int32Array(deJureMap);
            initialProvinceMapSnapshot = new Int32Array(provinceMap);
            initialLandMaskSnapshot = new Uint8Array(landMask);
            initialCountryMetadataSnapshot = deepClone(countryMetadata);
            initialCitiesSnapshot = deepClone(cities);
        }

        // Load and rasterize mountain terrain
        if (mountainsEnabled) {
            const currentMapRes = document.getElementById('map-res-select').value;
            await loadTerrain(currentMapRes);
        } else {
            terrainMask.fill(0);
        }
        
        if (!suppressUi) {
            // Brief delay for visual confirmation
            setTimeout(() => {
                loadingOverlay.style.display = 'none';
                mapUi.style.display = 'flex';
            }, 500);
        }
        
    } catch (err) {
        console.error("Failed to load geojson", err);
        loadingStatus.innerText = "Error Loading Assets";
        loadingStatus.style.color = "#ff4757";
    }
}

function handleCountryClick(feature, layer, latlng, originalEvent = null) {
    const idx = getGridIndex(latlng.lat, latlng.lng);

    const isCtrlClick = !!(originalEvent && (originalEvent.ctrlKey || originalEvent.metaKey));
    if (gameState === 'EDITOR_PLACING') {
        placeNewCountry(latlng);
        return;
    }

    if (gameState === 'EDITOR_PAINTING_TERRAIN') {
        // paintAt already handles the actual landMask modification via mousedown/mousemove
        return;
    }

    if (gameState === 'EDITOR_PLACING_DIVISION') {
        const countryIdAtClick = idx !== -1 ? worldControlMap[idx] : 0;
        if (editingCountryId <= 0) {
            if (countryIdAtClick > 0) {
                editingCountryId = countryIdAtClick;
                const meta = countryMetadata[editingCountryId - 1];
                statusText.innerText = `DEPLOYMENT: ${meta.name} (Click map to deploy divisions)`;
            } else {
                statusText.innerText = "SELECT SOURCE: Click a nation on the map first";
            }
        } else {
            placeDivisionAt(latlng, editingCountryId);
        }
        return;
    }

    if (gameState === 'EDITOR_ANNEXING') {
        const targetId = idx !== -1 ? worldControlMap[idx] : 0;
        if (targetId > 0 && targetId !== editingCountryId) {
            const victimMeta = countryMetadata[targetId - 1];
            const victimName = victimMeta ? victimMeta.name : "Target";
            
            // RELEASABLE TRANSFER: Transfer victim's releasables to the annexer
            countryMetadata.forEach(m => {
                if (m && m.releasableBy === targetId) {
                    m.releasableBy = editingCountryId;
                }
            });

            // Transfer all territory
            for (let i = 0; i < worldControlMap.length; i++) {
                if (worldControlMap[i] === targetId) {
                    worldControlMap[i] = editingCountryId;
                }
            }
            
            // Clean up live simulation data for the victim
            sides.forEach(side => {
                const sIdx = side.findIndex(c => c.id === targetId);
                if (sIdx > -1) side.splice(sIdx, 1);
            });
            units = units.filter(u => u.sovereignId !== targetId);

            statusText.innerText = `ANNEXED: ${victimName} absorbed.`;
            recalculateAllBounds();
            influenceLayer.render();
            updateSidesUI();
            
            // Return to inspector
            openInspector(editingCountryId);
            gameState = 'EDITOR_ACTIVE';
            map.getContainer().classList.remove('painting-cursor');
        } else {
            statusText.innerText = "Selection Cancelled: Clicked neutral land or self.";
            openInspector(editingCountryId);
            gameState = 'EDITOR_ACTIVE';
            map.getContainer().classList.remove('painting-cursor');
        }
        return;
    }

    if (gameState === 'EDITOR_SELECTING_OVERLORD') {
        const sovereignId = idx !== -1 ? worldControlMap[idx] : 0;
        if (sovereignId > 0 && sovereignId !== selectingOverlordForId) {
            setVassalage(selectingOverlordForId, sovereignId);
        } else {
            statusText.innerText = "Selection Cancelled";
        }
        gameState = godModeActive ? 'EDITOR_ACTIVE' : 'EDITOR_ACTIVE'; 
        if (godModeActive) gameState = 'EDITOR_ACTIVE'; 
        selectingOverlordForId = -1;
        map.getContainer().classList.remove('painting-cursor');
        return;
    }

    if (gameState === 'EDITOR_SELECTING_RELEASER') {
        const sovereignId = idx !== -1 ? worldControlMap[idx] : 0;
        if (sovereignId > 0 && sovereignId !== selectingOverlordForId) {
            setAsReleasable(selectingOverlordForId, sovereignId);
        } else {
            statusText.innerText = "Selection Cancelled";
        }
        gameState = 'EDITOR_ACTIVE';
        selectingOverlordForId = -1;
        map.getContainer().classList.remove('painting-cursor');
        return;
    }

    if (idx === -1) return;
    
    let sovereignId = worldControlMap[idx];

    // Ctrl-click multi-select support in editor / god mode
    if (isCtrlClick && sovereignId > 0 && (gameMode === 'EDITOR' || godModeActive)) {
        if (selectedCountryIds.has(sovereignId)) {
            selectedCountryIds.delete(sovereignId);
        } else {
            selectedCountryIds.add(sovereignId);
        }
        const count = selectedCountryIds.size;
        statusText.innerText = count > 0
            ? `Selected ${count} countr${count === 1 ? 'y' : 'ies'} for ZIP export`
            : "Map Editor (Alpha)";
        // Keep normal inspector / setup logic from running on Ctrl-click
        influenceLayer.render();
        return;
    }
    
    // In God Mode or Simulation, clicking occupied land selects the current occupier
    if (gameState === 'SIMULATING' || godModeActive) {
        const occ = occupationMap[idx];
        if (landMask[idx] === 2 && Math.abs(occ) > 0.1) {
            const occupierId = primaryOccupierMap[idx];
            if (occupierId > 0) sovereignId = occupierId;
        }
    }

    if (gameState === 'PEACE_SELECT_1') {
        if (sovereignId > 0) {
            const sideCountry = sides.flat().filter(Boolean).find(c => c.id === sovereignId);
            if (sideCountry) {
                peaceSelection1 = sideCountry;
                gameState = 'PEACE_SELECT_2';
                statusText.innerText = `Peace for ${sideCountry.name}: Select Opponent`;
                influenceLayer.render();
            }
        }
        return;
    }

    if (gameState === 'PEACE_SELECT_2') {
        if (sovereignId > 0) {
            const sideCountry = sides.flat().filter(Boolean).find(c => c.id === sovereignId);
            if (sideCountry) {
                signSelectivePeace(peaceSelection1, sideCountry);
            }
        }
        return;
    }



    if (gameState === 'SIMULATING') {
        if (sovereignId > 0) {
            openInspector(sovereignId);
        }
        return;
    }

    if (gameState === 'WAR_OVER') return;
    
    if (gameState === 'EDITOR_ACTIVE' || gameState === 'EDITOR_PAINTING' || gameState === 'EDITOR_FILLING' || gameState === 'EDITOR_FILLING_TERRAIN') {
        if (gameState === 'EDITOR_FILLING') {
            fillAt(latlng);
        } else if (gameState === 'EDITOR_FILLING_TERRAIN') {
            fillTerrainAt(latlng);
        } else if (sovereignId > 0) {
            // Select the nation and open the inspector
            editingCountryId = sovereignId;
            openInspector(sovereignId);
            
            if (godModeActive && gameState === 'EDITOR_ACTIVE') {
                const meta = countryMetadata[sovereignId - 1];
                statusText.innerText = `GOD MODE: ${meta.name || 'Selected Nation'} selected.`;
            }
        }
        return;
    }

    // Conquest Selection Logic
    if (sovereignId <= 0) return; // Must click a country in Conquest mode
    
    const meta = countryMetadata[sovereignId - 1];
    if (!meta) return;

    const targetFeature = meta.feature;
    const countryName = meta.name || targetFeature?.properties?.NAME || targetFeature?.properties?.name || "Unknown";
    const color = meta.color;

    // Smart Reassignment Logic: If country is already in a side, move it or open inspector
    let existingSideIdx = -1;
    sides.forEach((side, idx) => {
        if (side && side.some(c => c && c.id === sovereignId)) existingSideIdx = idx;
    });

    if (existingSideIdx !== -1) {
        if (existingSideIdx === activeSideIndex) {
            // Already in active side: open inspector for editing, with double-click protection
            if (Date.now() - lastSelectionTime > 350 || lastSelectedId !== sovereignId) {
                openInspector(sovereignId);
            }
        } else {
            // In a different side: transfer to active side instead of blocking or opening inspector
            const countryToMove = sides[existingSideIdx].find(c => c.id === sovereignId);
            sides[existingSideIdx] = sides[existingSideIdx].filter(c => c.id !== sovereignId);
            sides[activeSideIndex].push(countryToMove);
            updateSidesUI();
            statusText.innerText = `REASSIGNED: ${countryName} moved to Side ${String.fromCharCode(65 + activeSideIndex)}`;
            influenceLayer.render();
        }
        lastSelectionTime = Date.now();
        lastSelectedId = sovereignId;
        return;
    }

    if (ffaMode) {
        // In FFA, every new click creates a new side if the current active side isn't empty
        if (sides[activeSideIndex] && sides[activeSideIndex].length > 0) {
            sides.push([]);
            activeSideIndex = sides.length - 1;
        }
    }

    const targetList = sides[activeSideIndex];
    if (!targetList) return;

    const newCountry = {
        feature: targetFeature,
        id: sovereignId,
        color: color,
        name: countryName,
        buffState: meta.buffState || 'none', // Carry over buff state from meta
        flag: null,
        strategy: 'BALANCED',
        role: 'OFFENSE'
    };

    targetList.push(newCountry);
    lastSelectionTime = Date.now();
    lastSelectedId = sovereignId;
    updateSidesUI();
    statusText.innerText = "Conflict Setup (Select more or click Inaugurate)";
    influenceLayer.render();

    // Tutorial Progression Logic
    if (tutorialActive) {
        const step = activeTutorialSet[currentTutorialStep];
        if (step.actionRequired === "SELECT_GERMANY" && countryName.toLowerCase() === "germany") {
            advanceTutorial();
        } else if (step.actionRequired === "SELECT_POLAND" && countryName.toLowerCase() === "poland" && activeSideIndex === 1) {
            advanceTutorial();
        }
    }
}

function getFeatureCenter(feature) {
    const bounds = L.geoJSON(feature).getBounds();
    return bounds.getCenter();
}

function spawnSingleUnit(sideIdx, sovereignId, team) {
    // Enforce per‑side unit cap: if this side is already at or above the limit, do not spawn.
    const sideUnits = units.filter(u => u.sideIndex === sideIdx).length;
    if (sideUnits >= CONFIG.MAX_UNITS_PER_SIDE) return false;

    // Note: Nations can continue to raise new units even if their displayed personnel pool is exhausted.
    // This prevents a hard "dead state" where they are permanently unable to fight.
    const theaterIndices = [];
    const frontlines = [];
    const isTeamA = team === 'A';
    const supplyFailed = capitalLostCountries && capitalLostCountries.has(sovereignId);
    
    // Efficiently find recruitment-eligible territory
    const step = Math.max(1, Math.floor(landMask.length / 500000));
    for (let i = 0; i < landMask.length; i += step) {
        if (landMask[i] === 2 && worldControlMap[i] === sovereignId) {
            const occ = occupationMap[i];
            if ((isTeamA && occ > 0.5) || (!isTeamA && occ < -0.5)) {
                theaterIndices.push(i);
                
                // Fast check if this recruitment cell is on a border
                const neighbors = [i + 1, i - 1, i + gridWidth, i - gridWidth];
                let isF = false;
                for (const n of neighbors) {
                    if (n >= 0 && n < landMask.length) {
                        const nId = worldControlMap[n];
                        if (nId > 0 && nId !== sovereignId) {
                            const nSide = sides.findIndex(s => s.some(c => c.id === nId));
                            if (nSide !== -1 && (nSide % 2 !== sideIdx % 2)) {
                                isF = true;
                                break;
                            }
                        }
                    }
                }
                if (isF) frontlines.push(i);
            }
        }
    }

    if (theaterIndices.length === 0) return false;

    let idx;
    let isFromFront = false;
    // If supply has failed (capital captured), always spawn what few troops remain directly on the frontlines
    if ((frontlines.length > 0 && Math.random() < 0.85) || (supplyFailed && frontlines.length > 0)) {
        idx = frontlines[Math.floor(Math.random() * frontlines.length)];
        isFromFront = true;
    } else {
        idx = theaterIndices[Math.floor(Math.random() * theaterIndices.length)];
    }

    const y = Math.floor(idx / gridWidth);
    const x = idx % gridWidth;
    
    // Calculate direction away from enemies for pushback
    let vx = 0, vy = 0;
    if (isFromFront) {
        const neighbors = [
            { id: idx + 1, dx: 1, dy: 0 },
            { id: idx - 1, dx: -1, dy: 0 },
            { id: idx + gridWidth, dx: 0, dy: 1 },
            { id: idx - gridWidth, dx: 0, dy: -1 }
        ];
        for (const n of neighbors) {
            if (n.id >= 0 && n.id < landMask.length) {
                const nId = worldControlMap[n.id];
                if (nId > 0 && nId !== sovereignId) {
                    const nSide = sides.findIndex(s => s.some(c => c.id === nId));
                    if (nSide !== -1 && (nSide % 2 !== sideIdx % 2)) {
                        vx -= n.dx;
                        vy -= n.dy;
                    }
                }
            }
        }
    }
    
    const mag = Math.sqrt(vx*vx + vy*vy);
    // Reduced pushback to stay within sovereign borders (0.35x grid resolution)
    const pushBack = isFromFront && mag > 0 ? (CONFIG.GRID_RES * 0.35) : 0;
    const pvx = mag > 0 ? vx/mag : 0;
    const pvy = mag > 0 ? vy/mag : 0;

    let lat = (y * CONFIG.GRID_RES) - 90 + (Math.random() - 0.5) * CONFIG.GRID_RES * 0.8 + (pvy * pushBack);
    let lng = (x * CONFIG.GRID_RES) - 180 + (Math.random() - 0.5) * CONFIG.GRID_RES * 0.8 + (pvx * pushBack);

    // Sovereign Integrity Check: Ensure units don't spawn in neighbors (like France when Belgium is fighting Germany)
    const finalIdx = getGridIndex(lat, lng);
    if (finalIdx === -1 || worldControlMap[finalIdx] !== sovereignId) {
        // Fallback to strict cell center to guarantee sovereign location
        lat = (y * CONFIG.GRID_RES) - 90 + (CONFIG.GRID_RES / 2);
        lng = (x * CONFIG.GRID_RES) - 180 + (CONFIG.GRID_RES / 2);
    }

    const isMountainCell = terrainMask && terrainMask[idx] > 0.35;
    // Alpenjägers: mostly drawn from mountainous recruitment cells
    const isAlpen = isMountainCell && Math.random() < 0.4;

    // Base health for this new unit
    let unitHealth = CONFIG.UNIT_HEALTH * (isAlpen ? CONFIG.ALPEN_HEALTH_MULT : 1);
    // When supply has failed (capital captured), newly raised units are under‑equipped and fragile
    if (supplyFailed) {
        unitHealth *= 0.4; // 60% health penalty
    }

    units.push({
        id: Math.random(),
        lat,
        lng,
        team,
        sideIndex: sideIdx,
        sovereignId: sovereignId,
        beneficiaryId: sovereignId,
        isAlpenjager: !!isAlpen,
        health: unitHealth,
        lastAttack: 0,
        deployTicks: 30 // Exactly 0.5 seconds at 60fps
    });

    // Whenever a new unit is recruited mid‑war, restore personnel for that side
    // using the same dynamic soldiers‑per‑unit scaling used for casualties.
    if (team === 'A') {
        teamASoldiers += soldiersPerUnitA;
    } else if (team === 'B') {
        teamBSoldiers += soldiersPerUnitB;
    }

    return true;
}

function spawnUnits(feature, team, forcedId = null, sideIdx = 0) {
    // Legacy function - logic integrated into optimized startWar pass
    return;
    const theaterIndices = [];
    const isTeamA = sideIdx % 2 === 0; // Evens are "Side A" polarity, Odds are "Side B" polarity
    const sovereignId = forcedId !== null ? forcedId : (isTeamA ? teamAId : -1);

    for (let i = 0; i < landMask.length; i++) {
        if (landMask[i] === 2) {
            const occ = occupationMap[i];
            if (worldControlMap[i] === sovereignId || (sovereignId === -1)) {
                if ((isTeamA && occ > 0.5) || (!isTeamA && occ < -0.5)) {
                    theaterIndices.push(i);
                }
            }
        }
    }
    
    // Dynamic unit count based on land area (number of grid cells)
    const multiplier = parseFloat(densitySlider.value) || 1.0;
    let count = Math.floor(theaterIndices.length * CONFIG.UNIT_DENSITY_FACTOR * multiplier);
    
    const flatFloor = 3;
    count = Math.max(flatFloor, count);
    
    // Clamp by global unit limit
    count = Math.min(count, CONFIG.MAX_UNITS_PER_SIDE);
    
    let spawned = 0;
    while (spawned < count && theaterIndices.length > 0) {
        let idx = theaterIndices[Math.floor(Math.random() * theaterIndices.length)];
        
        const y = Math.floor(idx / gridWidth);
        const x = idx % gridWidth;
        const lat = (y * CONFIG.GRID_RES) - 90 + Math.random() * CONFIG.GRID_RES;
        const lng = (x * CONFIG.GRID_RES) - 180 + Math.random() * CONFIG.GRID_RES;
        
        units.push({
            id: Math.random(),
            lat,
            lng,
            team: isTeamA ? 'A' : 'B',
            sideIndex: sideIdx,
            sovereignId: sovereignId,
            beneficiaryId: sovereignId,
            health: CONFIG.UNIT_HEALTH,
            lastAttack: 0
        });
        spawned++;
    }
}

function generateBases() {
    // Legacy function - logic integrated into optimized startWar pass
}

function setGameTimeFromInputs() {
    if (!timeSystemCheckbox || !timeSystemCheckbox.checked) {
        gameTimeEnabled = false;
        gameTimeDate = null;
        gameTimeAccumulatorMs = 0;
        if (gameDateDisplay) gameDateDisplay.style.display = 'none';
        return;
    }
    const y = parseInt(timeYearInput.value || '0', 10);
    const m = parseInt(timeMonthInput.value || '0', 10);
    const d = parseInt(timeDayInput.value || '0', 10);
    if (!y || !m || !d) {
        // fallback default if user left blanks
        gameTimeDate = { year: 1936, month: 1, day: 1 };
    } else {
        gameTimeDate = { year: y, month: m, day: d };
    }
    gameTimeEnabled = true;
    gameTimeAccumulatorMs = 0;
    if (gameDateDisplay) {
        gameDateDisplay.style.display = 'block';
        gameDateDisplay.textContent = formatGameDate();
    }
}

function formatGameDate() {
    if (!gameTimeDate) return '0000/00/00';
    const y = gameTimeDate.year.toString().padStart(4, '0');
    const m = gameTimeDate.month.toString().padStart(2, '0');
    const d = gameTimeDate.day.toString().padStart(2, '0');
    return `${y}/${m}/${d}`;
}

function daysInMonth(year, month) {
    if (month === 1 || month === 3 || month === 5 || month === 7 || month === 8 || month === 10 || month === 12) return 31;
    if (month === 4 || month === 6 || month === 9 || month === 11) return 30;
    // February
    const isLeap = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    return isLeap ? 29 : 28;
}

function advanceGameDateOneDay() {
    if (!gameTimeEnabled || !gameTimeDate) return;
    gameTimeDate.day += 1;
    const dim = daysInMonth(gameTimeDate.year, gameTimeDate.month);
    if (gameTimeDate.day > dim) {
        gameTimeDate.day = 1;
        gameTimeDate.month += 1;
        if (gameTimeDate.month > 12) {
            gameTimeDate.month = 1;
            gameTimeDate.year += 1;
        }
    }
    if (gameDateDisplay) {
        gameDateDisplay.textContent = formatGameDate();
    }
}

function tickGameTime(elapsedMs) {
    if (!gameTimeEnabled || gameState !== 'SIMULATING' || isPaused || !gameTimeDate) return;
    // Scale in-game time progression with the current simulation speed
    gameTimeAccumulatorMs += elapsedMs * simSpeed;
    const step = 500; // 0.5 seconds per day at 1x speed
    while (gameTimeAccumulatorMs >= step) {
        advanceGameDateOneDay();
        gameTimeAccumulatorMs -= step;
    }
}

function deepClone(obj) {
    return obj ? JSON.parse(JSON.stringify(obj)) : obj;
}

async function startWar() {
    const activeSides = sides.filter(s => s.length > 0);
    if (activeSides.length < 2) {
        alert("Please assign countries to at least two sides.");
        return;
    }

    // Performance protection: show loading overlay while mobilizing giant nations
    loadingOverlay.style.display = 'flex';
    loadingStatus.innerText = getTranslation('LOADING');
    loadingBar.style.width = "0%";
    
    // Yield to allow UI to render the loader
    await new Promise(r => setTimeout(r, 50));
    
    initAudio().then(() => {
        playWarAmbiance();
    });
    playWarStartSound();

    // Capture a clean snapshot of the scenario just before the war starts
    // so QUICK RESTART can restore it instantly with no loading screen.
    initialWorldControlMapSnapshot = worldControlMap ? new Int32Array(worldControlMap) : null;
    initialDeJureMapSnapshot = deJureMap ? new Int32Array(deJureMap) : null;
    initialProvinceMapSnapshot = provinceMap ? new Int32Array(provinceMap) : null;
    initialLandMaskSnapshot = landMask ? new Uint8Array(landMask) : null;
    initialBiomeMaskSnapshot = biomeMask ? new Uint8Array(biomeMask) : null;
    initialCountryMetadataSnapshot = deepClone(countryMetadata);
    initialCitiesSnapshot = deepClone(cities);

    const attackers = sides[0] || [];
    const defenders = sides[1] || [];

    teamAId = attackers.length > 0 ? attackers[0].id : -1;

    // Initialize time system for this war
    setGameTimeFromInputs();

    // Read optional manual manpower overrides from the setup inputs
    const mpAInput = document.getElementById('manpower-side-a');
    const mpBInput = document.getElementById('manpower-side-b');
    const parsedA = mpAInput ? parseInt(mpAInput.value, 10) : NaN;
    const parsedB = mpBInput ? parseInt(mpBInput.value, 10) : NaN;
    manualSideAManpower = (!isNaN(parsedA) && parsedA > 0) ? parsedA : null;
    manualSideBManpower = (!isNaN(parsedB) && parsedB > 0) ? parsedB : null;

    gameState = 'SIMULATING';
    isPaused = false;
    
    // Cinematic Mode logic
    cinematicMode = document.getElementById('cinematic-mode-checkbox')?.checked || false;
    if (cinematicMode) {
        document.getElementById('game-status').style.display = 'none';
        document.getElementById('stats-panel').style.display = 'none';
        
        // Start Recording
        try {
            const canvas = influenceLayer._container;
            recordedChunks = [];
            const stream = canvas.captureStream(30); // 30fps recording
            mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm; codecs=vp9' });
            mediaRecorder.ondataavailable = (e) => {
                if (e.data.size > 0) recordedChunks.push(e.data);
            };
            mediaRecorder.start();
        } catch (e) {
            console.warn("MediaRecorder failed to start:", e);
        }
    } else {
        document.getElementById('game-status').style.display = 'flex';
        document.getElementById('stats-panel').style.display = 'block';
    }
    pauseBtn.innerText = '⏸';
    pauseBtn.style.background = '#f39c12';
    lastTreatyTime = Date.now();
    sideACasualties = 0;
    sideBCasualties = 0;
    countryCasualties.clear();
    sides.flat().forEach(c => countryCasualties.set(c.id, 0));
    frameAccumulator = 0;
    simFrameCount = 0;
    setSpeed(1); // Conflicts start at 0.5 speed (Index 1 in SPEED_STEPS)
    peaceTreatiesDisabled = noPeaceCheckbox.checked;
    bombsDisabled = disableBombsCheckbox.checked || !missilesEnabled;
    statusText.innerText = ffaMode ? "Free For All Active" : "Global Conflict Active";
    recalculateAllBounds();
    setupPanel.style.display = 'none';
    statsPanel.style.display = 'block';
    casualtyPanel.style.display = 'flex';
    resetBtn.style.display = 'block';
    updateRestartVisibility();
    
    // Final sync of mountain and province state before sim starts
    mountainsEnabled = !setupDisableMountainsCheckbox.checked;
    provincesEnabled = !setupDisableProvincesCheckbox.checked;
    document.getElementById('speed-controls').style.display = 'flex';
    godModeBtn.style.display = 'block';
    forcePeaceBtn.style.display = 'block';
    unitCountsDiv.style.display = 'flex';
    treatyAlert.style.display = 'none';

    const getCode = (feat) => {
        if (!feat || !feat.properties) return "un";
        const p = feat.properties;
        let code = p.ISO_A2 || p.iso_a2 || p.ISO_A2_EH || p.iso_a2_eh || p.ADDR_A2 || "un";
        if (code === "-99") code = "un";
        return code.toLowerCase();
    }
    
    // Optimize: Single pass to count initial cells and set up masks/occupancy
    const countryToSideMap = new Map();
    const cellCounts = new Map();
    const countryIndices = new Map();
    const sidePoleIndices = { 'A': [], 'B': [] };

    // Ensure country bounds are up to date before we derive any war theater extents
    recalculateAllBounds();

    initialCombatants = [];
    sides.forEach((side, idx) => {
        side.forEach(c => {
            initialCombatants.push({
                id: c.id,
                name: c.name,
                sideIndex: idx,
                pole: idx % 2 === 0 ? 0 : 1
            });
            countryToSideMap.set(c.id, idx);
            cellCounts.set(c.id, 0);
            countryIndices.set(c.id, []);
            
            // Flag initialization: Reuse existing flag objects from metadata to prevent flickering and redundant fetches
            const meta = countryMetadata.find(m => m && m.id === c.id);
            if (meta && meta.tempFlag) {
                c.flag = meta.tempFlag;
            } else {
                c.flag = new Image();
                c.flag.crossOrigin = "anonymous";
                if (meta && meta.flagUrl) {
                    c.flag.src = meta.flagUrl;
                } else {
                    const nameCode = findCodeByName(c.name);
                    const src = nameCode ? `https://flagcdn.com/w80/${nameCode}.png` : (c.feature ? `https://flagcdn.com/w80/${getCode(c.feature)}.png` : null);
                    if (src) c.flag.src = src;
                }
                if (meta) meta.tempFlag = c.flag;
            }
            c.isCapitulated = false;
            c.isSaturated = false;
        });
    });

    primaryOccupierMap.fill(0);
    
    // Determine the minimal bounding box that covers all warring countries on the grid
    let minX = gridWidth - 1;
    let maxX = 0;
    let minY = gridHeight - 1;
    let maxY = 0;

    countryMetadata.forEach(meta => {
        if (!meta) return;
        if (!countryToSideMap.has(meta.id)) return;
        if (!meta.bounds) return;
        minX = Math.min(minX, meta.bounds.minX);
        maxX = Math.max(maxX, meta.bounds.maxX);
        minY = Math.min(minY, meta.bounds.minY);
        maxY = Math.max(maxY, meta.bounds.maxY);
    });

    // Fallback to full map if bounds are invalid for some reason
    if (!isFinite(minX) || !isFinite(maxX) || !isFinite(minY) || !isFinite(maxY) ||
        minX < 0 || minY < 0 || maxX <= minX || maxY <= minY) {
        minX = 0;
        minY = 0;
        maxX = gridWidth - 1;
        maxY = gridHeight - 1;
    }

    // THE OPTIMIZED PASS: Only scan the war theater bounding box, chunked to keep UI responsive
    const regionWidth = (maxX - minX + 1);
    const regionHeight = (maxY - minY + 1);
    const regionTotalCells = regionWidth * regionHeight;
    const chunkSize = 250000; // Smaller chunks for smoother big-war startup

    let processed = 0;
    for (let y = minY; y <= maxY; y++) {
        const rowOffset = y * gridWidth;
        for (let x = minX; x <= maxX; x++) {
            const i = rowOffset + x;
            const id = worldControlMap[i];
            if (id > 0 && countryToSideMap.has(id)) {
                const sideIdx = countryToSideMap.get(id);
                const isPoleA = sideIdx % 2 === 0;
                const poleKey = isPoleA ? 'A' : 'B';
                
                landMask[i] = 2; // Mark as war zone
                occupationMap[i] = isPoleA ? 1.0 : -1.0;
                primaryOccupierMap[i] = id;
                
                cellCounts.set(id, cellCounts.get(id) + 1);
                countryIndices.get(id).push(i);
                sidePoleIndices[poleKey].push(i);
            }
            processed++;
            if (processed % chunkSize === 0) {
                loadingBar.style.width = Math.min(90, (processed / regionTotalCells) * 70) + "%";
                // Yield back to the browser so the UI doesn't freeze on giant conflicts
                await new Promise(r => setTimeout(r, 0));
            }
        }
    }

    // Set counts back to country objects
    sides.forEach(side => side.forEach(c => {
        c.initialCells = cellCounts.get(c.id) || 0;
    }));

    // --- GENERALS & BATTLE PLANS ---
    // Each side gets a "general" with a plan quality; underdogs with a brilliant plan get powerful buffs.
    generals = [];
    const sideLand = sides.map(side =>
        side.reduce((sum, c) => sum + (cellCounts.get(c.id) || 0), 0)
    );

    // Automatically switch to POLITICAL view at the start of every war for consistent visibility.
    viewMode = 'POLITICAL';
    if (viewModeBtn) {
        viewModeBtn.innerText = "POLITICAL";
        viewModeBtn.style.background = "#3498db";
    }
    if (influenceLayer && typeof influenceLayer._update === 'function') {
        influenceLayer._forceRender = true;
        influenceLayer._update();
    }

    sides.forEach((side, idx) => {
        const myLand = sideLand[idx] || 0;
        const enemyLand = sideLand.reduce((sum, v, i) => i === idx ? sum : sum + v, 0);
        const isUnderdog = enemyLand > 0 && myLand < enemyLand;

        // Base plan quality; underdogs get a small bias towards better plans.
        // Overall values are kept modest so "cracked" generals are rare.
        let planQuality = Math.random();
        if (isUnderdog) {
            // Pull slightly towards the upper half but keep a lot of randomness.
            planQuality = Math.min(1, planQuality * 0.3 + 0.3 + Math.random() * 0.2);
        }

        const general = {
            sideIndex: idx,
            isUnderdog,
            planQuality,
            name: isUnderdog ? `Underdog General ${idx + 1}` : `General ${idx + 1}`
        };
        generals.push(general);

        // If the plan is strong enough and this side is the underdog, consider super‑buffs.
        // However, if the opposing pole already fields heavily buffed nations (buff/super/godly),
        // their raw quality largely negates this general advantage.
        const enemyHasStrongBuff = sides.some((otherSide, j) =>
            j !== idx &&
            (j % 2 !== idx % 2) &&
            otherSide.some(c => ['buff', 'super', 'godly'].includes(c.buffState || 'none'))
        );

        // Make strong underdog generals much rarer (high threshold) and disable them
        // when facing strongly buffed opponents (e.g. Luxembourg vs a buffed Germany).
        if (isUnderdog && planQuality > 0.9 && !enemyHasStrongBuff) {
            side.forEach(c => {
                c.buffState = c.buffState === 'godly' ? 'godly' : 'super';
                const meta = countryMetadata.find(m => m && m.id === c.id);
                if (meta) meta.buffState = c.buffState;
            });
        }
    });

    teamAColor = attackers.length > 0 ? attackers[0].color : 'rgba(255,50,50,0.5)';
    teamBColor = defenders.length > 0 ? defenders[0].color : 'rgba(50,100,255,0.5)';
    
    const repColorA = teamAColor.replace(/[\d.]+\)$/g, '1)');
    const repColorB = teamBColor.replace(/[\d.]+\)$/g, '1)');
    progressBar.style.backgroundColor = repColorA;
    document.getElementById('p1-units').style.color = repColorA;
    document.getElementById('p2-units').style.color = repColorB;
    document.getElementById('p1-cities').style.color = repColorA;
    document.getElementById('p2-cities').style.color = repColorB;

    activeTheaterCities = cities.filter(c => {
        const idx = getGridIndex(c.lat, c.lng);
        if (idx !== -1 && landMask[idx] === 2) {
            c.sovereignId = worldControlMap[idx];
            return true;
        }
        return false;
    });

    // Identify frontline cells for each country for smarter spawning
    const frontlineIndices = new Map();
    sides.flat().forEach(c => frontlineIndices.set(c.id, []));
    
    // Scan warzone for borders to define the initial "front"
    const totalCells = worldControlMap.length;
    for (let i = 0; i < totalCells; i++) {
        const id = worldControlMap[i];
        if (id > 0 && countryToSideMap.has(id)) {
            const sideIdx = countryToSideMap.get(id);
            const y = Math.floor(i / gridWidth);
            const x = i % gridWidth;
            let isFrontline = false;
            // Check cardinal neighbors and calculate push vector
            const neighbors = [
                { id: i + 1, dx: 1, dy: 0 },
                { id: i - 1, dx: -1, dy: 0 },
                { id: i + gridWidth, dx: 0, dy: 1 },
                { id: i - gridWidth, dx: 0, dy: -1 }
            ];
            let vx = 0, vy = 0;
            for (const n of neighbors) {
                if (n.id >= 0 && n.id < totalCells) {
                    const nId = worldControlMap[n.id];
                    // A cell is a frontline if its neighbor belongs to an enemy side
                    if (nId > 0 && countryToSideMap.has(nId) && (countryToSideMap.get(nId) % 2 !== sideIdx % 2)) {
                        isFrontline = true;
                        vx -= n.dx; // Vector away from enemy neighbor
                        vy -= n.dy;
                    }
                }
            }
            if (isFrontline) {
                const mag = Math.sqrt(vx*vx + vy*vy);
                frontlineIndices.get(id).push({
                    idx: i,
                    vx: mag > 0 ? vx/mag : 0,
                    vy: mag > 0 ? vy/mag : 0
                });
            }
        }
    }

    // Efficient spawn based on pre-collected indices
    sides.forEach((side, sideIdx) => {
        const isPoleA = sideIdx % 2 === 0;
        const multiplier = parseFloat(densitySlider.value) || 1.0;

        // Track how many units this side already has so we can enforce CONFIG.MAX_UNITS_PER_SIDE strictly.
        let sideCurrentUnits = units.filter(u => u.sideIndex === sideIdx).length;

        side.forEach(c => {
            const theaterIndices = countryIndices.get(c.id);
            const fronts = frontlineIndices.get(c.id);
            if (!theaterIndices || theaterIndices.length === 0) return;

            // Diminishing Density: Large countries have lower unit density to prevent overcrowding
            const sizeFactor = Math.max(1, theaterIndices.length / 1500);
            const densityScale = 1.0 / Math.pow(sizeFactor, 0.45);

            let desiredCount = Math.floor(theaterIndices.length * CONFIG.UNIT_DENSITY_FACTOR * multiplier * densityScale);
            const floor = c.startingUnitsFloor || 3;
            desiredCount = Math.max(floor, desiredCount);

            const remainingCap = Math.max(0, CONFIG.MAX_UNITS_PER_SIDE - sideCurrentUnits);
            const count = Math.min(desiredCount, remainingCap);
            if (count <= 0) return;

            for (let j = 0; j < count; j++) {
                // High probability (95%) to spawn at identified frontline cells
                let fData;
                let fromFront = false;
                if (fronts && fronts.length > 0 && Math.random() < 0.95) {
                    fData = fronts[Math.floor(Math.random() * fronts.length)];
                    fromFront = true;
                } else {
                    const tidx = theaterIndices[Math.floor(Math.random() * theaterIndices.length)];
                    fData = { idx: tidx, vx: 0, vy: 0 };
                }

                const y = Math.floor(fData.idx / gridWidth);
                const x = fData.idx % gridWidth;
                
                // Spread units slightly but keep them in their territory and on the line
                // Reduced jitter and pushback to 0.4x grid res to prevent spawning across allied borders
                const jitterRange = CONFIG.GRID_RES * 0.4;
                const pushBack = fromFront ? (CONFIG.GRID_RES * 0.4) : 0;

                let lat = (y * CONFIG.GRID_RES) - 90 + (Math.random() - 0.5) * jitterRange + (fData.vy * pushBack);
                let lng = (x * CONFIG.GRID_RES) - 180 + (Math.random() - 0.5) * jitterRange + (fData.vx * pushBack);

                // Validation: Ensure final coordinate is within the country's sovereign grid
                const finalIdx = getGridIndex(lat, lng);
                if (finalIdx === -1 || worldControlMap[finalIdx] !== c.id) {
                    lat = (y * CONFIG.GRID_RES) - 90 + (CONFIG.GRID_RES / 2);
                    lng = (x * CONFIG.GRID_RES) - 180 + (CONFIG.GRID_RES / 2);
                }

                const isMountainCell = terrainMask && terrainMask[fData.idx] > 0.35;
                const isAlpen = isMountainCell && Math.random() < 0.4;

                units.push({
                    id: Math.random(),
                    lat,
                    lng,
                    team: isPoleA ? 'A' : 'B',
                    sideIndex: sideIdx,
                    sovereignId: c.id,
                    beneficiaryId: c.id,
                    isAlpenjager: !!isAlpen,
                    health: CONFIG.UNIT_HEALTH * (isAlpen ? CONFIG.ALPEN_HEALTH_MULT : 1),
                    lastAttack: 0,
                    deployTicks: 30 // Exactly 0.5 seconds at 60fps
                });
                sideCurrentUnits++;
                if (sideCurrentUnits >= CONFIG.MAX_UNITS_PER_SIDE) break;
            }
        });
    });

    // Historical Tech Guard for Base Generation
    const currentYear = gameTimeDate ? gameTimeDate.year : 2024;
    const allowSilos = !gameTimeEnabled || currentYear >= 1942;

    ['A', 'B'].forEach(pole => {
        const validIndices = sidePoleIndices[pole];
        if (!validIndices || validIndices.length === 0) return;

        // Missile Silos (1942+)
        if (allowSilos) {
            const baseCount = Math.min(8, Math.max(2, Math.floor(validIndices.length / 500)));
            for (let i = 0; i < baseCount; i++) {
                const randIdx = validIndices[Math.floor(Math.random() * validIndices.length)];
                const y = Math.floor(randIdx / gridWidth);
                const x = randIdx % gridWidth;
                bases.push({
                    lat: (y * CONFIG.GRID_RES) - 90 + (CONFIG.GRID_RES / 2),
                    lng: (x * CONFIG.GRID_RES) - 180 + (CONFIG.GRID_RES / 2),
                    team: pole
                });
            }
        }
    });

    loadingOverlay.style.display = 'none';

    if (tutorialActive && activeTutorialSet[currentTutorialStep].actionRequired === "START_WAR") {
        advanceTutorial();
    }

    // Initialize displayed manpower, honoring any manual overrides if present.
    // Base manpower comes from units, with an additional city-based bonus so more cities = more manpower.
    const unitCountA = units.filter(u => u.team === 'A').length;
    const unitCountB = units.filter(u => u.team === 'B').length;
    const initialUnitsA = unitCountA * CONFIG.UNIT_TO_SOLDIER_RATIO;
    const initialUnitsB = unitCountB * CONFIG.UNIT_TO_SOLDIER_RATIO;

    // Initial manpower now comes only from units (or manual overrides), not cities
    initialTeamASoldiers = manualSideAManpower !== null
        ? manualSideAManpower
        : Math.round(initialUnitsA);
    initialTeamBSoldiers = manualSideBManpower !== null
        ? manualSideBManpower
        : Math.round(initialUnitsB);

    // Current remaining manpower starts at the initial pool and is reduced by casualties
    teamASoldiers = initialTeamASoldiers;
    teamBSoldiers = initialTeamBSoldiers;

    // Compute dynamic soldiers-per-unit ratios so casualties always match available manpower
    // and scale with the actual number of units on each side (including manual manpower overrides).
    soldiersPerUnitA = unitCountA > 0 ? (initialTeamASoldiers / unitCountA) : CONFIG.UNIT_TO_SOLDIER_RATIO;
    soldiersPerUnitB = unitCountB > 0 ? (initialTeamBSoldiers / unitCountB) : CONFIG.UNIT_TO_SOLDIER_RATIO;
    
    let bounds = L.latLngBounds([]);
    sides.forEach(side => side.forEach(c => {
        if (c.feature) try { bounds.extend(L.geoJSON(c.feature).getBounds()); } catch(e) {}
    }));

    if (!bounds.isValid()) {
       for (let i = 0; i < worldControlMap.length; i++) {
           const id = worldControlMap[i];
           if (sides.some(s => s.some(c => c.id === id))) {
               const y = Math.floor(i / gridWidth);
               const x = i % gridWidth;
               const lat = (y * CONFIG.GRID_RES) - 90;
               const lng = (x * CONFIG.GRID_RES) - 180;
               bounds.extend([lat, lng]);
           }
       }
    }
    
    if (bounds.isValid()) {
        map.fitBounds(bounds.pad(0.2));
    }

    // Automatically join all vassals of countries starting the war if not disabled
    if (!disablePuppetsCheckbox.checked) {
        sides.forEach((side, sIdx) => {
            if (!side) return;
            const initialVassals = [];
            side.forEach(c => {
                if (!c) return;
                countryMetadata.forEach(m => {
                    if (m && m.overlordId === c.id && !sides.flat().some(exist => exist && exist.id === m.id)) {
                        initialVassals.push(m.id);
                    }
                });
            });
            initialVassals.forEach(vid => recruitNeutralMidWar(vid, sIdx));
        });
    }
    
    requestAnimationFrame(updateLoop);
}

function computeAdjacency() {
    const adj = new Map();
    const total = worldControlMap.length;
    for (let i = 0; i < total; i++) {
        const id1 = worldControlMap[i];
        if (id1 <= 0) continue;
        
        const x = i % gridWidth;
        const y = Math.floor(i / gridWidth);
        
        // Only check right and down to avoid redundant pairs
        const neighbors = [];
        if (x < gridWidth - 1) neighbors.push(i + 1);
        if (y < gridHeight - 1) neighbors.push(i + gridWidth);
        
        for (const nIdx of neighbors) {
            const id2 = worldControlMap[nIdx];
            if (id2 > 0 && id1 !== id2) {
                if (!adj.has(id1)) adj.set(id1, new Set());
                if (!adj.has(id2)) adj.set(id2, new Set());
                adj.get(id1).add(id2);
                adj.get(id2).add(id1);
            }
        }
    }
    return adj;
}

function triggerRandomWar() {
    if (!randomWarMode) return;
    
    if (!adjacencyCache) adjacencyCache = computeAdjacency();
    
    const currentCombatants = new Set(sides.flat().map(c => c.id));
    const eligibleCountries = Array.from(adjacencyCache.keys()).filter(id => !currentCombatants.has(id));
    
    if (eligibleCountries.length < 2) return;

    // Try to find a pair of neighbors who are NOT at war
    let idA = -1, idB = -1;
    const shuffledEligible = eligibleCountries.sort(() => Math.random() - 0.5);
    
    for (const candidateA of shuffledEligible) {
        const neighbors = Array.from(adjacencyCache.get(candidateA)).filter(id => !currentCombatants.has(id));
        if (neighbors.length > 0) {
            idA = candidateA;
            idB = neighbors[Math.floor(Math.random() * neighbors.length)];
            break;
        }
    }

    if (idA === -1 || idB === -1) return;

    const metaA = countryMetadata[idA - 1];
    const metaB = countryMetadata[idB - 1];
    if (!metaA || !metaB) return;

    const countryA = { id: idA, name: metaA.name, color: metaA.color, role: 'OFFENSE', strategy: 'BALANCED', buffState: 'none' };
    const countryB = { id: idB, name: metaB.name, color: metaB.color, role: 'OFFENSE', strategy: 'BALANCED', buffState: 'none' };

    if (gameState !== 'SIMULATING') {
        sides = [[countryA], [countryB]];
        updateSidesUI();
        startWar();
    } else {
        // Find empty slots or create brand new sides for this specific conflict breakout
        // Reuse slots 0 and 1 if they were vacated by capitulation
        let sideIdxA = -1;
        let sideIdxB = -1;
        
        for (let i = 0; i < sides.length; i++) {
            if (sides[i].length === 0) {
                if (sideIdxA === -1) sideIdxA = i;
                else if (sideIdxB === -1) { sideIdxB = i; break; }
            }
        }
        
        if (sideIdxA === -1) {
            sideIdxA = sides.length;
            sides.push([countryA]);
        } else {
            sides[sideIdxA] = [countryA];
        }
        
        if (sideIdxB === -1) {
            sideIdxB = sides.length;
            sides.push([countryB]);
        } else {
            sides[sideIdxB] = [countryB];
        }
        
        // Ensure FFA mode is active so these new sides actually fight everyone else
        if (!ffaMode) {
            ffaMode = true;
            ffaToggleBtn.style.border = '2px solid #fff';
            ffaToggleBtn.innerText = 'FFA: ON';
        }

        activateCountryMidWar(countryA, sideIdxA);
        activateCountryMidWar(countryB, sideIdxB);
        updateSidesUI();
        
        const bounds = L.latLngBounds([]);
        [metaA, metaB].forEach(m => {
            if (m.feature) {
                try {
                    bounds.extend(L.geoJSON(m.feature).getBounds());
                } catch(e) {}
            }
        });
        if (bounds.isValid()) {
            map.flyToBounds(bounds.pad(0.5), { duration: 1.5 });
        }

        updateSidesUI();
        influenceLayer.render();
    }
}

function activateCountryMidWar(country, sideIdx) {
    const isPoleA = sideIdx % 2 === 0;
    const poleVal = isPoleA ? 1.0 : -1.0;
    const countryId = country.id;
    
    // Update existing units if switching sides
    units.forEach(u => {
        if (u.sovereignId === countryId) {
            u.team = isPoleA ? 'A' : 'B';
            u.sideIndex = sideIdx;
            u.beneficiaryId = countryId;
            u.deployTicks = 15; // Brief re-deployment delay
        }
    });

    let cellCount = 0;
    const theaterIndices = [];

    for (let i = 0; i < worldControlMap.length; i++) {
        if (worldControlMap[i] === countryId) {
            landMask[i] = 2; // Tag as active warzone
            // Flip existing occupation polarity to the new side's team
            occupationMap[i] = poleVal;
            primaryOccupierMap[i] = countryId;
            theaterIndices.push(i);
            cellCount++;
        }
    }
    country.initialCells = cellCount;

    // Add cities of the new country to the active theater so they can be captured
    const newCities = cities.filter(c => {
        const idx = getGridIndex(c.lat, c.lng);
        return idx !== -1 && worldControlMap[idx] === countryId;
    });
    activeTheaterCities = [...activeTheaterCities, ...newCities];

    const meta = countryMetadata.find(m => m && m.id === countryId);
    if (meta && meta.tempFlag) {
        country.flag = meta.tempFlag;
    } else {
        country.flag = new Image();
        country.flag.crossOrigin = "anonymous";
        if (meta && meta.flagUrl) {
            country.flag.src = meta.flagUrl;
        }
        if (meta) meta.tempFlag = country.flag;
    }

    // Identify frontline cells for the intervening country for smart spawning
    const frontlines = [];
    theaterIndices.forEach(i => {
        let isF = false;
        let vx = 0, vy = 0;
        const neighbors = [
            { id: i + 1, dx: 1, dy: 0 },
            { id: i - 1, dx: -1, dy: 0 },
            { id: i + gridWidth, dx: 0, dy: 1 },
            { id: i - gridWidth, dx: 0, dy: -1 }
        ];
        for (const n of neighbors) {
            if (n.id >= 0 && n.id < worldControlMap.length) {
                const nId = worldControlMap[n.id];
                // A cell is a frontline if its neighbor belongs to an enemy side
                if (nId > 0 && nId !== countryId) {
                    const nSide = sides.findIndex(s => s.some(c => c.id === nId));
                    if (nSide !== -1 && (nSide % 2 !== sideIdx % 2)) {
                        isF = true;
                        vx -= n.dx; // Vector away from enemy neighbor
                        vy -= n.dy;
                    }
                }
            }
        }
        if (isF) {
            const mag = Math.sqrt(vx*vx + vy*vy);
            frontlines.push({
                idx: i,
                vx: mag > 0 ? vx/mag : 0,
                vy: mag > 0 ? vy/mag : 0
            });
        }
    });

    const multiplier = parseFloat(densitySlider.value) || 1.0;
    
    // Diminishing Density: Large countries have lower unit density to prevent overcrowding
    const sizeFactor = Math.max(1, theaterIndices.length / 1500);
    const densityScale = 1.0 / Math.pow(sizeFactor, 0.45);
    
    let count = Math.floor(theaterIndices.length * CONFIG.UNIT_DENSITY_FACTOR * multiplier * densityScale);
    count = Math.max(4, Math.min(count, CONFIG.MAX_UNITS_PER_SIDE));

    for (let j = 0; j < count; j++) {
        let fData;
        let fromFront = false;
        if (frontlines.length > 0 && Math.random() < 0.95) {
            fData = frontlines[Math.floor(Math.random() * frontlines.length)];
            fromFront = true;
        } else {
            const idx = theaterIndices[Math.floor(Math.random() * theaterIndices.length)];
            fData = { idx, vx: 0, vy: 0 };
        }

        const y = Math.floor(fData.idx / gridWidth);
        const x = fData.idx % gridWidth;
        
        // Use pushback logic consistent with startWar for clean frontline deployment
        const pushBack = fromFront ? (CONFIG.GRID_RES * 0.45) : 0;
        
        const spawnIdx = fData.idx;
        const isMountainCell = terrainMask && terrainMask[spawnIdx] > 0.35;
        const isAlpen = isMountainCell && Math.random() < 0.4;

        units.push({
            id: Math.random(),
            lat: (y * CONFIG.GRID_RES) - 90 + (Math.random() - 0.5) * CONFIG.GRID_RES * 1.2 + (fData.vy * pushBack),
            lng: (x * CONFIG.GRID_RES) - 180 + (Math.random() - 0.5) * CONFIG.GRID_RES * 1.2 + (fData.vx * pushBack),
            team: isPoleA ? 'A' : 'B',
            sideIndex: sideIdx,
            sovereignId: countryId,
            beneficiaryId: countryId,
            isAlpenjager: !!isAlpen,
            health: CONFIG.UNIT_HEALTH * (isAlpen ? CONFIG.ALPEN_HEALTH_MULT : 1),
            lastAttack: 0,
            deployTicks: 30 // Exactly 0.5 seconds at 60fps
        });
    }
    recalculateAllBounds();
}

function launchBomb(fromLat, fromLng, toLat, toLng, team) {
    bombs.push({
        id: Math.random(),
        startLat: fromLat,
        startLng: fromLng,
        targetLat: toLat,
        targetLng: toLng,
        currentLat: fromLat,
        currentLng: fromLng,
        nextLat: fromLat,
        nextLng: fromLng,
        progress: 0,
        team: team,
        state: 'rising',
        trail: [],
        peakAlt: 1.5 + Math.random() * 2.5 // Lower altitude for a flatter, more realistic arc
    });
}

function getBorderDirection(unit) {
    if (!worldControlMap || !landMask) return null;

    const idx = getGridIndex(unit.lat, unit.lng);
    if (idx === -1) return null;

    const y0 = Math.floor(idx / gridWidth);
    const x0 = idx % gridWidth;

    // Search radius in grid cells (frontline finder)
    const maxRadius = 12;
    let bestDx = 0, bestDy = 0;
    let bestDistSq = Infinity;

    for (let r = 1; r <= maxRadius; r++) {
        const yMin = Math.max(1, y0 - r);
        const yMax = Math.min(gridHeight - 2, y0 + r);
        const xMin = Math.max(1, x0 - r);
        const xMax = Math.min(gridWidth - 2, x0 + r);

        for (let y = yMin; y <= yMax; y++) {
            const rowOffset = y * gridWidth;
            for (let x = xMin; x <= xMax; x++) {
                const i = rowOffset + x;
                if (landMask[i] !== 2) continue;

                const occ = occupationMap[i];
                // Frontline cells: warzone with near-neutral occupation (border band)
                if (Math.abs(occ) > 0.25) continue;

                const cellLat = (y * CONFIG.GRID_RES) - 90;
                const cellLng = (x * CONFIG.GRID_RES) - 180;
                const dLat = cellLat - unit.lat;
                const dLng = cellLng - unit.lng;
                const dSq = dLat * dLat + dLng * dLng;
                if (dSq < bestDistSq) {
                    bestDistSq = dSq;
                    bestDx = dLng;
                    bestDy = dLat;
                }
            }
        }

        if (bestDistSq < Infinity) break;
    }

    if (bestDistSq === Infinity) return null;
    const mag = Math.sqrt(bestDx * bestDx + bestDy * bestDy);
    if (!mag || !isFinite(mag)) return null;

    return { lat: bestDy / mag, lng: bestDx / mag };
}

function performSimulationTick() {
    // If war is over, stop simulation mechanics (but update loop may continue for aftermath recording)
    if (gameState === 'WAR_OVER') return false;
    // If in God Mode but the war hasn't started yet, don't tick simulation mechanics
    if (godModeActive && preGodModeState !== 'SIMULATING') return false;

    // 0. Initial Utility Helpers
    const recordDamage = (targetUnit, dmg) => {
        if (isNaN(dmg) || dmg <= 0 || isNaN(targetUnit.health) || targetUnit.health <= 0) return;
        
        // Casualties increase while battling: damage is converted to personnel loss in real-time
        const effectiveDmg = Math.min(targetUnit.health, dmg);
        const ratio = (targetUnit.team === 'A' ? (soldiersPerUnitA || CONFIG.UNIT_TO_SOLDIER_RATIO) : (soldiersPerUnitB || CONFIG.UNIT_TO_SOLDIER_RATIO));
        const loss = (effectiveDmg / CONFIG.UNIT_HEALTH) * ratio;
        
        if (targetUnit.team === 'A') {
            teamASoldiers = Math.max(0, teamASoldiers - loss);
        } else {
            teamBSoldiers = Math.max(0, teamBSoldiers - loss);
        }
        
        const currentTotal = countryCasualties.get(targetUnit.sovereignId) || 0;
        countryCasualties.set(targetUnit.sovereignId, currentTotal + loss);
        targetUnit.health -= dmg;
    };

    // Random War Mode: Occasional new conflict breakout
    if (randomWarMode && simFrameCount % 60 === 0 && Math.random() < 0.05) {
        triggerRandomWar();
    }

    // 0. Initialize Tick Caches early to avoid access-before-initialization errors
    activeBattles = [];
    latestCountryStats.clear();
    const countryStats = latestCountryStats;
    const combatantIds = new Set();
    const countryToSideMap = new Map();

    sides.forEach((side, idx) => {
        side.forEach(c => {
            combatantIds.add(c.id);
            countryToSideMap.set(c.id, idx);
            countryStats.set(c.id, { units: 0, controlled: 0 });
        });
    });

    const isNeutral = (idx) => idx !== -1 && landMask[idx] > 0 && !combatantIds.has(worldControlMap[idx]);
    const isNeutralCountry = (idx) => isNeutral(idx) && worldControlMap[idx] > 0;

    // Determine unit counts once
    let p1UnitsCount = 0;
    let p2UnitsCount = 0;
    for (let i = 0; i < units.length; i++) {
        const u = units[i];
        if (u.team === 'A') p1UnitsCount++; else p2UnitsCount++;
        const s = countryStats.get(u.sovereignId);
        if (s) s.units++;
    }

    // 1. Update territory
    updatePersistentInfluence(p1UnitsCount, p2UnitsCount, countryToSideMap);

    // 1a. Occupancy Smoothing: Occasionally clean up primaryOccupierMap during war to prevent speckling
    if (simFrameCount % 120 === 0) {
        const tempOccupiers = new Int32Array(primaryOccupierMap);
        const sampleCount = 5000;
        for (let s = 0; s < sampleCount; s++) {
            const idx = Math.floor(Math.random() * primaryOccupierMap.length);
            if (landMask[idx] !== 2 || primaryOccupierMap[idx] === 0) continue;
            
            const myId = primaryOccupierMap[idx];
            const mySide = countryToSideMap.get(myId);
            
            // Sample 3x3 neighborhood
            const y = Math.floor(idx / gridWidth);
            const x = idx % gridWidth;
            const counts = new Map();
            for (let dy = -1; dy <= 1; dy++) {
                for (let dx = -1; dx <= 1; dx++) {
                    const nx = x + dx; const ny = y + dy;
                    if (nx >= 0 && nx < gridWidth && ny >= 0 && ny < gridHeight) {
                        const nId = primaryOccupierMap[ny * gridWidth + nx];
                        const nSide = countryToSideMap.get(nId);
                        // Only count allies
                        if (nId > 0 && nSide !== undefined && nSide % 2 === mySide % 2) {
                            counts.set(nId, (counts.get(nId) || 0) + 1);
                        }
                    }
                }
            }
            
            let dominantAlly = myId;
            let maxC = 0;
            counts.forEach((c, id) => { if (c > maxC) { maxC = c; dominantAlly = id; } });
            
            // If the occupier is a tiny island in an allied sea (majority neighbors are a single ally), flip to them.
            if (maxC >= 5) {
                tempOccupiers[idx] = dominantAlly;
            }
        }
        primaryOccupierMap.set(tempOccupiers);
    }

    // 1b. Territorial Integrity: Collapse deep pockets and isolated protrusions (Enclaves/Exclaves)
    // We sample the grid to find territory that is surrounded by the enemy.
    // This aggressively decays "border gore" and isolated bubbles.
    const optimizationFactor = getOptimizationFactor();
    const integBase = 5000;
    const integSamples = Math.max(1000, Math.floor(integBase / optimizationFactor));
    for (let s = 0; s < integSamples; s++) {
        const idx = Math.floor(Math.random() * landMask.length);
        if (landMask[idx] !== 2) continue; 
        const occ = occupationMap[idx];
        if (Math.abs(occ) < 0.1) continue; 
        
        const ownerId = worldControlMap[idx];
        const sideIdx = countryToSideMap.get(ownerId);
        if (sideIdx === undefined) continue;
        
        const isTeamA = sideIdx % 2 === 0;
        const isOccupiedByEnemy = isTeamA ? (occ < -0.05) : (occ > 0.05);
        const isOccupiedBySelf = isTeamA ? (occ > 0.05) : (occ < -0.05);
        
        const y = Math.floor(idx / gridWidth);
        const x = idx % gridWidth;
        let sovereignNeighbors = 0;
        let allyOccupiedNeighbors = 0;
        let enemyOccupiedNeighbors = 0;

        for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
                if (dy === 0 && dx === 0) continue;
                const ny = y + dy; const nx = x + dx;
                if (ny < 0 || ny >= gridHeight || nx < 0 || nx >= gridWidth) continue;
                const nIdx = ny * gridWidth + nx;
                const nOcc = occupationMap[nIdx];
                if (worldControlMap[nIdx] === ownerId) sovereignNeighbors++;
                if (isTeamA ? (nOcc > 0.1) : (nOcc < -0.1)) allyOccupiedNeighbors++;
                if (isTeamA ? (nOcc < -0.1) : (nOcc > 0.1)) enemyOccupiedNeighbors++;
            }
        }

        // A) Occupation Decay: If an enemy pocket is deep inside sovereign territory, it collapses.
        if (isOccupiedByEnemy && sovereignNeighbors >= 6) {
            occupationMap[idx] *= 0.8; // Aggressive decay
        }
        
        // B) Exclave Decay: If a friendly protrusion (finger) is surrounded by enemy occupation, it collapses.
        // This prevents the thin "tendrils" shown in the border gore feedback.
        if (isOccupiedBySelf && enemyOccupiedNeighbors >= 7) {
            occupationMap[idx] *= 0.75; 
        }
    }

    // Fade effect: slowly decay occupation values back to neutral
    if (CONFIG.OCCUPATION_FADE) {
        for (let i = 0; i < occupationMap.length; i++) {
            if (occupationMap[i] !== 0) {
                occupationMap[i] *= 0.98; // Gradual decay
                if (Math.abs(occupationMap[i]) < 0.001) occupationMap[i] = 0;
            }
        }
    }

    // 2. Statistics & Soldiers (Dynamic based on units)
    let p1T = 0, p2T = 0;
    for (let i = 0; i < occupationMap.length; i++) {
        if (landMask[i] === 2) {
            // Match visual frontline threshold (0)
            if (occupationMap[i] > 0) p1T++;
            else if (occupationMap[i] < 0) p2T++;
        }
    }
    const p1LandScore = (p1T + p2T > 0) ? (p1T / (p1T + p2T)) * 100 : 50;

    // Manpower is a fixed pool initialized at war start and reduced by casualties;
    // do not recompute it from current unit counts here.
    // We only ensure it never goes negative and keep casualties in sync with it below.
    teamASoldiers = Math.max(0, teamASoldiers);
    teamBSoldiers = Math.max(0, teamBSoldiers);

    // 3. AI & Combat (Including Mid-War Recruitment)
    
    // Optimization: Only count land every 15 frames or if specifically requested
    // This removes the biggest bottleneck of scanning 6.4 million pixels every tick.
    const shouldCountLand = simFrameCount % 15 === 0;
    if (shouldCountLand) {
        recalculateAllBounds();
        const countryFrontlines = new Map();
        sides.flat().forEach(c => countryFrontlines.set(c.id, 0));

        for (let i = 0; i < worldControlMap.length; i++) {
            if (landMask[i] === 2) {
                const sid = worldControlMap[i];
                const stats = countryStats.get(sid);
                if (stats) {
                    const sIdx = countryToSideMap.get(sid);
                    const isTeamA = sIdx % 2 === 0;
                    if ((isTeamA && occupationMap[i] > 0) || (!isTeamA && occupationMap[i] < 0)) {
                        stats.controlled++;
                    }

                    // Count frontline cells for saturation check
                    const neighbors = [i + 1, i - 1, i + gridWidth, i - gridWidth];
                    let isFront = false;
                    for (const n of neighbors) {
                        if (n >= 0 && n < worldControlMap.length) {
                            const nid = worldControlMap[n];
                            const nsid = countryToSideMap.get(nid);
                            if (nid > 0 && nsid !== undefined && (nsid % 2 !== sIdx % 2)) {
                                isFront = true;
                                break;
                            }
                        }
                    }
                    if (isFront) {
                        countryFrontlines.set(sid, countryFrontlines.get(sid) + 1);
                    }
                }
            }
        }

        // Determine saturation for each country
        sides.flat().forEach(c => {
            const stats = countryStats.get(c.id);
            const frontCount = countryFrontlines.get(c.id) || 0;
            // Strict Saturation Requirement: Nations must man 100% of their identified frontline before pushing.
            const saturationThreshold = 1.0; 
            if (stats) {
                if (stats.units >= frontCount * saturationThreshold) {
                    c.isSaturated = true;
                } else if (stats.units < frontCount * 0.6) {
                    // Drop saturation if decimated below 60% coverage to force regrouping
                    c.isSaturated = false;
                }
            }
        });
    } else {
        // Carry over stats from the last "counting" frame
        sides.flat().forEach(c => {
            const stats = countryStats.get(c.id);
            if (stats) stats.controlled = c.lastControlledCount || c.initialCells || 0;
        });
    }

    // Persist stats for next frame's "non-counting" logic
    sides.flat().forEach(c => {
        const stats = countryStats.get(c.id);
        if (stats && shouldCountLand) c.lastControlledCount = stats.controlled;
    });

    const unitsBySide = sides.map((_, idx) => units.filter(u => u.sideIndex === idx));

    // Calculate Victory Ratios for each side to coordinate surges
    const sideVictoryRatios = unitsBySide.map((sideUnits, sIdx) => {
        if (sideUnits.length === 0) return 0;
        const winners = sideUnits.filter(u => u.victoryBoostTicks > 0).length;
        const ratio = winners / sideUnits.length;

        // Global Surge State: Update coordinated push status for each side
        const sideCountries = sides[sIdx];
        if (sideCountries) {
            sideCountries.forEach(c => {
                // Lowered surge threshold to 60% momentum for more consistent offensive action.
                // A side starts a coordinated surge when victory momentum is good (>60%) 
                // and frontline saturation is achieved.
                if (!c.isSurging && ratio > 0.6 && c.isSaturated) {
                    c.isSurging = true;
                } 
                // The surge breaks and units hold once momentum falls below 35%.
                else if (c.isSurging && ratio < 0.35) {
                    c.isSurging = false;
                }
                
                // If not saturated, immediately kill any active surge to force line-filling.
                if (!c.isSaturated) c.isSurging = false;
            });
        }

        return ratio;
    });

    // Calculate centroids for each side to help with strategic "fanning out"
    // Group-Based Hive Intelligence: Partition each side into 4 tactical battle groups
    const numGroups = 4;
    const sideCentroids = sides.map((_, idx) => {
        const sideUnits = unitsBySide[idx];
        if (sideUnits.length === 0) return null;
        
        const groups = Array.from({length: numGroups}, () => ({ latSum: 0, lngSum: 0, count: 0, vLat: 0, vLng: 0 }));
        sideUnits.forEach(u => {
            const gIdx = Math.floor(u.id * 1000) % numGroups;
            groups[gIdx].latSum += u.lat;
            groups[gIdx].lngSum += u.lng;
            groups[gIdx].vLat += (u.dirLat || 0);
            groups[gIdx].vLng += (u.dirLng || 0);
            groups[gIdx].count++;
        });

        return groups.map(g => g.count > 0 ? {
            lat: g.latSum / g.count,
            lng: g.lngSum / g.count,
            vLat: g.vLat / g.count,
            vLng: g.vLng / g.count,
            count: g.count
        } : null);
    });

    // Pre-calculate collapsed nations for each side to avoid O(N^2) complexity inside the unit loop
    const sideToCollapsedNations = sides.map((side, idx) => {
        const enemies = [];
        sides.forEach((s, sIdx) => {
            const isEnemy = ffaMode ? (sIdx !== idx) : (sIdx % 2 !== idx % 2);
            if (isEnemy && s.length > 0) {
                s.forEach(c => {
                    const stats = countryStats.get(c.id);
                    if (stats && stats.units === 0 && stats.controlled > 0) {
                        // Support nations are only valid targets for mop-up if they've already been "activated"
                        // (meaning someone has managed to breach their border already).
                        if (c.role === 'SUPPORT') {
                            const initial = c.initialCells || 1;
                            if (stats.controlled >= initial * 0.99) {
                                // Virtually untouched support nation, ignore for now
                                return;
                            }
                        }
                        enemies.push(c);
                    }
                });
            }
        });
        // Prioritize OFFENSE nations in the mop-up list to ensure core enemies are finished first
        enemies.sort((a, b) => {
            const aOffense = (a.role === 'OFFENSE' ? 1 : 0);
            const bOffense = (b.role === 'OFFENSE' ? 1 : 0);
            return bOffense - aOffense;
        });
        return enemies;
    });

    const countryToCityCount = new Map();
    const countryCapitalLost = new Map();

    activeTheaterCities.forEach(city => {
        const idx = getGridIndex(city.lat, city.lng);
        const ownerId = primaryOccupierMap[idx];
        const originalSovereignId = city.sovereignId;

        if (ownerId > 0) {
            countryToCityCount.set(ownerId, (countryToCityCount.get(ownerId) || 0) + 1);
        }

        if (city.isCapital && originalSovereignId > 0) {
            const originalSide = countryToSideMap.get(originalSovereignId);
            const isPoleA = originalSide !== undefined && originalSide % 2 === 0;
            const occ = occupationMap[idx];
            
            // If the city is heavily occupied by the enemy side
            const isOccupiedByEnemy = isPoleA ? (occ < -0.3) : (occ > 0.3);
            if (isOccupiedByEnemy) {
                countryCapitalLost.set(originalSovereignId, true);
            }
        }
    });
    // Expose capital-loss state globally so recruitment/spawn logic can react to supply failure
    capitalLostCountries = new Set(countryCapitalLost.keys());

    // Mid-War Recruitment (Steady, Land-Capped, and Underdog-Aware)
    sides.forEach((side, sIdx) => {
        side.forEach(country => {
            const stats = countryStats.get(country.id);
            if (!stats) return;

            const currentUnits = stats.units;
            const initialLand = country.initialCells || 1;
            const currentLand = stats.controlled;
            
            const supplyFailed = capitalLostCountries.has(country.id);
            // Increased army caps to accommodate the much higher frontline saturation requirements.
            const multiplier = parseFloat(densitySlider.value) || 1.0;
            // Less aggressive size scaling to allow large empires to maintain thick lines.
            const sizeFactor = Math.max(1, currentLand / 2000);
            const densityScale = 1.0 / Math.pow(sizeFactor, 0.35);
            const landBasedCap = Math.max(8, Math.floor(currentLand * CONFIG.UNIT_DENSITY_FACTOR * 1.6 * multiplier * densityScale));
            const sideLimit = CONFIG.MAX_UNITS_PER_SIDE;
            
            // Flexible Limit: Capped much tighter to prevent unit-flooding on massive landmasses
            const flexibleLimit = sideLimit * (1 + Math.min(2.5, currentLand / 5000));
            let absoluteCap = Math.min(landBasedCap, flexibleLimit);
            
            // GODLY Buff: Higher cap and ignores flexible limits
            if (country.buffState === 'godly') {
                absoluteCap = Math.max(absoluteCap, 3600);
            }

            // If the capital has fallen, supply is failing: drastically limit total fieldable troops
            if (supplyFailed) {
                absoluteCap = Math.min(absoluteCap, 5);
            }

            if (currentUnits < absoluteCap) {
                const controlRatio = currentLand / initialLand; 
                const cityCount = countryToCityCount.get(country.id) || 0;
                const cityBonus = cityCount * 0.25; // Increased city importance
                
                // Manpower Scale: Diminishing returns on recruitment for massive nations
                // to prevent them from overwhelmingly flooding the screen with unit flags.
                const landRatio = currentLand / 2000; // Reference size
                let scaleFactor = Math.max(0.4, Math.pow(landRatio, 0.35));

                // Underdog Bonus: Slightly nerfed to prevent tiny nations from holding out forever
                const underdogFactor = (controlRatio < 0.3) ? (0.3 - controlRatio) * 1.5 : 0;
                
                // Boosted recruitment speed to help nations reach their higher push-thresholds faster.
                const baseRecruitmentChance = 0.007; 
                let recruitmentChance = baseRecruitmentChance * scaleFactor * (controlRatio + cityBonus + underdogFactor) * multiplier;
                
                if (country.buffState === 'godly') {
                    recruitmentChance *= 12.0; // 12x recruitment speed
                }

                // If the capital is lost, recruitment almost collapses
                if (supplyFailed) {
                    recruitmentChance *= 0.1; // 90% reduction in new troops
                }
                
                if (Math.random() < recruitmentChance) {
                    spawnSingleUnit(sIdx, country.id, sIdx % 2 === 0 ? 'A' : 'B');
                }
            }
        });
    });

    // Precompute city list once per tick for city‑focus mode
    const cityTargets = cityFocusMode ? (activeTheaterCities && activeTheaterCities.length ? activeTheaterCities : cities) : null;

    for (let i = units.length - 1; i >= 0; i--) {
        const u = units[i];
        
        // Scrub NaN units immediately to prevent rendering crashes
        if (isNaN(u.lat) || isNaN(u.lng)) {
            units.splice(i, 1);
            continue;
        }

        u.dirLat = 0; u.dirLng = 0; // Reset movement indicators for the current tick
        u.activeTargetPos = null; // Reset target pos for the current tick (used for arrows)
        
        // Handle deployment/mobilization phase
        if (u.deployTicks > 0) {
            u.deployTicks--;
            continue; // Skip AI and movement while deploying
        }

        let sideIndex = u.sideIndex !== undefined ? u.sideIndex : (u.team === 'A' ? 0 : 1);
        const gIdx = Math.floor(u.id * 1000) % numGroups;
        const centroids = sideCentroids[sideIndex];
        const groupCentroid = centroids ? centroids[gIdx] : null;

        // Ensure sideIndex is valid if sides were removed via capitulation
        if (sideIndex >= sides.length) sideIndex = sides.length - 1;
        if (sideIndex < 0) sideIndex = 0;
        
        // Sync index back to object for the renderer
        u.sideIndex = sideIndex;

        const sideList = sides[sideIndex];
        if (!sideList) continue;

        const countryObj = sideList.find(c => c.id === u.sovereignId);
        const isDefensive = countryObj?.strategy === 'DEFENSIVE';
        
        let damageDealtMult = 1.0;
        let damageTakenMult = 1.0;
        let speedBuffMult = 1.0;

        // Victory Boost Logic: Momentum Phase
        if (u.victoryBoostTicks > 0) {
            u.victoryBoostTicks--;
            damageDealtMult *= 1.4; // Reduced damage boost for longer battles
            speedBuffMult *= 1.3;  // Reduced speed boost for slower pushing
        }

        // Capital Loss Penalty (Nerfed to prevent instant collapse of smaller nations)
        if (countryCapitalLost.has(u.sovereignId)) {
            damageDealtMult *= 0.8; // 20% reduction (was 35%)
            damageTakenMult *= 1.15; // 15% more vulnerable (was 25%)
            speedBuffMult *= 0.9;    // 10% slower (was 20%)
        }
        
        const gridIdxNow = getGridIndex(u.lat, u.lng);
        const isAtSea = gridIdxNow === -1 || landMask[gridIdxNow] === 0;
        const mountainIntensity = (mountainsEnabled && gridIdxNow !== -1) ? terrainMask[gridIdxNow] : 0;
        const isMountain = mountainIntensity > 0;
        const currentControl = getControlValue(u.lat, u.lng);

        // Optional city‑focus movement target (does not affect combat logic)
        let cityFocusTarget = null;
        if (cityFocusMode && cityTargets && cityTargets.length) {
            const teamPole = (u.team === 'A') ? 1 : -1;
            let bestCity = null;
            let bestCityDistSq = Infinity;
            for (let cIdx = 0; cIdx < cityTargets.length; cIdx++) {
                const city = cityTargets[cIdx];
                const cv = getControlValue(city.lat, city.lng);
                // Prefer enemy or contested cities
                const isGoodTarget =
                    (teamPole > 0 && cv < 0.4) ||
                    (teamPole < 0 && cv > -0.4);
                if (!isGoodTarget) continue;
                const dSq = (u.lat - city.lat) ** 2 + (u.lng - city.lng) ** 2;
                if (dSq < bestCityDistSq) {
                    bestCityDistSq = dSq;
                    bestCity = city;
                }
            }
            if (bestCity) {
                cityFocusTarget = { lat: bestCity.lat, lng: bestCity.lng };
            }
        }

        if (countryObj) {
            if (countryObj.buffState === 'buff') {
                damageDealtMult = 2.5;
                damageTakenMult = 0.6;
                speedBuffMult = 1.3;
            } else if (countryObj.buffState === 'super') {
                damageDealtMult = 10.0;
                damageTakenMult = 0.2;
                speedBuffMult = 1.8;
            } else if (countryObj.buffState === 'godly') {
                damageDealtMult = 40.0;
                damageTakenMult = 0.015;
                speedBuffMult = 2.2;
            } else if (countryObj.buffState === 'weakened') {
                damageDealtMult = 0.7;
                damageTakenMult = 1.4;
                speedBuffMult = 0.9;
            } else if (countryObj.buffState === 'crippled') {
                damageDealtMult = 0.4;
                damageTakenMult = 2.5;
                speedBuffMult = 0.7;
            }

            // Continuous attack/defense modifiers from sliders (-90% .. +90%)
            const atkPct = typeof countryObj.attackBuffPercent === 'number' ? countryObj.attackBuffPercent : 0;
            const defPct = typeof countryObj.defenseBuffPercent === 'number' ? countryObj.defenseBuffPercent : 0;
            const atkFactor = 1 + (atkPct / 100);
            const defFactor = 1 + (defPct / 100);
            if (atkFactor > 0) damageDealtMult *= atkFactor;
            // positive defPct reduces damageTaken (tougher), negative increases (softer)
            if (defFactor > 0.01) damageTakenMult *= (1 / defFactor);
        }

        // Terrain Modifiers: Mountains reduce speed and lethality based on intensity (size/scale)
        if (isMountain) {
            // Intensity 1.0 = full penalty, Intensity 0.1 = minimal penalty
            speedBuffMult *= (1.0 - (0.65 * mountainIntensity)); 
            damageDealtMult *= (1.0 - (0.4 * mountainIntensity));
            damageTakenMult *= (1.0 - (0.4 * mountainIntensity));
        }

        // Alpenjägers: small, quiet buffs with emphasis on mountain warfare
        if (u.isAlpenjager) {
            if (isMountain) {
                speedBuffMult *= CONFIG.ALPEN_MTN_SPEED_MULT;
            }
            damageDealtMult *= CONFIG.ALPEN_COMBAT_MULT;
            damageTakenMult *= (1.0 / CONFIG.ALPEN_COMBAT_MULT);
        }

        // Exile Disbandment: If a navy is at sea and its nation has lost all land, it slowly disbands
        if (isAtSea && countryObj) {
            const stats = countryStats.get(u.sovereignId);
            if (stats && stats.controlled === 0) {
                if (Math.random() < 0.02) { // Gradual disappearance of exiled navies
                    units.splice(i, 1);
                    continue;
                }
            }
        }

        // --- ENCIRCLEMENT DETECTION ---
        let encirclementFactor = 0;
        const isMega = countryObj?.buffState === 'super';
        const isSuper = countryObj?.buffState === 'buff';
        const isWeak = countryObj?.buffState === 'weakened';
        const isCripple = countryObj?.buffState === 'crippled';

        if (!isAtSea && !isMega && !isSuper) {
            const eR = CONFIG.ENCIRCLEMENT_RADIUS;
            const samples = [
                [0, eR], [0, -eR], [eR, 0], [-eR, 0], 
                [eR*0.7, eR*0.7], [-eR*0.7, -eR*0.7], [eR*0.7, -eR*0.7], [-eR*0.7, eR*0.7]
            ];
            let enemyCount = 0;
            samples.forEach(([dlng, dlat]) => {
                const val = getControlValue(u.lat + dlat, u.lng + dlng);
                const sIdx = getGridIndex(u.lat + dlat, u.lng + dlng);
                // Geography (water) should NOT count as an enemy encirclement point. 
                // Only actual enemy-controlled territory cuts off supplies.
                // This prevents units from instantly dying upon landing on coastlines.
                if (sIdx !== -1 && landMask[sIdx] > 0) {
                    if (u.team === 'A' ? val < -0.1 : val > 0.1) {
                        enemyCount++;
                    }
                }
            });
            encirclementFactor = enemyCount / samples.length;
        }
        const isEncircled = encirclementFactor > 0.75;

        if (isEncircled && !isMega && !isSuper) {
            damageDealtMult *= 0.25; // Massive reduction in combat effectiveness
            damageTakenMult *= 4.0;  // Extremely vulnerable to attacks
        }

        // Attrition logic: logistics strain increases the further you push into large nations
        const inEnemyTerritory = !isAtSea && ((u.team === 'A' && currentControl < -0.2) || (u.team === 'B' && currentControl > 0.2));
        
        // Attrition is disabled during Victory Boost (momentum) to prevent breakthroughs from stalling instantly
        if ((inEnemyTerritory || isEncircled) && !isMega && !isSuper && u.victoryBoostTicks <= 0) {
            // Logistics Strain: Attrition scales with the target's total land area
            let targetLandSize = 0;
            const enemySideIndices = sides.map((_, idx) => idx).filter(idx => ffaMode ? idx !== sideIndex : idx % 2 !== sideIndex % 2);
            enemySideIndices.forEach(idx => {
                sides[idx].forEach(enemy => {
                    const s = countryStats.get(enemy.id);
                    if (s) targetLandSize += s.controlled;
                });
            });

            const logisticsPenalty = Math.max(1, Math.log10(targetLandSize / 500 + 1));
            let dmg = CONFIG.ATTRITION_DAMAGE * (1 + Math.abs(currentControl) * 3) * logisticsPenalty;
            
            if (isEncircled) dmg *= CONFIG.ENCIRCLEMENT_DAMAGE_MULT; 
            recordDamage(u, dmg * damageTakenMult);

            // Instant death triggers full remaining health as casualties
            if (isEncircled && Math.random() < 0.001) {
                recordDamage(u, u.health);
            }
        }

        // --- EXPEDITIONARY SUPPORT SYSTEM ---
        const role = countryObj?.role || 'OFFENSE';
        const alliesMetadata = sideList.filter(c => c.id !== u.sovereignId);
        const offensiveAllies = alliesMetadata.filter(c => c.role === 'OFFENSE');

        if (role === 'SUPPORT') {
            if (offensiveAllies.length > 0) {
                if (!u.beneficiaryId || u.beneficiaryId === u.sovereignId || !offensiveAllies.some(a => a.id === u.beneficiaryId)) {
                    u.beneficiaryId = offensiveAllies[Math.floor(Math.random() * offensiveAllies.length)].id;
                }
            } else if (alliesMetadata.length > 0) {
                if (!u.beneficiaryId || u.beneficiaryId === u.sovereignId) {
                    u.beneficiaryId = alliesMetadata[Math.floor(Math.random() * alliesMetadata.length)].id;
                }
            } else {
                u.beneficiaryId = u.sovereignId;
            }
        } else {
            // Offensive units: Drastically reduced chance to randomly wander off to support allies (like Britain to Canada)
            // unless their sovereign land is almost entirely occupied.
            const myStats = countryStats.get(u.sovereignId);
            const myInitial = (countryObj?.initialCells || 1);
            const beingOverrun = myStats ? (myStats.controlled < myInitial * 0.3) : false;
            
            // Significantly reduced probability to wander to an ally's territory (0.02% per frame)
            if (!beingOverrun && Math.random() < 0.0002 && alliesMetadata.length > 0) {
                u.beneficiaryId = alliesMetadata[Math.floor(Math.random() * alliesMetadata.length)].id;
            } else if (Math.random() < 0.12 || !u.beneficiaryId) {
                // High chance to reset to sovereign target to ensure focus on the main theater
                u.beneficiaryId = u.sovereignId;
            }
        }

        // Tactical Awareness: Identify enemies and local balance of power
        let enemies = [];
        sides.forEach((_, idx) => {
            const isEnemySide = ffaMode ? (idx !== sideIndex) : (idx % 2 !== sideIndex % 2);
            if (isEnemySide) enemies = enemies.concat(unitsBySide[idx]);
        });

        let target = null;
        let minDist = Infinity;
        let retreatVector = null;

        // Tactical sensor for retreat logic
        const tacticalRadiusSq = 0.6 * 0.6;
        const repulsionRadiusSq = 0.45 * 0.45; // Increased spread to prevent stacking
        let localEnemyCount = 0;
        let localAllyCount = 1; // Including self
        let enemyCentroidLat = 0;
        let enemyCentroidLng = 0;

        // Efficient unified scan for target finding and tactical assessment
        // Optimization: Increase step significantly for giant unit counts (O(N^2) bottleneck)
        let step = 1;
        if (enemies.length > 500) step = 15;
        else if (enemies.length > 200) step = 8;
        
        const isRebelUnit = activeRebellion && u.sovereignId === activeRebellion.rebelId;
        const isAlpen = !!u.isAlpenjager;

        // If city‑focus mode is on, seed target with nearest city before unit‑target logic
        if (cityFocusTarget) {
            target = cityFocusTarget;
            // minDist is screen‑space later; just keep placeholder for comparison with unit targets
            const dSqCity = (u.lat - cityFocusTarget.lat) ** 2 + (u.lng - cityFocusTarget.lng) ** 2;
            minDist = dSqCity;
        }

        for(let j=0; j<enemies.length; j+=step) {
            const e = enemies[j];
            const eIdx = getGridIndex(e.lat, e.lng);
            const eAtSea = eIdx === -1 || landMask[eIdx] === 0;

            // Global Wrap: Calculate shortest longitude delta
            let deLng = e.lng - u.lng;
            if (deLng > 180) deLng -= 360;
            else if (deLng < -180) deLng += 360;

            // REBEL / DEFENSIVE strategy logic: Do not chase enemies deep into their own territory
            if ((isDefensive || isRebelUnit) && !isAtSea) {
                const isEnemyInMyMandatedLand = eIdx !== -1 && (isRebelUnit ? deJureMap[eIdx] === u.sovereignId : worldControlMap[eIdx] === u.sovereignId);
                if (!isEnemyInMyMandatedLand) {
                    const dSqToEnemy = (u.lat - e.lat)**2 + (deLng)**2;
                    // Strict border tethering: Only target if enemy is inside or right on the doorstep (0.3 deg)
                    if (dSqToEnemy > 0.09) continue; 
                }
            }
            
            let distMult = 1.0;
            if (eAtSea && !isAtSea) {
                // Massive penalty for sea units to prevent land units from being lured away
                distMult = 50.0; 
            }

            // Add slight spatial noise to target seeking to prevent units from following perfect single-file paths
            const noise = (Math.sin(u.id + simFrameCount * 0.02) * 0.03);
            const dSq = ((u.lat - e.lat + noise)**2 + (deLng + noise)**2) * distMult;
            
            // Check for nearest target
            if (dSq < minDist) {
                minDist = dSq;
                target = e;
            }

            // Check for local overwhelming force
            if (dSq < tacticalRadiusSq) {
                // Weight powerful units massively to trigger enemy retreats
                let eWeight = step;

                // Naval units exert significantly less tactical pressure/intimidation on enemies
                if (eAtSea) {
                    eWeight *= (isAtSea ? 0.6 : 0.2);
                }

                const eSideIdx = countryToSideMap.get(e.sovereignId);
                const eCountry = eSideIdx !== undefined ? sides[eSideIdx].find(c => c.id === e.sovereignId) : null;
                
                if (eCountry?.buffState === 'super') eWeight *= 200; // Mega
                else if (eCountry?.buffState === 'buff') eWeight *= 50; // Super
                
                localEnemyCount += eWeight;
                enemyCentroidLat += e.lat * eWeight;
                enemyCentroidLng += e.lng * eWeight;

                // Proximity damage: Units "pushing" into each other deal damage even before perfectly overlapping
                // Toned down to prevent instant vaporization of clashing frontline clusters
                if (dSq < 0.04) { // within ~0.2 degrees
                    let proximityDamage = (CONFIG.COMBAT_DAMAGE * 0.07) * damageDealtMult * (1.0 - Math.sqrt(dSq)/0.2) * step;
                    
                    // Naval units clash: Sea battles are more high-stakes and lethal
                    if (isAtSea && eAtSea) {
                        proximityDamage *= 2.2;
                    }

                    // Casualties increase while battling (proximity clash)
                    recordDamage(e, proximityDamage);
                    recordDamage(u, (proximityDamage * 0.8) * damageTakenMult);
                    
                    u.lastCombatTick = simFrameCount;
                    e.lastCombatTick = simFrameCount;

                    if (e.health <= 0) {
                        u.victoryBoostTicks = 240;
                    }

                    // Group into battles for visual clustering
                    let existing = activeBattles.find(b => {
                        const db = (u.lat - b.lat)**2 + (u.lng - b.lng)**2;
                        return db < 0.16; // 0.4 degree clustering radius
                    });
                    if (existing) {
                        existing.participants++;
                        // Incremental average for center
                        existing.lat = (existing.lat * (existing.participants - 1) + (u.lat + e.lat) / 2) / existing.participants;
                        existing.lng = (existing.lng * (existing.participants - 1) + (u.lng + e.lng) / 2) / existing.participants;
                    } else {
                        activeBattles.push({
                            lat: (u.lat + e.lat) / 2,
                            lng: (u.lng + e.lng) / 2,
                            participants: 2
                        });
                    }
                }
            }
        }

        // Count nearby allies for context
        const myAllies = unitsBySide[sideIndex];
        u.lastAllyCount = localAllyCount; // Store for influence weight calculation
        const aStep = myAllies.length > 100 ? 4 : 1;
        for (let j = 0; j < myAllies.length; j += aStep) {
            const a = myAllies[j];
            if (a === u) continue;
            
            let daLng = a.lng - u.lng;
            if (daLng > 180) daLng -= 360;
            else if (daLng < -180) daLng += 360;

            const dSq = (u.lat - a.lat)**2 + (daLng)**2;
            if (dSq < tacticalRadiusSq) {
                let aWeight = aStep;
                const aSideIdx = countryToSideMap.get(a.sovereignId);
                const aCountry = aSideIdx !== undefined ? sides[aSideIdx].find(c => c.id === a.sovereignId) : null;
                
                if (aCountry?.buffState === 'super') aWeight *= 200;
                else if (aCountry?.buffState === 'buff') aWeight *= 50;
                
                localAllyCount += aWeight;

                // Repulsion to prevent massive stacks in pockets
                if (dSq < repulsionRadiusSq && dSq > 0.00001) {
                    const d = Math.sqrt(dSq);
                    if (!u.repulsionVector) u.repulsionVector = { lat: 0, lng: 0 };
                    u.repulsionVector.lat += (u.lat - a.lat) / d;
                    u.repulsionVector.lng += (u.lng - a.lng) / d;
                }
            }
        }

        // Retreat logic: If enemy force is > 5x ally force (increased threshold to prevent premature dodging)
        if (localEnemyCount > localAllyCount * 8 && localEnemyCount >= 5) {
            const avgLat = enemyCentroidLat / localEnemyCount;
            const avgLng = enemyCentroidLng / localEnemyCount;
            const dirLat = u.lat - avgLat;
            const dirLng = u.lng - avgLng;
            const mag = Math.sqrt(dirLat*dirLat + dirLng*dirLng);
            if (mag > 0) {
                retreatVector = { lat: dirLat/mag, lng: dirLng/mag };
            }
        }

        const collapsedEnemyNations = sideToCollapsedNations[sideIndex] || [];
        
        const targetIdx = target ? getGridIndex(target.lat, target.lng) : -1;
        const targetAtSea = target && (targetIdx === -1 || landMask[targetIdx] === 0);
        
        // Unified behavior: Units hunt enemies when nearby, but switch to focused territory capture (mop-up) 
        // when enemies are further than a local threshold.
        // Increased threshold to 1.5 so units are more aggressive about chasing nearby hostiles before roaming.
        const mopUpDistThreshold = 1.5; 
        // Only enter mop‑up mode when there are truly no enemy units left;
        // as long as enemies exist, units should prioritize fighting them instead of roaming.
        const shouldMopUp = (enemies.length === 0);

        // Target Caching: Only re-search for targets every few ticks to save CPU
        if (u.targetSearchCooldown > 0) {
            u.targetSearchCooldown--;
        }

        // Frontline Pressure: If unit is too close to a moving/losing border, push it back
        const borderBuffer = 0.06; // Narrower buffer so units sit "right on" the frontline
        const currentIdx = getGridIndex(u.lat, u.lng);
        const currentOwnerId = currentIdx !== -1 ? worldControlMap[currentIdx] : 0;
        const currentOwnerSideIdx = countryToSideMap.get(currentOwnerId);
        
        // Tactical Control: If we significantly occupy the land, it's not "enemy land" for movement purposes
        // Broadened "friendly" land check to make units wait further back from the actual border
        const isEffectivelyMyLand = (u.team === 'A' && currentControl > 0.35) || (u.team === 'B' && currentControl < -0.35);
        const isOnEnemyLand = !isEffectivelyMyLand && currentOwnerSideIdx !== undefined && (currentOwnerSideIdx % 2 !== sideIndex % 2);

        // Mega and Super units are immune to the automatic pushback; they ARE the pushback.
        // BUG FIX: Units were being "pushed back" and taking skirmish damage even when attacking into enemy land.
        // Pushback now only triggers if the unit is on friendly/sovereign territory that is being overrun by enemies.
        const ownerIdAtUnit = currentIdx !== -1 ? worldControlMap[currentIdx] : 0;
        const ownerSideIdx = countryToSideMap.get(ownerIdAtUnit);
        const onFriendlySovereignLand = ownerSideIdx !== undefined && (ownerSideIdx % 2 === sideIndex % 2);

        const isTooNearBorder = !isAtSea &&
            !isMega &&
            !isSuper &&
            onFriendlySovereignLand &&
            // Only treat tiles that are part of the active warzone as "border band"
            currentIdx !== -1 &&
            landMask[currentIdx] === 2 &&
            (
                (u.team === 'A' && (currentControl < borderBuffer)) ||
                (u.team === 'B' && (currentControl > -borderBuffer))
            );

        // Direction toward nearby frontline (used to pull units to the border instead of roaming)
        const borderDir = getBorderDirection(u);
        
        if (isTooNearBorder && !isAtSea) {
            // Frontline Skirmish Damage: Being pushed back by an advancing border is taxing and represents rear-guard casualties
            const skirmishDamage = CONFIG.COMBAT_DAMAGE * 0.15 * (1.0 + Math.abs(currentControl) * 2);
            recordDamage(u, skirmishDamage * damageTakenMult);

            // Find direction of safety (deeper into friendly territory) by sampling nearby grid
            let bestLat = 0, bestLng = 0, bestVal = u.team === 'A' ? -Infinity : Infinity;
            const sDist = 0.6; // Sample further out to find safe haven
            const samples = [
                [0, sDist], [0, -sDist], [sDist, 0], [-sDist, 0], 
                [sDist*0.7, sDist*0.7], [-sDist*0.7, -sDist*0.7], [sDist*0.7, -sDist*0.7], [-sDist*0.7, sDist*0.7]
            ];
            
            samples.forEach(([dlng, dlat]) => {
                const sampleLat = u.lat + dlat;
                const sampleLng = u.lng + dlng;
                const val = getControlValue(sampleLat, sampleLng);
                const sIdx = getGridIndex(sampleLat, sampleLng);
                const isSampleLand = sIdx !== -1 && landMask[sIdx] > 0;
                
                // Score samples: prioritize land and friendly control
                let score = val;
                
                const sampleOwnerId = sIdx !== -1 ? worldControlMap[sIdx] : 0;
                const isSampleAlly = sideList.some(c => c.id === sampleOwnerId);

                if (!isSampleLand) {
                    // Sea is the ultimate retreat penalty
                    score = u.team === 'A' ? -999 : 999;
                } else if (isNeutralCountry(sIdx)) {
                    // Neutral land is "lava" - absolute priority is to stay out of non-combatant territory
                    score = u.team === 'A' ? -2500 : 2500;
                } else if (!isSampleAlly) {
                    // Enemy land is also a bad retreat destination but slightly more viable than neutral "lava"
                    score = u.team === 'A' ? -800 : 800;
                }

                if (u.team === 'A' ? score > bestVal : score < bestVal) {
                    bestVal = score;
                    bestLat = dlat;
                    bestLng = dlng;
                }
            });
            
            if (bestVal !== (u.team === 'A' ? -Infinity : Infinity)) {
                const mag = Math.sqrt(bestLat*bestLat + bestLng*bestLng);
                if (mag > 0) {
                    if (!retreatVector) retreatVector = { lat: 0, lng: 0 };
                    // Strong pushback force to ensure they outrun the advancing frontline
                    retreatVector.lat += (bestLat / mag) * 6.0;
                    retreatVector.lng += (bestLng / mag) * 6.0;
                }
            }
        }

        if (shouldMopUp) {
            // Mop-up mode: Enemy has no units or target is far and collapsed nations exist
            let enemyId = -1;
            const isRebel = activeRebellion && u.sovereignId === activeRebellion.rebelId;
            
            if (isRebel) {
                // REBELS: Target their own de jure land exclusively
                enemyId = u.sovereignId;
            } else if (isDefensive) {
                // DEFENSIVE: Target own nation to find occupied cells to reclaim
                enemyId = u.sovereignId;
            } else if (collapsedEnemyNations.length > 0) {
                // If there are multiple collapsed nations, prioritize the first few (which are sorted by OFFENSE role)
                const candidates = collapsedEnemyNations.slice(0, 3);
                enemyId = candidates[Math.floor(Math.random() * candidates.length)].id;
            } else {
                const possibleEnemySides = sides.filter((s, idx) => {
                    if (ffaMode) return idx !== sideIndex;
                    return idx % 2 !== sideIndex % 2;
                }).filter(s => s.length > 0);
                
                if (possibleEnemySides.length > 0) {
                    const randomEnemySide = possibleEnemySides[Math.floor(Math.random() * possibleEnemySides.length)];
                    const randomEnemyCountry = randomEnemySide[Math.floor(Math.random() * randomEnemySide.length)];
                    enemyId = randomEnemyCountry?.id || -1;
                }
            }

            // If supporting an ally and no enemies nearby, move towards their frontlines
            // Only actually go to the ally if that ally is losing land (has occupation)
            let activeSupportTarget = null;
            if (u.beneficiaryId !== u.sovereignId) {
                const ally = sideList.find(c => c.id === u.beneficiaryId);
                const allyStats = countryStats.get(u.beneficiaryId);
                const allyInitial = ally?.initialCells || 1;
                // Only support allies that are at least 5% occupied to prevent unnecessary wandering
                if (ally && allyStats && allyStats.controlled < allyInitial * 0.95) {
                    activeSupportTarget = ally;
                } else {
                    // Force redirect back to sovereign/enemy goals if ally is safe
                    u.beneficiaryId = u.sovereignId;
                }
            }

            const needsNewTarget = !u.mopUpTarget || 
                                 (u.targetSearchCooldown <= 0) || 
                                 (u.lastMopUpId && u.lastMopUpId !== (activeSupportTarget ? activeSupportTarget.id : enemyId));

            if (needsNewTarget) {
                u.targetSearchCooldown = 15 + Math.floor(Math.random() * 20); // 0.25s - 0.6s cache
                const targetId = activeSupportTarget ? activeSupportTarget.id : enemyId;
                u.lastMopUpId = targetId;
                let bestCellIdx = -1;
                let bestScore = -Infinity;
                const isTeamA = u.team === 'A';
                
                // Calculate unit's relative position in its team cluster to maintain "lane" seeking
                const relLat = groupCentroid ? u.lat - groupCentroid.lat : 0;
                const relLng = groupCentroid ? u.lng - groupCentroid.lng : 0;

                // United Push Targeting: Sample cells heavily focused on the actual front rather than deep roaming.
                for (let j = 0; j < 250; j++) {
                    const randIdx = Math.floor(Math.random() * worldControlMap.length);
                    const ownerAtIdx = worldControlMap[randIdx];
                    const deJureAtIdx = deJureMap[randIdx];

                    let isCandidate = false;
                    if (isRebel) {
                        if (deJureAtIdx === activeRebellion.rebelId) {
                            const occ = occupationMap[randIdx];
                            if ((isTeamA && occ < 0.95) || (!isTeamA && occ > -0.95)) isCandidate = true;
                        }
                    } else if (ownerAtIdx === targetId) {
                        const occ = occupationMap[randIdx];
                        if (isDefensive) {
                            if ((isTeamA && occ < 0.98) || (!isTeamA && occ > -0.98)) isCandidate = true;
                        } else {
                            if ((isTeamA && occ < 0.85) || (!isTeamA && occ > -0.85)) isCandidate = true;
                        }
                    }

                    if (isCandidate) {
                        const cy = Math.floor(randIdx / gridWidth);
                        const cx = randIdx % gridWidth;
                        const cLat = (cy * CONFIG.GRID_RES) - 90;
                        const cLng = (cx * CONFIG.GRID_RES) - 180;

                        // Hive Sector Logic: Bias groups toward specific geographic arcs to create organized fronts
                        const sectorAngle = (gIdx / numGroups) * Math.PI * 2;
                        const sectorLat = Math.sin(sectorAngle) * 45;
                        const sectorLng = Math.cos(sectorAngle) * 45;
                        
                        // Distance to assigned squad sector
                        const sectorDistSq = (cLat - sectorLat)**2 + (cLng - sectorLng)**2;
                        const sectorBias = Math.max(0, 100 - sectorDistSq * 0.05);

                        let dcLng = cLng - u.lng;
                        if (dcLng > 180) dcLng -= 360;
                        else if (dcLng < -180) dcLng += 360;

                        const distSq = (u.lat - cLat)**2 + (dcLng)**2;
                        const occ = occupationMap[randIdx];
                        const occFavor = (1.0 - Math.abs(occ)) * 120; 
                        
                        // Combinatorial score: Proximity + Frontline Freshness + Squad Sector Focus
                        let score = occFavor - (distSq * 0.4) + sectorBias;

                        // ALASKA & ARCTIC PENALTY: Discourage units from roaming to Alaska or far north islands 
                        // when Fighting in North America. This forces them to prioritize the Mainland US/Canada borders.
                        const isAlaska = cLat > 54 && cLng < -130;
                        const isArctic = cLat > 65;
                        
                        if (isAlaska) score -= 1500;
                        if (isArctic) score -= 800;

                        // MAINLAND THEATER BOOST: Encourage units to target "The Heartland" (Lower 48 / Europe core)
                        if (cLat > 25 && cLat < 50 && cLng > -125 && cLng < -65) score += 200; // US Mainland
                        if (cLat > 35 && cLat < 60 && cLng > -10 && cLng < 40) score += 200; // Europe Core
                        
                        if (score > bestScore) {
                            bestScore = score;
                            bestCellIdx = randIdx;
                        }
                    }
                }

                if (bestCellIdx !== -1) {
                    const y = Math.floor(bestCellIdx / gridWidth);
                    const x = bestCellIdx % gridWidth;
                    u.mopUpTarget = {
                        lat: (y * CONFIG.GRID_RES) - 90,
                        lng: (x * CONFIG.GRID_RES) - 180
                    };
                } else {
                    // Fallback: If no priority cells found, target ANY cell of the target nation.
                    // This prevents units (especially defensive or weakened ones) from freezing when priority targets are gone.
                    for (let j = 0; j < 80; j++) {
                        const randIdx = Math.floor(Math.random() * worldControlMap.length);
                        if (worldControlMap[randIdx] === targetId) {
                            const y = Math.floor(randIdx / gridWidth);
                            const x = randIdx % gridWidth;
                            u.mopUpTarget = { 
                                lat: (y * CONFIG.GRID_RES) - 90, 
                                lng: (x * CONFIG.GRID_RES) - 180 
                            };
                            break;
                        }
                    }
                }
            }
            target = u.mopUpTarget;
        }

        // CITY-FOCUS COMBAT MODE:
        // When enabled, AI movement targeting prioritizes cities as primary objectives,
        // using unit positions only for local combat/retreat decisions.
        if (cityFocusMode && cityFocusTarget) {
            target = cityFocusTarget;
        }

        if (target) {
            // Store target position for the renderer's operational arrows
            u.activeTargetPos = { lat: target.lat, lng: target.lng };

            // Spatial Jitter: Add a small, unit-specific offset to the target destination
            // to prevent multiple units from converging on the exact same coordinate.
            const jitterScale = 0.08;
            const jitterLat = target.lat + (Math.sin(u.id * 100) * jitterScale);
            const jitterLng = target.lng + (Math.cos(u.id * 100) * jitterScale);
            
            let dLat = jitterLat - u.lat;
            let dLng = jitterLng - u.lng;
            
            // GLOBAL WRAP: Shortest path around the world
            if (dLng > 180) dLng -= 360;
            else if (dLng < -180) dLng += 360;

            const dist = Math.sqrt(dLat * dLat + dLng * dLng);

            const isEngaged = u.lastCombatTick && (simFrameCount - u.lastCombatTick < 2);
            if (dist > 0.05 && !isEngaged) {
                // Movement logic
                const baseSpeed = isAtSea ? CONFIG.UNIT_NAVAL_SPEED : CONFIG.UNIT_SPEED;
                
                // Roaming Prevention: Removed exploratory wiggle to force a focused linear push
                const landSpeedBuff = (!isAtSea && ((u.team === 'A' && currentControl > 0.5) || (u.team === 'B' && currentControl < -0.5))) ? 1.8 : 1.2;
                const speedMult = landSpeedBuff * speedBuffMult;

                let moveDirLat = dLat / dist;
                let moveDirLng = dLng / dist;

                // Pull towards nearby frontline so units hug the border instead of roaming deep interiors
                if (borderDir && !isAtSea) {
                    // Force units to prioritize the frontline even more heavily to prevent the "interior roaming" seen in clusters.
                    const blendStrength = 0.9;
                    moveDirLat = moveDirLat * (1 - blendStrength) + borderDir.lat * blendStrength;
                    moveDirLng = moveDirLng * (1 - blendStrength) + borderDir.lng * blendStrength;
                    const magBorder = Math.sqrt(moveDirLat * moveDirLat + moveDirLng * moveDirLng);
                    if (magBorder > 0) {
                        moveDirLat /= magBorder;
                        moveDirLng /= magBorder;
                    }
                }

                // Apply tactical retreat/border pushback
                let activeRetreat = false;
                if (retreatVector) {
                    const rMag = Math.sqrt(retreatVector.lat**2 + retreatVector.lng**2);
                    if (rMag > 0) {
                        activeRetreat = true;
                        const rDirLat = retreatVector.lat / rMag;
                        const rDirLng = retreatVector.lng / rMag;
                        
                        // Blend target direction with retreat direction
                        // Reduced retreat strength so units don't "dodge" and sprint away entirely, 
                        // allowing them to keep some forward pressure while backing off.
                        const inHostileLand = (u.team === 'A' && currentControl < 0) || (u.team === 'B' && currentControl > 0);
                        const retreatStrength = inHostileLand ? 0.4 : 0.25; 
                        
                        moveDirLat = moveDirLat * (1 - retreatStrength) + rDirLat * retreatStrength;
                        moveDirLng = moveDirLng * (1 - retreatStrength) + rDirLng * retreatStrength;
                        
                        const finalMag = Math.sqrt(moveDirLat**2 + moveDirLng**2);
                        if (finalMag > 0) {
                            moveDirLat /= finalMag;
                            moveDirLng /= finalMag;
                        }
                    }
                }

                // Hive Cohesion & Alignment: Units stick with their squad and move in unison
                if (groupCentroid && !isAtSea && !activeRetreat) {
                    // 1. Cohesion: Pull towards squad center
                    const dCentLat = groupCentroid.lat - u.lat;
                    const dCentLng = groupCentroid.lng - u.lng;
                    const dCentDist = Math.sqrt(dCentLat * dCentLat + dCentLng * dCentLng);
                    if (dCentDist > 0.1) {
                        const cohesionStr = 0.15;
                        moveDirLat += (dCentLat / dCentDist) * cohesionStr;
                        moveDirLng += (dCentLng / dCentDist) * cohesionStr;
                    }

                    // 2. Alignment: Match squad's average heading
                    if (Math.abs(groupCentroid.vLat) > 0.01 || Math.abs(groupCentroid.vLng) > 0.01) {
                        const alignStr = 0.25;
                        moveDirLat += groupCentroid.vLat * alignStr;
                        moveDirLng += groupCentroid.vLng * alignStr;
                    }
                    
                    const newMag = Math.sqrt(moveDirLat * moveDirLat + moveDirLng * moveDirLng);
                    if (newMag > 0) {
                        moveDirLat /= newMag;
                        moveDirLng /= newMag;
                    }
                }

                // Apply allied repulsion to ensure units spread out to borders
                // Suppression check: Repulsion is disabled during active retreats to prioritize survival
                if (u.repulsionVector && !activeRetreat) {
                    const rMag = Math.sqrt(u.repulsionVector.lat**2 + u.repulsionVector.lng**2);
                    if (rMag > 0) {
                        // Less aggressive repulsion so units keep their forward momentum and don't scatter sideways
                        const repulsionStrength = 0.4;
                        moveDirLat = moveDirLat * (1 - repulsionStrength) + (u.repulsionVector.lat / rMag) * repulsionStrength;
                        moveDirLng = moveDirLng * (1 - repulsionStrength) + (u.repulsionVector.lng / rMag) * repulsionStrength;
                        const finalMag = Math.sqrt(moveDirLat**2 + moveDirLng**2);
                        if (finalMag > 0) {
                            moveDirLat /= finalMag;
                            moveDirLng /= finalMag;
                        }
                    }
                    u.repulsionVector = null;
                }

                // Guided Pathfinding: Priority-based Corridor Seeking
                // Actively detours around neutral nations (like Czechoslovakia) to find internal routes.
                const isProtectedSupport = (idx) => {
                    if (idx === -1 || landMask[idx] === 0) return false;
                    const cellOwnerId = worldControlMap[idx];
                    const ownerSideIdx = countryToSideMap.get(cellOwnerId);
                    if (ownerSideIdx === undefined) return false;
                    const isEnemySupport = (ownerSideIdx % 2 !== sideIndex % 2) && role === 'OFFENSE' && sides[ownerSideIdx].find(c => c.id === cellOwnerId)?.role === 'SUPPORT';
                    if (isEnemySupport) {
                        const occ = occupationMap[idx];
                        return !((u.team === 'A' && occ > 0.1) || (u.team === 'B' && occ < -0.1));
                    }
                    return false;
                };

                const isInsideNeutral = isNeutralCountry(currentIdx) || isProtectedSupport(currentIdx);
                // Dynamic lookahead: units stuck inside or near neutral territory look further to find a valid corridor.
                const lookAheadDist = isInsideNeutral ? 1.6 : (isNeutralCountry(getGridIndex(u.lat + moveDirLat * 0.25, u.lng + moveDirLng * 0.25)) ? 1.2 : 0.6); 

                const lookIdx = getGridIndex(u.lat + moveDirLat * lookAheadDist, u.lng + moveDirLng * lookAheadDist);
                
                // Enhanced Neutral Awareness: Proactively detect neutral territory to prevent illegal border crossings
                if (isNeutralCountry(lookIdx) || isProtectedSupport(lookIdx) || isInsideNeutral) {
                    // Impending neutral border or already inside. Try to "pathfind" a local corridor that stays off neutral land.
                    let bestLat = moveDirLat;
                    let bestLng = moveDirLng;
                    let foundFriendly = false;

                    // Local corridor search: sweep angles and check both mid‑point and end‑point cells
                    // so we don't just step over a single neutral cell but actually route around it.
                    const sweepSteps = 24;
                    const sweepAngle = Math.PI; // 180° left/right around current heading
                    const corridorLook = lookAheadDist;
                    const midFactor = 0.5;

                    for (let j = 1; j <= sweepSteps; j++) {
                        const angleOff = (sweepAngle / sweepSteps) * j;
                        const checkAngles = [angleOff, -angleOff];

                        for (const a of checkAngles) {
                            const curCos = Math.cos(a);
                            const curSin = Math.sin(a);

                            // Candidate direction
                            const candLat = moveDirLat * curCos - moveDirLng * curSin;
                            const candLng = moveDirLat * curSin + moveDirLng * curCos;

                            // Sample mid‑point along this direction
                            const midLat = u.lat + candLat * corridorLook * midFactor;
                            const midLng = u.lng + candLng * corridorLook * midFactor;
                            const midIdx = getGridIndex(midLat, midLng);

                            // Sample end‑point along this direction
                            const endLat = u.lat + candLat * corridorLook;
                            const endLng = u.lng + candLng * corridorLook;
                            const endIdx = getGridIndex(endLat, endLng);

                            const midBlocked = midIdx !== -1 && (isNeutralCountry(midIdx) || isProtectedSupport(midIdx));
                            const endBlocked = endIdx !== -1 && (isNeutralCountry(endIdx) || isProtectedSupport(endIdx));

                            // We only accept directions where both mid and end are non‑neutral/non‑protected land.
                            if (
                                endIdx !== -1 &&
                                landMask[endIdx] > 0 &&
                                !midBlocked &&
                                !endBlocked
                            ) {
                                bestLat = candLat;
                                bestLng = candLng;
                                foundFriendly = true;
                                break;
                            }
                        }
                        if (foundFriendly) break;
                    }

                    if (!foundFriendly) {
                        // Second pass: search a slightly larger ring to get around wider neutral "blocks"
                        const farLook = corridorLook * 1.6;
                        for (let j = 1; j <= sweepSteps && !foundFriendly; j++) {
                            const angleOff = (sweepAngle / sweepSteps) * j;
                            const checkAngles = [angleOff, -angleOff];

                            for (const a of checkAngles) {
                                const curCos = Math.cos(a);
                                const curSin = Math.sin(a);

                                const candLat = moveDirLat * curCos - moveDirLng * curSin;
                                const candLng = moveDirLat * curSin + moveDirLng * curCos;

                                const midLat = u.lat + candLat * farLook * midFactor;
                                const midLng = u.lng + candLng * farLook * midFactor;
                                const midIdx = getGridIndex(midLat, midLng);

                                const endLat = u.lat + candLat * farLook;
                                const endLng = u.lng + candLng * farLook;
                                const endIdx = getGridIndex(endLat, endLng);

                                const midBlocked = midIdx !== -1 && (isNeutralCountry(midIdx) || isProtectedSupport(midIdx));
                                const endBlocked = endIdx !== -1 && (isNeutralCountry(endIdx) || isProtectedSupport(endIdx));

                                if (
                                    endIdx !== -1 &&
                                    landMask[endIdx] > 0 &&
                                    !midBlocked &&
                                    !endBlocked
                                ) {
                                    bestLat = candLat;
                                    bestLng = candLng;
                                    foundFriendly = true;
                                    break;
                                }
                            }
                        }
                    }

                    if (foundFriendly) {
                        const mag = Math.sqrt(bestLat**2 + bestLng**2);
                        if (mag > 0) {
                            moveDirLat = bestLat / mag;
                            moveDirLng = bestLng / mag;
                        }
                    } else {
                        // No safe corridor that avoids neutral/protected land – do not move this tick
                        // so units hold their line instead of drifting through neutral territory.
                        moveDirLat = 0;
                        moveDirLng = 0;
                    }
                }

                // Speed penalties for neutral or protected territory (Strict enforcement)
                // If a unit enters neutral land, it's effectively "interned" or slowed to a crawl.
                // Penalty is reduced if the unit is actively moving TOWARDS friendly land to allow escape.
                let neutralPenalty = 1.0;
                let touchingNeutralForNaval = false;

                if (isNeutralCountry(currentIdx) || isProtectedSupport(currentIdx)) {
                    const exitLookDist = 0.25;
                    const nextIdx = getGridIndex(u.lat + moveDirLat * exitLookDist, u.lng + moveDirLng * exitLookDist);
                    const isExiting = nextIdx !== -1 && !isNeutralCountry(nextIdx) && !isProtectedSupport(nextIdx);
                    // Use 0.25 speed to escape, but 0.05 speed if moving deeper into neutral territory
                    neutralPenalty = isExiting ? 0.25 : 0.05;
                    if (isAtSea) touchingNeutralForNaval = true;
                } else if (isAtSea) {
                    // For naval units, also treat upcoming neutral coastline as "touching" neutral
                    const coastLookDist = 0.4;
                    const coastIdx = getGridIndex(u.lat + moveDirLat * coastLookDist, u.lng + moveDirLng * coastLookDist);
                    if (isNeutral(coastIdx) || isProtectedSupport(coastIdx)) {
                        touchingNeutralForNaval = true;
                    }
                }

                // Naval neutral-contact damage: ships scraping neutral coasts take heavy damage and should avoid them
                if (isAtSea && touchingNeutralForNaval && !isNaN(u.health)) {
                    const neutralHitDamage = CONFIG.ATTRITION_DAMAGE * 4.0 * damageTakenMult;
                    recordDamage(u, neutralHitDamage);
                }
                
                // Massive speed boost when actively retreating to avoid being swallowed by fast borders
                // BUT trapped/encircled units cannot retreat efficiently
                let retreatBoost = activeRetreat ? 5.5 : 1.0;
                if (isEncircled) retreatBoost *= 0.05; 

                // --- FORCED PUSH COORDINATION (Victory-Driven) ---
                // Units now wait at the frontline until a significant portion of their army 
                // has won local skirmishes, triggering a massive, coordinated "Big Push".
                let pushReadiness = 1.0;
                const isAtFrontline = !isAtSea && !isEffectivelyMyLand && !isTooNearBorder;
                
                if (isAtFrontline && !isMega && !isSuper && !activeRetreat) {
                    const victoryRatio = sideVictoryRatios[sideIndex] || 0;
                    
                    // UNITED PUSH COORDINATION: Units now creep forward even when not surging to prevent static fronts.
                    if (countryObj?.isSurging) {
                        // Spearhead Effect: Units move at varying speeds to create breakthroughs rather than straight lines
                        const spearheadAggression = 0.5 + (Math.sin(u.id * 777) * 0.5 + 0.5); // 0.5x to 1.5x variation
                        const momentumScale = Math.min(1.8, victoryRatio * 2.5);
                        pushReadiness = 4.2 * momentumScale * spearheadAggression;
                        
                        // Local Breakthrough: Units with high local victory momentum push even harder
                        if (u.victoryBoostTicks > 0) pushReadiness *= 1.4;
                    } else {
                        // Creeping Advance: Units advance at a moderate speed while holding the line to maintain pressure.
                        pushReadiness = 0.7;
                    }

                    // Strategic Lock: allow pushes with smaller groups so they don't sit idle
                    if (localAllyCount < 3) pushReadiness = 0.0;
                    
                    // Force halt if saturation is lost, but still allow some forward pressure
                    if (countryObj && !countryObj.isSaturated) {
                        pushReadiness = 0.3;
                    }
                }

                const moveDist = baseSpeed * speedMult * neutralPenalty * retreatBoost * pushReadiness * 0.8; // Reduced movement speed
                
                // Safety: Prevent NaN from propagating if moveDir calculation fails
                if (!isNaN(moveDirLat) && !isNaN(moveDirLng) && !isNaN(moveDist)) {
                    u.lat += moveDirLat * moveDist;
                    u.lng += moveDirLng * moveDist;
                    u.dirLat = moveDirLat; // Store trajectory for renderer
                    u.dirLng = moveDirLng;
                    
                    // Geographic clamping/wrapping to prevent units from flying off the map
                    u.lat = Math.max(-89.9, Math.min(89.9, u.lat));
                    // Wrap longitude [-180, 180]
                    if (u.lng > 180) u.lng -= 360;
                    if (u.lng < -180) u.lng += 360;
                }
            } else if (enemies.length > 0 && typeof target.health !== 'undefined') {
                // Combat logic
                u.lastCombatTick = simFrameCount;
                target.lastCombatTick = simFrameCount;

                // Strategic Depth: Units defending their own de jure (historical) territory get a defense boost.
                let defenseBonus = 1.0;
                const currentIdx = getGridIndex(u.lat, u.lng);
                const isDeJureLand = currentIdx !== -1 && deJureMap[currentIdx] === u.sovereignId;
                
                if (!isAtSea) {
                    if (isDeJureLand) defenseBonus *= 0.65; // 35% reduction in historical land
                    if (worldControlMap[gridIdxNow] === u.sovereignId && Math.abs(currentControl) < 0.2) {
                        defenseBonus *= 0.85; // Additional stack for unoccupied frontline
                    }

                    // City Fortification: Units near friendly cities are much harder to destroy
                    const nearbyCity = activeTheaterCities.find(c => c.sovereignId === u.sovereignId && (u.lat - c.lat)**2 + (u.lng - c.lng)**2 < 0.04);
                    if (nearbyCity) {
                        defenseBonus *= 0.45; // Significant defense boost in urban centers
                    }
                }

                const tDmg = CONFIG.COMBAT_DAMAGE * damageDealtMult * 0.7;
                const uDmg = (CONFIG.COMBAT_DAMAGE * 0.8) * damageTakenMult * defenseBonus;
                
                // Casualties increase while battling (direct engagement)
                recordDamage(target, tDmg);
                recordDamage(u, uDmg);

                if (target.health <= 0) {
                    u.victoryBoostTicks = 180; // Reduced momentum duration
                }
            }
        }

        if (u.health <= 0) {
            // Units are already being counted for casualties per-hit during simulation.
            // This just cleans them up when they reach 0 health.
            units.splice(i, 1);
        }
    }

    // NOTE: Even if teamASoldiers/teamBSoldiers reach 0, sides remain on the field and can still recruit.
    // This keeps wars from hard-locking when a side's manpower bar is exhausted.

    // 4. Individual Capitulation & Treaty Logic
    const timeSinceTreaty = Date.now() - lastTreatyTime;

    // Keep side-level casualty counters consistent with remaining manpower and initial pools
    if (initialTeamASoldiers > 0) {
        sideACasualties = Math.max(0, initialTeamASoldiers - teamASoldiers);
    }
    if (initialTeamBSoldiers > 0) {
        sideBCasualties = Math.max(0, initialTeamBSoldiers - teamBSoldiers);
    }

    // Check for individual country falls
    for (let sIdx = 0; sIdx < sides.length; sIdx++) {
        const side = sides[sIdx];
        for (let i = side.length - 1; i >= 0; i--) {
            const country = side[i];

            // Decrement grace period
            if (country.graceTicks > 0) country.graceTicks--;

            const stats = countryStats.get(country.id);
            if (!stats) continue;

            const initial = country.initialCells || 1;
            const controlPct = (stats.controlled / initial) * 100;
            
            // Individual Capitulation criteria: 
            // If undefended (0 units), capitulate much earlier (25% land)
            // Otherwise, fight until 2% land remains
            // Nations can be granted a grace period (e.g. rebellions) where they are immune to capitulation
            const isProtected = country.graceTicks > 0;
            if (!isProtected && ((stats.units === 0 && controlPct < 25) || controlPct < 2)) {
                capitulateCountry(country, sIdx);
                // Exit tick early to re-evaluate state in next tick with updated sides/units
                return false; 
            }
        }
    }

    // Determine which "poles" still have participating and combat-effective (OFFENSE) countries
    const activePoles = new Set();
    const effectivePoles = new Set();
    sides.forEach((side, idx) => {
        if (side.length > 0) {
            const pole = idx % 2 === 0 ? 'A' : 'B';
            activePoles.add(pole);
            if (side.some(c => c.role === 'OFFENSE')) {
                effectivePoles.add(pole);
            }
        }
    });

    // End war if only one pole remains, or if a pole has lost all its offensive capability against an active enemy
    if (gameState === 'SIMULATING') {
        if (activePoles.size <= 1) {
            const winnerPole = activePoles.has('A') ? 'A' : 'B';
            applyTreaty(winnerPole === 'A' ? 'FULL_CAPITULATION_A' : 'FULL_CAPITULATION_B');
            return true;
        }

        // Support Clause: If one side has no offensive capability left but the other does, the side without offense collapses
        if (effectivePoles.size === 1) {
            const winnerPole = Array.from(effectivePoles)[0];
            applyTreaty(winnerPole === 'A' ? 'FULL_CAPITULATION_A' : 'FULL_CAPITULATION_B', winnerPole);
            return true;
        }
    }

    if (p1LandScore >= 99.9) {
        applyTreaty('FULL_CAPITULATION_A'); return true; 
    } else if (p1LandScore <= 0.1) {
        applyTreaty('FULL_CAPITULATION_B'); return true;
    } else if (timeSinceTreaty > 6000 && treatyAlert.style.display === 'none') {
        if (!peaceTreatiesDisabled && Math.random() < 0.001) {
            // Select actual side indices for a more specific treaty proposal
            const proposerSideIdx = Math.floor(Math.random() * sides.length);
            if (sides[proposerSideIdx] && sides[proposerSideIdx].length > 0) {
                const proposerPole = proposerSideIdx % 2 === 0 ? 'A' : 'B';
                const receiverPole = proposerPole === 'A' ? 'B' : 'A';
                const receiverLand = receiverPole === 'A' ? p1LandScore : (100 - p1LandScore);
                const acceptChance = Math.max(0.1, (100 - receiverLand) / 100);
                showTreatyOffer(proposerPole, Math.random() < acceptChance, proposerSideIdx);
            }
        }
    }

    // Rebellion victory check
    if (activeRebellion && simFrameCount % 15 === 0) {
        const { rebelId, overlordId, startTime } = activeRebellion;

        // Goliath Buff Decay: Rebels lose their initial combat bonus after ~20 seconds at 1x speed
        if (simFrameCount - startTime > 1200) {
            sides.flat().filter(Boolean).forEach(c => {
                if (c.id === rebelId && c.buffState === 'buff') {
                    c.buffState = 'none';
                    statusText.innerText = `${c.name.toUpperCase()} REVOLUTIONARY FERVOR SUBSIDING`;
                }
            });
            const meta = countryMetadata.find(m => m && m.id === rebelId);
            if (meta && meta.buffState === 'buff') meta.buffState = 'none';
        }

        let rebelDeJureCount = 0;
        let rebelReclaimedCount = 0;

        // Check if rebel has reclaimed its original borders
        // Use a much higher density scan for this to ensure small countries (like Portugal) hit the trigger reliably.
        // When many sides are active, we can safely sample more sparsely.
        const optimizationFactor = getOptimizationFactor();
        const winCheckStep = Math.max(1, Math.floor((deJureMap.length / 100000) * optimizationFactor));
        const rebelSide = sides.find(s => s.some(c => c.id === rebelId));
        const rebelIsTeamA = rebelSide && rebelSide.indexOf(rebelSide.find(c => c.id === rebelId)) !== -1 && sides.indexOf(rebelSide) % 2 === 0;

        for (let i = 0; i < deJureMap.length; i += winCheckStep) {
            if (deJureMap[i] === rebelId) {
                rebelDeJureCount++;
                // A cell is "reclaimed" if:
                // 1. It is owned by the rebel in worldControlMap (starting pocket)
                // 2. OR it is occupied by the rebel's side/pole with high confidence
                const occ = occupationMap[i];
                const isOccupiedByRebel = worldControlMap[i] === rebelId || 
                                          (rebelIsTeamA ? occ > 0.15 : occ < -0.15);
                if (isOccupiedByRebel) {
                    rebelReclaimedCount++;
                }
            }
        }

        // Robust threshold (85%) and high scan density to ensure peace triggers even with scattered islands/tiny pockets
        if (rebelDeJureCount > 0 && rebelReclaimedCount > rebelDeJureCount * 0.85) { 
            handleRebellionPeace();
            return true;
        }
    }

    if (units.length === 0 && gameState === 'SIMULATING') {
         applyTreaty('WHITE_PEACE'); return true;
    }

    // 5. Update Bombs & Explosions
    if (bombsDisabled) {
        bombs = [];
    }
    for (let i = bombs.length - 1; i >= 0; i--) {
        const b = bombs[i];
        // Slower step for smoother movement, accelerating slightly on descent
        const step = 0.0055 * (b.state === 'falling' ? (1 + (b.progress - 0.5) * 2.5) : 1);
        b.progress += step;

        if (b.state === 'rising' && b.progress >= 0.5) {
            b.state = 'falling';
        }

        const t = b.progress;
        const latBase = b.startLat + (b.targetLat - b.startLat) * t;
        const lngBase = b.startLng + (b.targetLng - b.startLng) * t;
        
        const alt = Math.sin(Math.PI * t) * b.peakAlt;
        b.currentLat = latBase + alt;
        b.currentLng = lngBase;

        // Predict next position for rotation calculation
        const nextT = Math.min(1.0, t + 0.005);
        const nextLatBase = b.startLat + (b.targetLat - b.startLat) * nextT;
        const nextLngBase = b.startLng + (b.targetLng - b.startLng) * nextT;
        const nextAlt = Math.sin(Math.PI * nextT) * b.peakAlt;
        b.nextLat = nextLatBase + nextAlt;
        b.nextLng = nextLngBase;

        // Trail logic
        b.trail.push({ lat: b.currentLat, lng: b.currentLng });
        if (b.trail.length > 40) b.trail.shift();

        if (b.progress >= 1.0) {
            // Impact!
            playExplosionSound();
            explosions.push({
                lat: b.targetLat,
                lng: b.targetLng,
                life: 30,
                maxRadius: 20
            });

            // Damage units in radius instead of instantly killing them
            const killRadiusSq = 0.5 * 0.5;
            const killRadius = Math.sqrt(killRadiusSq);
            for (let j = 0; j < units.length; j++) {
                const victim = units[j];
                const dSq = (victim.lat - b.targetLat) ** 2 + (victim.lng - b.targetLng) ** 2;
                if (dSq < killRadiusSq) {
                    const dist = Math.sqrt(dSq);
                    const falloff = 1 - (dist / killRadius); // 1 at center, 0 at edge
                    // Base missile damage scaled by distance; strong but non‑lethal except near center
                    const baseDamage = CONFIG.COMBAT_DAMAGE * 4;
                    const damage = baseDamage * Math.max(0.2, falloff); // ensure a minimum chunk
                    recordDamage(victim, damage);
                    // Do NOT splice here; units will be removed later when their health <= 0
                }
            }
            bombs.splice(i, 1);
        }
    }

    // AI Bomb Launching (Restored and buffed frequency)
    const simYear = gameTimeDate ? gameTimeDate.year : 2024;
    const canFireMissiles = !gameTimeEnabled || simYear >= 1942;

    if (!bombsDisabled) {
        const poleAExists = sides.some((s, idx) => idx % 2 === 0 && s.length > 0);
        const poleBExists = sides.some((s, idx) => idx % 2 !== 0 && s.length > 0);
        
        if (poleAExists && poleBExists) {
            // Missile AI (Buffed frequency: 0.0025 -> 0.01)
            if (canFireMissiles && bases.length > 0 && Math.random() < 0.01) {
                const launcherTeam = Math.random() > 0.5 ? 'A' : 'B';
                const targetTeam = launcherTeam === 'A' ? 'B' : 'A';
                const myBases = bases.filter(b => b.team === launcherTeam);
                const enemyUnits = units.filter(u => u.team === targetTeam);
                if (myBases.length > 0 && enemyUnits.length > 0) {
                    const launcher = myBases[Math.floor(Math.random() * myBases.length)];
                    const target = enemyUnits[Math.floor(Math.random() * enemyUnits.length)];
                    launchBomb(launcher.lat, launcher.lng, target.lat, target.lng, launcherTeam);
                }
            }
        }
    }

    for (let i = explosions.length - 1; i >= 0; i--) {
        explosions[i].life--;
        if (explosions[i].life <= 0) explosions.splice(i, 1);
    }

    return false;
}

function updateLoop(now) {
    const shouldSimulate = gameState === 'SIMULATING' || (godModeActive && (preGodModeState === 'SIMULATING' || preGodModeState === 'WAR_OVER'));
    if (!shouldSimulate) return;
    // Avoid running the visual loop while a background tick loop is active
    if (document.hidden) return;

    if (!isPaused) {
        // Run sub-ticks based on simSpeed (handles both fast-forward and slow-motion)
        frameAccumulator += simSpeed;
        while (frameAccumulator >= 1) {
            const warEnded = performSimulationTick();
            if (warEnded) {
                frameAccumulator = 0;
                return;
            }
            frameAccumulator -= 1;
        }

        // Advance in-game date by real time
        if (typeof now === 'number') {
            // Because we don't track previous timestamp, approximate per-frame using 16ms if undefined
            tickGameTime(16.67);
        }
    }

    // Advance simulation frame counter once per visual loop
    simFrameCount++;

    // When running at high speeds, skip every other render frame to reduce UI / draw load
    const skipRenderThisFrame = simSpeed > 2 && (simFrameCount % 2 === 1);
    if (skipRenderThisFrame) {
        animationFrameId = requestAnimationFrame(updateLoop);
        return;
    }

    // UI Updates (once per frame)
    // Derive displayed personnel directly from live unit health so it never shows 0
    // while divisions are still present on the map, and correctly scales with damage.
    const spA = soldiersPerUnitA || CONFIG.UNIT_TO_SOLDIER_RATIO;
    const spB = soldiersPerUnitB || CONFIG.UNIT_TO_SOLDIER_RATIO;
    let estSoldiersA = 0;
    let estSoldiersB = 0;
    let p1Units = 0;
    let p2Units = 0;

    for (let i = 0; i < units.length; i++) {
        const u = units[i];
        if (u.team === 'A') {
            p1Units++;
            estSoldiersA += (u.health / CONFIG.UNIT_HEALTH) * spA;
        } else {
            p2Units++;
            estSoldiersB += (u.health / CONFIG.UNIT_HEALTH) * spB;
        }
    }

    document.getElementById('p1-soldiers-ui').innerText = influenceLayer.formatSoldiers(estSoldiersA > 0 && estSoldiersA < 1 ? 1 : estSoldiersA);
    document.getElementById('p2-soldiers-ui').innerText = influenceLayer.formatSoldiers(estSoldiersB > 0 && estSoldiersB < 1 ? 1 : estSoldiersB);

    p1UnitsDisp.innerText = p1Units;
    p2UnitsDisp.innerText = p2Units;

    let p1CityCount = 0;
    let p2CityCount = 0;
    activeTheaterCities.forEach(c => {
        const val = getControlValue(c.lat, c.lng);
        if (val > 0.3) p1CityCount++;
        else if (val < -0.3) p2CityCount++;
    });
    p1CitiesDisp.innerText = p1CityCount;
    p2CitiesDisp.innerText = p2CityCount;

    // Throttled UI rendering in Flag mode to maintain responsive interaction and framerate
    simFrameCount++;
    
    // Throttled Combatants UI update
    if (simFrameCount % 30 === 0) {
        updateCombatantsUI();
    }

    // Update Casualty UI (Every frame for "live" counting effect)
    const updateSideCasualties = (poleIdx, containerId) => {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        // Use initialCombatants to ensure consistency, but also check sides for any mid-war joiners
        let entries = initialCombatants.filter(c => c.pole === poleIdx);
        
        // Check for any currently warring countries not in initialCombatants
        sides.forEach((side, sIdx) => {
            if (sIdx % 2 === poleIdx) {
                side.forEach(c => {
                    if (!entries.some(e => e.id === c.id)) {
                        entries.push({ id: c.id, name: c.name, pole: poleIdx });
                    }
                });
            }
        });

        if (entries.length === 0) {
            container.innerHTML = '';
            return;
        }

        // Only update HTML if values changed to save CPU, or every 10 frames
        if (simFrameCount % 5 === 0) {
            container.innerHTML = entries.map((c, i) => {
                const casualties = countryCasualties.get(c.id) || 0;
                const formatted = influenceLayer.formatSoldiers(casualties);
                
                // Determine if country is capitulated (no longer in any side)
                const isDefeated = !sides.flat().some(active => active.id === c.id);
                const isPrimary = (i === 0 && !isDefeated); // Germany is primary only if still fighting

                const meta = countryMetadata[c.id - 1];
                let flagSrc = meta?.flagUrl || '';
                if (meta?.tempFlag instanceof HTMLCanvasElement) {
                    try { flagSrc = meta.tempFlag.toDataURL(); } catch(e) {}
                }

                return `
                    <div class="casualty-item ${isPrimary ? 'primary' : 'secondary'}" style="opacity: ${isDefeated ? 0.45 : 1};">
                        <img src="${flagSrc}" class="cas-flag ${isPrimary ? '' : 'small'}" alt="" style="${isDefeated ? 'filter: grayscale(1);' : ''}">
                        <div class="cas-value team-${poleIdx === 0 ? 'a' : 'b'}" style="font-size: ${isPrimary ? '18px' : '12px'};">${formatted}</div>
                    </div>
                `;
            }).join('');
        }
    };

    updateSideCasualties(0, 'casualty-list-a');
    updateSideCasualties(1, 'casualty-list-b');

    if (viewMode === 'FLAG') {
        // In flag view, force the canvas layer to fully update each frame so units and borders
        // keep animating even when the camera is stationary.
        influenceLayer._forceRender = true;
        influenceLayer._update();
    } else {
        influenceLayer.render();
    }
    
    animationFrameId = requestAnimationFrame(updateLoop);
}

function updateCombatantsUI() {
    // Combatants list removed from stats panel to reduce clutter.
    // Users can click nations directly on the map to buff them via the inspector.
}

/**
 * Build and show global leaderboard of all countries with current size and estimated unit strength.
 */
function openLeaderboard() {
    if (!leaderboardOverlay || !leaderboardList || !countryMetadata || !worldControlMap) return;

    // Count tiles per country id
    const maxId = countryMetadata.reduce((max, m) => m ? Math.max(max, m.id) : max, 0);
    const tileCounts = new Int32Array(maxId + 1);
    for (let i = 0; i < worldControlMap.length; i++) {
        const id = worldControlMap[i];
        if (id > 0 && id <= maxId) tileCounts[id]++;
    }

    const lang = getCookie('mw_lang') || 'en';

    const rows = [];
    for (let i = 0; i < countryMetadata.length; i++) {
        const meta = countryMetadata[i];
        if (!meta) continue;
        const id = meta.id;
        const tiles = tileCounts[id] || 0;

        // Exclude Antarctica from the leaderboard to avoid it dominating due to map area
        const rawName = meta.name || 'Unknown';
        if (rawName === 'Antarctica') continue;

        // Size zero: still show (releasables / dead states), but mark as 0 tiles
        const estUnits = estimateUnitsForCountry ? estimateUnitsForCountry(id) : 0;

        const displayName = getTranslation(rawName, lang, 'NATIONS');
        const flagUrl = (meta.tempFlag && meta.tempFlag.src) ? meta.tempFlag.src : (meta.flagUrl || getFlagUrl(findCodeByName(meta.name), meta.name));
        rows.push({
            id,
            name: displayName,
            rawName,
            tiles,
            estUnits,
            flagUrl
        });
    }

    // Primary sort: estimated units desc, secondary: tiles desc, tertiary: name
    rows.sort((a, b) => {
        if (b.estUnits !== a.estUnits) return b.estUnits - a.estUnits;
        if (b.tiles !== a.tiles) return b.tiles - a.tiles;
        return a.name.localeCompare(b.name);
    });

    leaderboardList.innerHTML = rows.map((row, idx) => {
        const unitsLabel = row.estUnits > 0 ? influenceLayer.formatSoldiers(row.estUnits) : '—';
        const tilesLabel = row.tiles.toLocaleString();
        const rank = idx + 1;
        const flagSrc = row.flagUrl || '';
        return `
            <div class="leaderboard-row">
                <div class="leaderboard-name">
                    ${flagSrc ? `<img src="${flagSrc}" class="leaderboard-flag" alt="">` : `<div class="leaderboard-flag" style="background:#111;"></div>`}
                    <span>${row.name}</span>
                </div>
                <div class="leaderboard-tiles">${tilesLabel}</div>
                <div class="leaderboard-units">${unitsLabel}</div>
                <div class="leaderboard-rank">${rank}</div>
            </div>
        `;
    }).join('');

    leaderboardOverlay.style.display = 'flex';
}

function showTreatyOffer(proposer, willAccept, proposerSideIdx = null) {
    lastTreatyTime = Date.now();
    let name = proposer === 'A' ? p1NameDisp.innerText : p2NameDisp.innerText;
    
    // In FFA/Multi-side, try to find the specific side's name for the UI
    if (proposerSideIdx !== null && sides[proposerSideIdx] && sides[proposerSideIdx][0]) {
        const side = sides[proposerSideIdx];
        name = side.length > 1 ? `${side[0].name} Allies` : side[0].name;
    }

    treatyMsg.innerText = `${name} requests peace`;
    treatyAlert.style.display = 'block';
    document.getElementById('treaty-status').innerText = "Considering proposal...";
    
    setTimeout(() => {
        if (willAccept) {
            document.getElementById('treaty-status').innerText = "Treaty Accepted";
            setTimeout(() => applyTreaty('PEACE_TREATY'), 1500);
        } else {
            document.getElementById('treaty-status').innerText = "Proposal Rejected";
            setTimeout(() => {
                treatyAlert.style.display = 'none';
                lastTreatyTime = Date.now();
            }, 1500);
        }
    }, 2000);
}

function capitulateCountry(country, sideIndex) {
    const side = sides[sideIndex];
    if (!side) return;

    // Announce the individual fall
    statusText.innerText = `${country.name} HAS CAPITULATED`;
    treatyMsg.innerText = "NATION ANNEXED";
    document.getElementById('treaty-status').innerText = `${country.name} territory has been seized.`;
    treatyAlert.style.display = 'block';
    
    // Auto-hide the alert after a delay if war is still going
    setTimeout(() => { 
        if (gameState === 'SIMULATING') {
            treatyAlert.style.display = 'none';
        }
    }, 4000);

    // Build owner -> side index map once for this operation
    const ownerToSideMap = new Map();
    sides.forEach((s, idx) => {
        s.forEach(c => ownerToSideMap.set(c.id, idx));
    });

    // Snapshot all tiles currently owned by the capitulating country so it can be released later
    const victimTerritorySnapshot = [];
    for (let i = 0; i < worldControlMap.length; i++) {
        if (worldControlMap[i] === country.id) {
            const y = Math.floor(i / gridWidth);
            const x = i % gridWidth;
            victimTerritorySnapshot.push([x, y]);
        }
    }

    // Transfer territory logic
    const opposingPoleIdx = sideIndex % 2 === 0 ? 1 : 0;
    
    // Find a fallback winner on the opposing pole to inherit land not claimed by specific occupiers
    let fallbackWinnerId = 0;
    for (let j = 0; j < sides.length; j++) {
        if (j % 2 === opposingPoleIdx && sides[j].length > 0) {
            fallbackWinnerId = sides[j][0].id;
            break;
        }
    }

    // Track which indices were part of the capitulated country's warzone so we can
    // decide afterwards if they should remain active fronts or be stabilized.
    const affectedIndices = [];

    for (let i = 0; i < worldControlMap.length; i++) {
        if (worldControlMap[i] === country.id && landMask[i] === 2) {
            const occupierId = primaryOccupierMap[i];
            
            // Verify if the occupier belongs to the winning side of this specific engagement
            let occupierOnOpposingPole = false;
            sides.forEach((s, idx) => {
                if (idx % 2 === opposingPoleIdx && s.some(c => c.id === occupierId)) {
                    occupierOnOpposingPole = true;
                }
            });

            const newOwner = occupierOnOpposingPole ? occupierId : fallbackWinnerId;
            worldControlMap[i] = newOwner;
            primaryOccupierMap[i] = newOwner || 0;
            affectedIndices.push(i);
        }
    }

    // Re-evaluate warzone status for newly annexed tiles so winners can keep pushing
    const totalCells = worldControlMap.length;
    const gridW = gridWidth;
    const gridH = gridHeight;
    affectedIndices.forEach(idx => {
        const ownerId = worldControlMap[idx];
        if (ownerId <= 0) {
            landMask[idx] = 1;
            occupationMap[idx] = 0;
            primaryOccupierMap[idx] = 0;
            return;
        }

        const ownerSideIdx = ownerToSideMap.get(ownerId);
        const ownerPole = ownerSideIdx !== undefined ? (ownerSideIdx % 2) : null;

        let stillFront = false;
        const x = idx % gridW;
        const y = Math.floor(idx / gridW);

        const neighborOffsets = [
            1, -1, gridW, -gridW
        ];

        for (const off of neighborOffsets) {
            const nIdx = idx + off;
            if (nIdx < 0 || nIdx >= totalCells) continue;
            if (landMask[nIdx] === 0) continue; // ignore sea

            const nOwner = worldControlMap[nIdx];
            if (nOwner <= 0 || nOwner === ownerId) continue;

            const nSideIdx = ownerToSideMap.get(nOwner);
            if (nSideIdx === undefined) continue;

            const nPole = nSideIdx % 2;

            // If neighbor belongs to an opposing pole that still has forces, this cell
            // remains an active frontline.
            if (ownerPole !== null && nPole !== ownerPole && sides[nSideIdx].length > 0) {
                stillFront = true;
                break;
            }
        }

        if (stillFront) {
            landMask[idx] = 2;
            // Set occupation polarity so the annexer can push further from this border
            const poleIsA = ownerPole === 0;
            occupationMap[idx] = poleIsA ? 1 : -1;
            primaryOccupierMap[idx] = ownerId;
        } else {
            landMask[idx] = 1;
            occupationMap[idx] = 0;
            // keep primaryOccupierMap[idx] as ownerId is harmless, but clear to be safe
            primaryOccupierMap[idx] = 0;
        }
    });

    // RELEASABLE TRANSFER: Transfer any releasables owned by the capitulating country to the primary annexer
    countryMetadata.forEach(m => {
        if (m && m.releasableBy === country.id) {
            m.releasableBy = fallbackWinnerId;
        }
    });

    // Make the capitulated country itself a releasable of the annexer and remember its old territory
    if (fallbackWinnerId > 0) {
        const victimMeta = countryMetadata.find(m => m && m.id === country.id);
        if (victimMeta) {
            victimMeta.releasableBy = fallbackWinnerId;

            // Prefer the precise snapshot we made before any transfer; if empty, fall back to deJure cores
            if (victimTerritorySnapshot.length > 0) {
                victimMeta.savedCells = victimTerritorySnapshot;
            } else {
                const cells = [];
                for (let i = 0; i < deJureMap.length; i++) {
                    if (deJureMap[i] === country.id) {
                        const y = Math.floor(i / gridWidth);
                        const x = i % gridWidth;
                        cells.push([x, y]);
                    }
                }
                victimMeta.savedCells = cells;
            }
        }
    }

    // Remove the country from its alliance list
    const cIdx = side.indexOf(country);
    if (cIdx > -1) side.splice(cIdx, 1);

    // Clear targets for any units that were focusing on this specific country's theater
    units.forEach(u => {
        if (u.lastMopUpId === country.id) {
            u.mopUpTarget = null;
            u.lastMopUpId = null;
            u.targetSearchCooldown = 0;
        }
    });

    // Filter out all units belonging to the capitulated nation
    units = units.filter(u => u.sovereignId !== country.id);

    // Sync provinces to new ownership
    generateProvinces();

    // Refresh UI
    recalculateAllBounds();
    updateSidesUI();
    influenceLayer.render();
}

function applyTreaty(type, winnerPoleOverride = null) {
    gameState = 'WAR_OVER';
    playPeaceSound();

    // Stop recording if active
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.onstop = () => {
            const blob = new Blob(recordedChunks, { type: 'video/webm' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `ModernWars_${new Date().getTime()}.webm`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            recordedChunks = [];
        };
        mediaRecorder.stop();
    }

    // Freeze time system at war end and reflect final date in the setup inputs
    if (gameTimeDate && timeYearInput && timeMonthInput && timeDayInput) {
        gameTimeEnabled = false;
        gameTimeAccumulatorMs = 0;
        timeYearInput.value = gameTimeDate.year;
        timeMonthInput.value = gameTimeDate.month;
        timeDayInput.value = gameTimeDate.day;
        if (gameDateDisplay) {
            gameDateDisplay.textContent = formatGameDate();
            gameDateDisplay.style.display = 'block';
        }
    }
    
    let p1T = 0, p2T = 0;
    for (let i = 0; i < occupationMap.length; i++) {
        if (landMask[i] === 2) {
            if (occupationMap[i] > 0) p1T++; else if (occupationMap[i] < 0) p2T++;
        }
    }
    
    let winA = p1T >= p2T;
    if (winnerPoleOverride === 'A') winA = true;
    if (winnerPoleOverride === 'B') winA = false;
    
    let winnerName = "The Winner";
    const sideUnitCounts = sides.map((s, i) => ({
        idx: i,
        units: units.filter(u => u.sideIndex === i).length,
        side: s
    }));

    casualtyPanel.style.display = 'none';

    if (winA) {
        const strongest = sideUnitCounts.filter(s => s.idx % 2 === 0).sort((a,b) => b.units - a.units)[0];
        winnerName = strongest && strongest.side[0] ? (strongest.side.length > 1 ? `${strongest.side[0].name} Allies` : strongest.side[0].name) : p1NameDisp.innerText;
    } else {
        const strongest = sideUnitCounts.filter(s => s.idx % 2 !== 0).sort((a,b) => b.units - a.units)[0];
        winnerName = strongest && strongest.side[0] ? (strongest.side.length > 1 ? `${strongest.side[0].name} Allies` : strongest.side[0].name) : p2NameDisp.innerText;
    }
    
    const isTotalCapitulation = type.includes('FULL_CAPITULATION') || type === 'ANNEXATION';
    const isNegotiatedPeace = type === 'PEACE_TREATY';

    if (isTotalCapitulation) {
        statusText.innerText = winA ? `Victory! Multiple nations annexed by ${winnerName}` : (p1NameDisp.innerText !== "Side A" ? `${p1NameDisp.innerText} was conquered.` : "The conquest is complete.");
        treatyMsg.innerText = "TOTAL ANNEXATION";
        document.getElementById('treaty-status').innerText = "The conflict has concluded";
        treatyAlert.style.display = 'block';
    } else if (isNegotiatedPeace) {
        statusText.innerText = "Peace Treaty Signed";
        treatyMsg.innerText = "BORDERS REDRAWN";
        document.getElementById('treaty-status').innerText = "Territorial adjustments finalized";
        treatyAlert.style.display = 'block';
    } else {
        statusText.innerText = "White Peace Signed";
    }
    
    const countryToSideMap = new Map();
    const countryToRoleMap = new Map();
    sides.forEach((side, idx) => {
        side.forEach(c => {
            countryToSideMap.set(c.id, idx);
            countryToRoleMap.set(c.id, c.role || 'OFFENSE');
        });
    });

    for (let i = 0; i < worldControlMap.length; i++) {
        if (landMask[i] === 2) {
            const originalOwner = worldControlMap[i];
            const occupierId = primaryOccupierMap[i];
            const val = occupationMap[i];
            
            const ownerSideIdx = countryToSideMap.get(originalOwner);
            const occupierSideIdx = countryToSideMap.get(occupierId);

            const isTeamAOccupying = val > 0;
            const isTeamBOccupying = val < 0;

            // Organic land shift: Transfer if side currently holding it is different from original owner
            let cellNewOwner = originalOwner;
            if (isTeamAOccupying && (ownerSideIdx === undefined || ownerSideIdx % 2 !== 0)) {
                cellNewOwner = (occupierSideIdx !== undefined && occupierSideIdx % 2 === 0) ? occupierId : (sides[0][0]?.id || originalOwner);
            } else if (isTeamBOccupying && (ownerSideIdx === undefined || ownerSideIdx % 2 === 0)) {
                cellNewOwner = (occupierSideIdx !== undefined && occupierSideIdx % 2 !== 0) ? occupierId : (sides[1][0]?.id || originalOwner);
            }
            
            // Transfer land to new owner
            if (cellNewOwner !== originalOwner && cellNewOwner > 0) {
                worldControlMap[i] = cellNewOwner;
            }

            if (isTotalCapitulation) {
                const currentOwner = worldControlMap[i];
                const currentSideIdx = countryToSideMap.get(currentOwner);
                const currentRole = countryToRoleMap.get(currentOwner);
                
                let newOwnerId = 0;
                if (winA && (currentSideIdx !== undefined && currentSideIdx % 2 !== 0) && currentRole !== 'SUPPORT') {
                    newOwnerId = (occupierSideIdx !== undefined && occupierSideIdx % 2 === 0) ? occupierId : (sides[0][0]?.id || 0);
                } else if (!winA && (currentSideIdx !== undefined && currentSideIdx % 2 === 0) && currentRole !== 'SUPPORT') {
                    newOwnerId = (occupierSideIdx !== undefined && occupierSideIdx % 2 !== 0) ? occupierId : (sides[1][0]?.id || 0);
                }

                if (newOwnerId > 0) {
                    worldControlMap[i] = newOwnerId;
                    // Note: Releasable transfer handled once per country outside this loop for performance
                }
            }

            // Clean up theater masks
            landMask[i] = 1;
            occupationMap[i] = 0;
        }
    }
    
    // Re-sync province map to final treaty borders to remove ghost province lines
    generateProvinces();

    // High-Performance Organic Border Smoothing: Uses frequency array to avoid GC pressure
    const smoothingPasses = 3;
    const maxId = countryMetadata.reduce((max, m) => m ? Math.max(max, m.id) : max, 0);
    const sideLookup = new Int8Array(maxId + 1).fill(-1);
    countryToSideMap.forEach((side, id) => { if(id <= maxId) sideLookup[id] = side; });
    
    // Static buffers to avoid re-allocation in loops
    const freq = new Uint16Array(maxId + 1);
    const activeIds = new Uint32Array(9); 

    // Transfer Releasables: Move all releasables belonging to defeated countries to their new primary owners
    const ownerTransferMap = new Map();
    // Use sample points to find which countries lost land and who took it
    for (let i = 0; i < worldControlMap.length; i += 500) {
        if (landMask[i] === 2) {
            const currentOwner = worldControlMap[i];
            const originalOwner = deJureMap[i]; // Approximate previous owner
            if (currentOwner !== originalOwner && originalOwner > 0) {
                ownerTransferMap.set(originalOwner, currentOwner);
            }
        }
    }
    countryMetadata.forEach(m => {
        if (m && m.releasableBy && ownerTransferMap.has(m.releasableBy)) {
            m.releasableBy = ownerTransferMap.get(m.releasableBy);
        }
    });

    for (let p = 0; p < smoothingPasses; p++) {
        const tempMap = new Int32Array(worldControlMap);
        for (let y = 1; y < gridHeight - 1; y++) {
            const rowIdx = y * gridWidth;
            for (let x = 1; x < gridWidth - 1; x++) {
                const idx = rowIdx + x;
                if (landMask[idx] === 0) continue;

                let activeCount = 0;
                let maxFreq = 0;
                let winner = worldControlMap[idx];

                // Sample 3x3 neighborhood
                for (let dy = -1; dy <= 1; dy++) {
                    const rOff = dy * gridWidth;
                    for (let dx = -1; dx <= 1; dx++) {
                        const owner = worldControlMap[idx + rOff + dx];
                        if (owner > 0) {
                            if (freq[owner] === 0) activeIds[activeCount++] = owner;
                            freq[owner]++;
                            if (freq[owner] > maxFreq) {
                                maxFreq = freq[owner];
                                winner = owner;
                            }
                        }
                    }
                }

                // Apply majority rule
                if (maxFreq >= 6) tempMap[idx] = winner;

                // Cleanup frequency array for next pixel
                for (let i = 0; i < activeCount; i++) freq[activeIds[i]] = 0;
            }
        }
        worldControlMap.set(tempMap);
    }

    units = [];
    bombs = [];
    explosions = [];
    bases = [];
    operationStarts.clear();
    recalculateAllBounds();
    influenceLayer.render();
    
    setTimeout(() => {
        treatyAlert.style.display = 'none';
        resetToSelection();
        if (randomWarMode) {
            setTimeout(triggerRandomWar, 1500);
        }
    }, 2500);
}

function handleRebellionPeace() {
    if (!activeRebellion) return;
    const { rebelId, overlordId } = activeRebellion;
    
    gameState = 'WAR_OVER';
    playPeaceSound();

    // Freeze time system at war end and reflect final date in the setup inputs
    if (gameTimeDate && timeYearInput && timeMonthInput && timeDayInput) {
        gameTimeEnabled = false;
        gameTimeAccumulatorMs = 0;
        timeYearInput.value = gameTimeDate.year;
        timeMonthInput.value = gameTimeDate.month;
        timeDayInput.value = gameTimeDate.day;
        if (gameDateDisplay) {
            gameDateDisplay.textContent = formatGameDate();
            gameDateDisplay.style.display = 'block';
        }
    }
    
    statusText.innerText = "Rebellion Successful: Borders Restored";
    treatyMsg.innerText = "INDEPENDENCE RECOGNIZED";
    document.getElementById('treaty-status').innerText = "Post-colonial borders enforced";
    treatyAlert.style.display = 'block';

    // Special Peace Condition:
    // 1. Rebel gets its de jure land back.
    // 2. Overlord gets its de jure land back (even if captured by rebel during war).
    // 3. Any other land involved stabilized.
    
    for (let i = 0; i < worldControlMap.length; i++) {
        if (landMask[i] === 2) {
            const djId = deJureMap[i];
            if (djId === rebelId) {
                worldControlMap[i] = rebelId;
            } else if (djId === overlordId) {
                worldControlMap[i] = overlordId;
            } else {
                // If it was some other land captured during the chaos, return to original
                if (djId > 0) worldControlMap[i] = djId;
            }
            
            landMask[i] = 1;
            occupationMap[i] = 0;
            primaryOccupierMap[i] = 0;
        }
    }

    activeRebellion = null;
    units = [];
    bombs = [];
    
    // Sync provinces back to restored de jure borders
    generateProvinces();
    explosions = [];
    bases = [];
    operationStarts.clear();
    recalculateAllBounds();
    influenceLayer.render();
    
    setTimeout(() => {
        treatyAlert.style.display = 'none';
        resetToSelection();
    }, 3000);
}

function resetToSelection() {
    stopWarAmbiance();
    // Stop in‑game time progression but keep the last war date visible in the setup
    gameTimeEnabled = false;
    gameTimeAccumulatorMs = 0;
    if (gameTimeDate && timeYearInput && timeMonthInput && timeDayInput) {
        timeYearInput.value = gameTimeDate.year;
        timeMonthInput.value = gameTimeDate.month;
        timeDayInput.value = gameTimeDate.day;
        if (gameDateDisplay) {
            gameDateDisplay.textContent = formatGameDate();
            gameDateDisplay.style.display = 'block';
        }
    }
    
    // If in God Mode, we reset the underlying state that will be restored on exit
    if (godModeActive) {
        preGodModeState = 'SELECTING_P1';
    }

    if (gameMode === 'EDITOR' || gameMode === 'EDITOR_TEST') {
        if (gameMode === 'EDITOR_TEST') {
            gameMode = 'EDITOR';
            editorToolbox.style.display = 'flex';
        }
        if (!godModeActive) {
            gameState = 'EDITOR_ACTIVE';
            statusText.innerText = "Map Editor (Alpha)";
        }
        setupPanel.style.display = 'none';
        statsPanel.style.display = 'none';
        resetBtn.style.display = 'block';
        ffBtn.style.display = 'none';
        forcePeaceBtn.style.display = 'none';
        unitCountsDiv.style.display = 'none';
        updateRestartVisibility();
        influenceLayer.render();
        if (!godModeActive) return;
    }
    gameState = 'SELECTING_P1';
    sides = [[], []];
    attackers = sides[0];
    defenders = sides[1];
    activeSideIndex = 0;
    ffaMode = false;
    ffaToggleBtn.style.border = 'none';
    ffaToggleBtn.innerText = 'FFA Mode';
    buffedTeam = null;
    units = [];
    bombs = [];
    explosions = [];
    bases = [];
    operationStarts.clear();
    setSpeed(0);
    frameAccumulator = 0;
    
    statusText.innerText = "Select First Country";
    setupPanel.style.display = 'block';
    setupOptions.style.display = 'none';
    
    updateSidesUI();

    statsPanel.style.display = 'none';
    document.getElementById('game-status').style.display = 'flex'; // Restore if cinematic
    casualtyPanel.style.display = 'none';
    resetBtn.style.display = currentScenarioContext ? 'block' : 'none';
    restartScenarioBtn.style.display = 'block';
    document.getElementById('speed-controls').style.display = 'none';
    godModeBtn.style.display = (gameMode === 'CONQUEST' || godModeActive) ? 'block' : 'none';
    forcePeaceBtn.style.display = 'none';
    unitCountsDiv.style.display = 'none';
}

async function resetGame() {
    cancelAnimationFrame(animationFrameId);
    
    // Scenario-specific reset: Reload the original preset if available
    if (currentScenarioContext && currentScenarioContext.blobUrl) {
        loadingStatus.innerText = "Reloading Scenario Assets...";
        loadingOverlay.style.display = 'flex';
        try {
            const response = await fetch(currentScenarioContext.blobUrl);
            if (!response.ok) throw new Error("Reload failed");
            const blob = await response.blob();
            await performPresetLoad(blob, gameMode);
            return;
        } catch (e) {
            console.error("Satellite Reset Failed:", e);
        }
    }

    worldControlMap.fill(0);
    occupationMap.fill(0);
    landMask.fill(0);
    resetToSelection();
    updateRestartVisibility();
    // Re-initialize landmask from features
    const mapRes = document.getElementById('map-res-select').value;
    const geoUrl = `${CONFIG.GEOJSON_BASE}${mapRes}/cultural/ne_${mapRes}_admin_0_countries.json`;
    loadCountries(geoUrl, gameMode === 'EDITOR');
}

/**
 * INTERACTION
 */
function findCityAtLatLng(latlng) {
    if (!cities || cities.length === 0) return null;
    const pt = map.latLngToContainerPoint(latlng);
    const maxDistSq = 8 * 8;
    let best = null;
    let bestDistSq = maxDistSq;

    const bounds = map.getBounds();
    cities.forEach(c => {
        if (c.lat == null || c.lng == null) return;
        if (!bounds.contains([c.lat, c.lng])) return;
        const cp = map.latLngToContainerPoint([c.lat, c.lng]);
        const dx = cp.x - pt.x;
        const dy = cp.y - pt.y;
        const d2 = dx*dx + dy*dy;
        if (d2 < bestDistSq) {
            bestDistSq = d2;
            best = c;
        }
    });
    return best;
}

map.on('click', (e) => {
    const originalEvent = e.originalEvent || e;

    // City move / create modes take priority
    if ((gameMode === 'EDITOR' || godModeActive) && cityEditMode === 'MOVE' && editingCityId > 0) {
        const city = cities.find(c => c.id === editingCityId);
        if (city) {
            city.lat = e.latlng.lat;
            city.lng = e.latlng.lng;
            statusText.innerText = `Moved ${city.name} to new position`;
            cityEditMode = null;
            cityInspector.style.display = 'block';
            influenceLayer.render();
            return;
        }
        cityEditMode = null;
    }

    if ((gameMode === 'EDITOR' || godModeActive) && cityEditMode === 'CREATE') {
        const newId = (cities.length ? Math.max(...cities.map(c => c.id || 0)) : 0) + 1;
        const idx = getGridIndex(e.latlng.lat, e.latlng.lng);
        const ownerId = idx !== -1 ? worldControlMap[idx] : null;
        const newCity = {
            id: newId,
            name: "New City",
            lat: e.latlng.lat,
            lng: e.latlng.lng,
            pop: 0,
            isCapital: false,
            ownerId: ownerId,
            isCustom: true
        };
        cities.push(newCity);
        activeTheaterCities = cities;
        statusText.innerText = "New city created. Use the City Inspector to name and assign it.";
        cityEditMode = null;
        openCityInspector(newId);
        influenceLayer.render();
        return;
    }

    // City click detection (editor / god mode)
    if (gameMode === 'EDITOR' || godModeActive) {
        const city = findCityAtLatLng(e.latlng);
        if (city) {
            openCityInspector(city.id);
            return;
        }
    }

    handleCountryClick(null, null, e.latlng, originalEvent);
});

map.on('mousemove', (e) => {
    coordsDisplay.textContent = `${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`;
});

viewModeBtn.addEventListener('click', () => {
    if (viewMode === 'POLITICAL') {
        viewMode = 'FLAG';
        viewModeBtn.innerText = "FLAG VIEW";
        viewModeBtn.style.background = "#8e44ad";
    } else {
        viewMode = 'POLITICAL';
        viewModeBtn.innerText = "POLITICAL";
        viewModeBtn.style.background = "#3498db";
    }
    influenceLayer._update();
});

arrowsToggleBtn.addEventListener('click', () => {
    // Arrows have been removed; keep this handler a no‑op for compatibility.
});

battlesToggleBtn.addEventListener('click', () => {
    showBattleIndicators = !showBattleIndicators;
    battlesToggleBtn.classList.toggle('active', showBattleIndicators);
    influenceLayer.render();
});

if (labelsToggleBtn) {
    labelsToggleBtn.classList.toggle('active', showCountryLabels);
    labelsToggleBtn.addEventListener('click', () => {
        showCountryLabels = !showCountryLabels;
        // Clear cached anchors whenever label mode changes so they can be re-anchored once
        countryLabelAnchors.clear();
        labelsToggleBtn.classList.toggle('active', showCountryLabels);
        // Force a full redraw so labels respond instantly, even outside active wars
        if (influenceLayer) {
            influenceLayer._forceRender = true;
            if (typeof influenceLayer._update === 'function') {
                influenceLayer._update();
            } else {
                influenceLayer.render();
            }
        }
    });
}

 // Sync mountain toggles
if (noPeaceCheckbox) {
    noPeaceCheckbox.addEventListener('change', () => {
        peaceTreatiesDisabled = noPeaceCheckbox.checked;
    });
}

if (cityFocusCheckbox) {
    cityFocusCheckbox.addEventListener('change', () => {
        cityFocusMode = cityFocusCheckbox.checked;
    });
}

setupDisableMountainsCheckbox.addEventListener('change', async (e) => {
    const disabled = e.target.checked;
    mountainsEnabled = !disabled;
    mainDisableMountainsCheckbox.checked = disabled;
    
    if (mountainsEnabled && terrainMask.every(v => v === 0)) {
        const currentMapRes = document.getElementById('map-res-select').value;
        await loadTerrain(currentMapRes);
    }
    influenceLayer.render();
});

mainDisableMountainsCheckbox.addEventListener('change', (e) => {
    setupDisableMountainsCheckbox.checked = e.target.checked;
    mountainsEnabled = !e.target.checked;
    influenceLayer.render();
});

// Sync province toggles
setupDisableProvincesCheckbox.addEventListener('change', (e) => {
    const disabled = e.target.checked;
    provincesEnabled = !disabled;
    mainDisableProvincesCheckbox.checked = disabled;
    influenceLayer.render();
});

mainDisableProvincesCheckbox.addEventListener('change', (e) => {
    const disabled = e.target.checked;
    setupDisableProvincesCheckbox.checked = disabled;
    provincesEnabled = !disabled;
    influenceLayer.render();
});



restartScenarioBtn.addEventListener('click', resetGame);

// QUICK RESTART: instant in‑memory reset back to scenario start without loading overlay
if (quickRestartBtn) {
    quickRestartBtn.addEventListener('click', () => {
        // If we never captured a snapshot (e.g. user hits quick restart before a war),
        // just fall back to the heavy reset.
        if (!initialWorldControlMapSnapshot || !initialDeJureMapSnapshot || !initialProvinceMapSnapshot || !initialLandMaskSnapshot) {
            resetGame();
            return;
        }

        // Stop any running simulation loops and sounds but do NOT show the loading overlay.
        if (animationFrameId !== null) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = null;
        }
        if (backgroundTickId) {
            clearInterval(backgroundTickId);
            backgroundTickId = null;
        }
        stopWarAmbiance();

        // Restore core grid state
        worldControlMap.set(initialWorldControlMapSnapshot);
        deJureMap.set(initialDeJureMapSnapshot);
        provinceMap.set(initialProvinceMapSnapshot);
        landMask.set(initialLandMaskSnapshot);
        if (initialBiomeMaskSnapshot) biomeMask.set(initialBiomeMaskSnapshot);

        // Restore metadata and cities from snapshots
        // Note: we avoid deepClone (JSON) here because it breaks Infinity values in bounds and loses Image references
        if (initialCountryMetadataSnapshot) {
            countryMetadata = initialCountryMetadataSnapshot.map(m => {
                if (!m) return null;
                // Create a fresh shallow copy to avoid mutating the snapshot
                const newMeta = { ...m };
                // Re-initialize bounds correctly if they were lost or corrupted
                newMeta.bounds = { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity };
                
                // Restore the Drawable Image object for flags
                if (newMeta.flagUrl) {
                    const img = new Image();
                    img.crossOrigin = "anonymous";
                    img.onload = () => { if (influenceLayer) influenceLayer.render(); };
                    img.src = newMeta.flagUrl;
                    newMeta.tempFlag = img;
                }
                return newMeta;
            });
        }
        
        if (initialCitiesSnapshot) {
            cities = initialCitiesSnapshot.map(c => ({ ...c }));
        }

        // Hide loading screen just in case it was triggered by a fallback
        loadingOverlay.style.display = 'none';

        // Clear all dynamic war state
        occupationMap.fill(0);
        primaryOccupierMap.fill(0);
        units = [];
        bombs = [];
        explosions = [];
        bases = [];
        activeBattles = [];
        capitalLostCountries = new Set();
        activeRebellion = null;
        countryCasualties.clear();
        latestCountryStats.clear();
        selectedCountryIds.clear();
        operationStarts.clear();

        // Reset time system and manpower to pristine state
        gameTimeEnabled = false;
        gameTimeDate = null;
        gameTimeAccumulatorMs = 0;
        if (gameDateDisplay) {
            gameDateDisplay.style.display = 'none';
        }
        teamASoldiers = 0;
        teamBSoldiers = 0;
        initialTeamASoldiers = 0;
        initialTeamBSoldiers = 0;
        soldiersPerUnitA = CONFIG.UNIT_TO_SOLDIER_RATIO;
        soldiersPerUnitB = CONFIG.UNIT_TO_SOLDIER_RATIO;

        // Reset sides / selection but keep the active scenario context
        sides = [[], []];
        attackers = sides[0];
        defenders = sides[1];
        activeSideIndex = 0;
        teamAId = -1;
        ffaMode = false;
        buffedTeam = null;

        // Reset UI back to conflict setup with no loading screen
        gameState = 'SELECTING_P1';
        statusText.innerText = getTranslation('SELECT_P1');
        setupPanel.style.display = 'block';
        setupOptions.style.display = 'none';
        statsPanel.style.display = 'none';
        casualtyPanel.style.display = 'none';
        document.getElementById('speed-controls').style.display = 'none';
        godModeBtn.style.display = (gameMode === 'CONQUEST') ? 'block' : 'none';
        forcePeaceBtn.style.display = 'none';
        unitCountsDiv.style.display = 'none';
        treatyAlert.style.display = 'none';
        frameAccumulator = 0;
        simFrameCount = 0;
        setSpeed(0);
        updateSidesUI();
        updateRestartVisibility();
        recalculateAllBounds();
        
        // Force an immediate high-priority redraw of the canvas layer
        if (influenceLayer) {
            influenceLayer._forceRender = true;
            if (typeof influenceLayer._update === 'function') {
                influenceLayer._update();
            } else {
                influenceLayer.render();
            }
        }
    });
}

resetBtn.addEventListener('click', resetGame);

// In‑game MENU button: return to main menu without full page reload
mainMenuBtn.addEventListener('click', () => {
    // Stop any running simulation loops
    if (animationFrameId !== null) {
        cancelAnimationFrame(animationFrameId);
        animationFrameId = null;
    }
    if (backgroundTickId) {
        clearInterval(backgroundTickId);
        backgroundTickId = null;
    }
    stopWarAmbiance();

    // Reset high‑level state to menu
    gameState = 'MAIN_MENU';
    gameMode = 'CONQUEST';
    isPaused = false;

    // Hide in‑game UI and show main menu
    mapUi.style.display = 'none';
    settingsOverlay.style.display = 'none';
    loadingOverlay.style.display = 'none';
    scenarioHubModal.style.display = 'none';
    tutorialOverlay.style.display = 'none';
    creditsModal.style.display = 'none';
    if (leaderboardOverlay) leaderboardOverlay.style.display = 'none';
    mainMenu.style.display = 'flex';

    // Ensure background music resumes when returning to the main menu
    initAudio();

    // Make sure restart/menu visibility is updated for when you re‑enter a scenario
    updateRestartVisibility();
});

startBtn.addEventListener('click', () => {
    activeRebellion = null;
    startWar();
});

if (rebellionBtn) {
    // Rebellions are disabled; keep this button inert.
    rebellionBtn.addEventListener('click', () => {
        alert("Rebellions have been disabled in this build.");
    });
}

editorUpdateBtn.addEventListener('click', async () => {
    if (!activeScenarioId) return;
    if (!confirm("Update existing scenario? This will overwrite the map file and thumbnail on the Hub.")) return;

    loadingStatus.innerText = "Updating Scenario...";
    loadingOverlay.style.display = 'flex';

    try {
        // 1. Generate updated preview
        let previewUrl = null;
        if (influenceLayer && influenceLayer._container) {
            influenceLayer._isCapturing = true;
            influenceLayer.render();
            const canvas = influenceLayer._container;
            const previewBlob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.8));
            influenceLayer._isCapturing = false;
            influenceLayer.render();
            if (previewBlob) {
                const previewFile = new File([previewBlob], "update_preview.jpg", { type: "image/jpeg" });
                previewUrl = await websim.upload(previewFile);
            }
        }

        // 2. Generate updated preset data
        const currentName = statusText.innerText.replace("REMIXING: ", "").replace("Map Editor (Alpha)", "Updated Scenario");
        const saveData = generatePresetData(currentName);
        const blob = new Blob([JSON.stringify(saveData)], { type: 'application/json' });
        const file = new File([blob], "updated_scenario.json", { type: "application/json" });
        const blobUrl = await websim.upload(file);

        // 3. Update existing record
        await room.collection('scenario_v1').update(activeScenarioId, {
            previewUrl: previewUrl,
            blobUrl: blobUrl
        });

        loadingOverlay.style.display = 'none';
        alert("Scenario updated successfully!");
    } catch (e) {
        console.error(e);
        alert("Update failed. You can only update scenarios you created.");
        loadingOverlay.style.display = 'none';
    }
});

godModeBtn.addEventListener('click', () => {
    if (!godModeActive) {
        // Activate God Mode
        godModeActive = true;
        preGodModeState = gameState;
        gameState = 'EDITOR_ACTIVE';
        
        godModeBtn.innerText = getTranslation('GOD_ACTIVE');
        godModeBtn.style.background = "#27ae60";
        
        // Setup UI
        editorToolbox.style.display = 'flex';
        setupPanel.style.display = 'none';
        statsPanel.style.display = 'none';
        // Allow sharing and saving any current map state from God Mode, including official presets
        editorShareBtn.style.display = 'block';
        editorSaveBtn.style.display = 'block';
        editorHubBtn.style.display = 'block';
        editorLibraryBtn.style.display = 'block';
        shareFlagBtn.style.display = 'block';
        editorExitBtn.style.display = 'none';
        editorTestBtn.style.display = 'none';
        editorUpdateBtn.style.display = activeScenarioId ? 'block' : 'none';
        editorUnclaimBtn.style.display = 'block';
        
        statusText.innerText = currentScenarioContext ? `GOD MODE // REMIXING: ${currentScenarioContext.name}` : "GOD MODE: Map Editing Active";
        updateRestartVisibility();
    } else {
        // Deactivate God Mode
        godModeActive = false;
        gameState = preGodModeState;
        
        godModeBtn.innerText = getTranslation('GOD_MODE');
        godModeBtn.style.background = "#d35400";
        
        // Hide editor UI
        editorToolbox.style.display = 'none';
        countryInspector.style.display = 'none';
        shareFlagBtn.style.display = 'none';
        map.getContainer().classList.remove('painting-cursor');
        
        // Refresh simulation caches in case land changed
        if (gameState === 'SIMULATING' || preGodModeState === 'SIMULATING') {
            statsPanel.style.display = 'block';
            activeTheaterCities = cities.filter(c => {
                const idx = getGridIndex(c.lat, c.lng);
                return idx !== -1 && landMask[idx] === 2;
            });
            // Ensure loop restarts if it was stopped
            cancelAnimationFrame(animationFrameId);
            requestAnimationFrame(updateLoop);
        }
        
        if (gameState.startsWith('SELECTING') || gameState === 'WAR_OVER') {
            if (gameState === 'WAR_OVER') gameState = 'SELECTING_P1';
            setupPanel.style.display = 'block';
            statusText.innerText = currentScenarioContext ? `PLAYING: ${currentScenarioContext.name}` : getTranslation('SELECT_P1');
            updateSidesUI();
        } else if (gameState === 'SIMULATING') {
            statsPanel.style.display = 'block';
            statusText.innerText = ffaMode ? "Free For All Active" : "Global Conflict Active";
        } else {
            // Safety fallback: transition any orphaned state to setup mode
            gameState = 'SELECTING_P1';
            setupPanel.style.display = 'block';
            statusText.innerText = getTranslation('SELECT_P1');
            updateSidesUI();
        }
        updateRestartVisibility();
    }
});

forcePeaceBtn.addEventListener('click', () => {
    if (gameState === 'SIMULATING') {
        gameState = 'PEACE_SELECT_1';
        statusText.innerText = "DIPLOMACY: Click nation to withdraw from war";
        peaceSelection1 = null;
    } else if (gameState === 'PEACE_SELECT_1' || gameState === 'PEACE_SELECT_2') {
        // Double click/cancel to just do a global peace
        if (confirm("Sign global white peace for all remaining combatants?")) {
            applyTreaty('PEACE_TREATY');
        } else {
            gameState = 'SIMULATING';
            statusText.innerText = "Conflict Continued";
            requestAnimationFrame(updateLoop);
        }
    }
});

function unilateralExitConflict(country, sideIdx) {
    if (sideIdx === -1) return;

    const poleIdx = sideIdx % 2;

    // Redraw borders: Keep all currently occupied land
    for (let i = 0; i < worldControlMap.length; i++) {
        if (landMask[i] !== 2) continue;

        const ownerId = worldControlMap[i];
        const occupierId = primaryOccupierMap[i];
        const occ = occupationMap[i];
        
        // A) If exiting nation is occupying someone else's land, they annex it
        if (occupierId === country.id) {
            const isOccupyingEnemy = (poleIdx === 0) ? (occ > 0.05) : (occ < -0.05);
            if (isOccupyingEnemy) {
                worldControlMap[i] = country.id;
            }
            landMask[i] = 1; // Stabilize
            occupationMap[i] = 0;
            primaryOccupierMap[i] = 0;
        } 
        // B) If someone else is occupying the exiting nation's land, they keep it (unilateral exit logic)
        else if (ownerId === country.id) {
            const isOccupiedByEnemy = (poleIdx === 0) ? (occ < -0.05) : (occ > 0.05);
            if (isOccupiedByEnemy) {
                // If they are exiting, they lose this land to the current occupier
                worldControlMap[i] = occupierId > 0 ? occupierId : ownerId;
            }
            landMask[i] = 1; // Stabilize
            occupationMap[i] = 0;
            primaryOccupierMap[i] = 0;
        }
    }

    // Remove from sides
    const side = sides[sideIdx];
    const idx = side.findIndex(c => c.id === country.id);
    if (idx > -1) side.splice(idx, 1);

    // Purge units
    units = units.filter(u => u.sovereignId !== country.id);
    units.forEach(u => { if (u.beneficiaryId === country.id) u.beneficiaryId = u.sovereignId; });

    // Global cleanup for neutral land that might be stuck in war state
    const combatantIds = new Set(sides.flat().map(c => c.id));
    for (let i = 0; i < worldControlMap.length; i++) {
        if (landMask[i] === 2 && !combatantIds.has(worldControlMap[i]) && Math.abs(occupationMap[i]) < 0.01) {
            landMask[i] = 1;
            occupationMap[i] = 0;
            primaryOccupierMap[i] = 0;
        }
    }

    generateProvinces();
    recalculateAllBounds();
    updateSidesUI();
    influenceLayer.render();

    playPeaceSound();
    statusText.innerText = `${country.name} has exited the conflict and annexed occupied land.`;

    const activePoles = new Set();
    sides.forEach((s, idx) => { if (s.length > 0) activePoles.add(idx % 2); });

    if (activePoles.size < 2) {
        applyTreaty('PEACE_TREATY');
    }
}

function signSelectivePeace(exiter, target) {
    let exiterSideIdx = -1;
    let targetSideIdx = -1;
    
    sides.forEach((s, i) => {
        if (s.some(c => c.id === exiter.id)) exiterSideIdx = i;
        if (s.some(c => c.id === target.id)) targetSideIdx = i;
    });

    if (exiterSideIdx === -1 || targetSideIdx === -1 || (exiterSideIdx % 2 === targetSideIdx % 2)) {
        alert("Diplomatic error: Negotiating nations must be on opposing sides.");
        gameState = 'SIMULATING';
        statusText.innerText = "Conflict Continued";
        requestAnimationFrame(updateLoop);
        return;
    }

    // The 'target' (second nation clicked) is the one exiting the specific conflict engagement
    const exiterPoleIdx = exiterSideIdx % 2;
    const targetPoleIdx = targetSideIdx % 2; 

    // 1. Redraw borders for the TARGET nation as it exits the war
    // As per user request: "work like normal peace treatys where the occupied land gets annexed and only the occupied parts"
    for (let i = 0; i < worldControlMap.length; i++) {
        if (landMask[i] !== 2) continue;

        const ownerId = worldControlMap[i];
        const occupierId = primaryOccupierMap[i];
        const occ = occupationMap[i];
        
        // A) If the target (leaving nation) owns this land, and it's being occupied by enemies
        if (ownerId === target.id) {
            const isOccupiedByEnemy = (targetPoleIdx === 0) ? (occ < -0.05) : (occ > 0.05);
            if (isOccupiedByEnemy) {
                // Annexation: Give land to the specific occupier
                worldControlMap[i] = occupierId > 0 ? occupierId : exiter.id;
                landMask[i] = 1; // Stabilize
                occupationMap[i] = 0;
                primaryOccupierMap[i] = 0;
            }
        } 
        // B) If the target (leaving nation) is occupying someone else's land, it gets annexed by the target
        else if (occupierId === target.id) {
            const isOccupyingEnemy = (targetPoleIdx === 0) ? (occ > 0.05) : (occ < -0.05);
            if (isOccupyingEnemy) {
                worldControlMap[i] = target.id;
                landMask[i] = 1; // Stabilize
                occupationMap[i] = 0;
            } else {
                // Retreat from allies or neutral land
                occupationMap[i] = 0;
            }
            primaryOccupierMap[i] = 0;
        }
    }

    // 2. Remove the target country from its alliance list
    const targetSide = sides[targetSideIdx];
    const idx = targetSide.findIndex(c => c.id === target.id);
    if (idx > -1) targetSide.splice(idx, 1);

    // 3. Purge units belonging to the target nation
    units = units.filter(u => u.sovereignId !== target.id);
    
    // Reset beneficiary IDs for units that were supporting the leaving nation
    units.forEach(u => {
        if (u.beneficiaryId === target.id) u.beneficiaryId = u.sovereignId;
    });

    // 4. Final Sweep: Stabilize land owned by nations no longer in the war
    const combatantIds = new Set(sides.flat().map(c => c.id));
    for (let i = 0; i < worldControlMap.length; i++) {
        if (landMask[i] === 2) {
            const ownerId = worldControlMap[i];
            // If owner is not a combatant AND no one else is currently occupying it, stabilize it
            if (!combatantIds.has(ownerId) && Math.abs(occupationMap[i]) < 0.01) {
                landMask[i] = 1;
                occupationMap[i] = 0;
                primaryOccupierMap[i] = 0;
            }
        }
    }

    // 5. Separate Peace Smoothing Pass - Optimized to avoid GC thrashing
    const smoothingPasses = 2;
    for (let p = 0; p < smoothingPasses; p++) {
        const tempMap = new Int32Array(worldControlMap);
        const uniqueIds = new Int32Array(9); 
        const idCounts = new Int32Array(9);
        
        for (let y = 1; y < gridHeight - 1; y++) {
            const rowIdx = y * gridWidth;
            for (let x = 1; x < gridWidth - 1; x++) {
                const i = rowIdx + x;
                if (landMask[i] !== 1) continue; 
                
                uniqueIds.fill(0);
                idCounts.fill(0);
                let numUnique = 0;

                for (let dy = -1; dy <= 1; dy++) {
                    for (let dx = -1; dx <= 1; dx++) {
                        const nId = worldControlMap[i + dy * gridWidth + dx];
                        if (nId > 0) {
                            let found = false;
                            for (let k = 0; k < numUnique; k++) {
                                if (uniqueIds[k] === nId) {
                                    idCounts[k]++;
                                    found = true;
                                    break;
                                }
                            }
                            if (!found && numUnique < 9) {
                                uniqueIds[numUnique] = nId;
                                idCounts[numUnique] = 1;
                                numUnique++;
                            }
                        }
                    }
                }
                
                let bestId = worldControlMap[i];
                let maxC = 0;
                for (let k = 0; k < numUnique; k++) {
                    if (idCounts[k] > maxC) {
                        maxC = idCounts[k];
                        bestId = uniqueIds[k];
                    }
                }
                if (maxC >= 5) tempMap[i] = bestId;
            }
        }
        worldControlMap.set(tempMap);
    }

    // 6. Update UI and check for total conflict end
    generateProvinces();
    recalculateAllBounds();
    updateSidesUI();
    influenceLayer.render();
    
    const activePoles = new Set();
    sides.forEach((side, idx) => {
        if (side.length > 0) activePoles.add(idx % 2);
    });

    if (activePoles.size < 2) {
        applyTreaty('PEACE_TREATY');
    } else {
        playPeaceSound();
        gameState = 'SIMULATING';
        statusText.innerText = `${target.name} signed separate peace. Conflict continues.`;
        cancelAnimationFrame(animationFrameId);
        requestAnimationFrame(updateLoop);
    }
}

const SPEED_STEPS = [0.25, 0.5, 1, 1.5, 2, 3];
let currentSpeedIndex = 0; // Index for "0.1x"

function togglePause() {
    isPaused = !isPaused;
    pauseBtn.innerText = isPaused ? '▶' : '⏸';
    pauseBtn.style.background = isPaused ? '#27ae60' : '#f39c12';
    statusText.innerText = isPaused ? getTranslation('SIM_PAUSED') : (ffaMode ? getTranslation('STABLE') : getTranslation('STABLE'));
}

pauseBtn.addEventListener('click', togglePause);



// Keybinds
document.addEventListener('keydown', (e) => {
    // Don't trigger if user is typing in an input or textarea
    if (['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;

    if (e.code === 'Space') {
        if (gameState === 'SIMULATING') {
            e.preventDefault();
            togglePause();
        }
    }

    if (e.key === 'Delete' || e.key === 'Backspace') {
        if ((gameMode === 'EDITOR' || godModeActive) && editingCountryId > 0) {
            e.preventDefault();
            unclaimSelectedCountry();
        }
    }

    // Z key: instantly zoom out to a global view of the entire world
    if (e.key === 'z' || e.key === 'Z') {
        e.preventDefault();
        // Fit the whole world into view with a small padding for aesthetics
        map.fitWorld({ animate: true, padding: [20, 20] });
    }

    if (e.key === 'Escape') {
        if (gameState === 'PEACE_SELECT_1' || gameState === 'PEACE_SELECT_2') {
            e.preventDefault();
            gameState = 'SIMULATING';
            statusText.innerText = "Conflict Continued";
            requestAnimationFrame(updateLoop);
        } else if (countryInspector.style.display === 'block') {
            closeInspectorBtn.click();
        }
    }
});

function unclaimSelectedCountry() {
    if (editingCountryId <= 0) return;
    
    const meta = countryMetadata.find(m => m && m.id === editingCountryId);
    const name = meta ? meta.name : "Nation";
    
    // Visual confirmation is good for destructive actions
    if (!confirm(`Satellite Directive: Are you sure you want to unclaim all territory for ${name}?`)) return;

    for (let i = 0; i < worldControlMap.length; i++) {
        if (worldControlMap[i] === editingCountryId) {
            worldControlMap[i] = 0;
        }
    }
    
    // Also remove from any active conflict sides
    sides.forEach(side => {
        const idx = side.findIndex(c => c.id === editingCountryId);
        if (idx > -1) side.splice(idx, 1);
    });
    
    updateSidesUI();
    countryInspector.style.display = 'none';
    editingCountryId = -1;
    recalculateAllBounds();
    influenceLayer.render();
    statusText.innerText = `UNCLAIMED: ${name} territory has been returned to neutral status.`;
}

function setSpeed(index) {
    currentSpeedIndex = Math.max(0, Math.min(index, SPEED_STEPS.length - 1));
    simSpeed = SPEED_STEPS[currentSpeedIndex];
    ffBtn.innerText = simSpeed + "x";
    if (simSpeed === 1) {
        ffBtn.classList.remove('active');
    } else {
        ffBtn.classList.add('active');
    }
    frameAccumulator = 0;
}

ffBtn.addEventListener('click', () => {
    let nextIndex = (currentSpeedIndex + 1) % SPEED_STEPS.length;
    setSpeed(nextIndex);
});

speedDownBtn.addEventListener('click', () => {
    setSpeed(currentSpeedIndex - 1);
});

speedUpBtn.addEventListener('click', () => {
    setSpeed(currentSpeedIndex + 1);
});

if (customTrackInput) {
    customTrackInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        loadingStatus.innerText = "Uploading Soundtrack...";
        loadingOverlay.style.display = 'flex';
        
        try {
            const url = await websim.upload(file);
            customTrackUrl = url;
            setCookie('mw_custom_track', url);
            
            // Restart music with new track
            if (bgMusicSource) {
                bgMusicSource.stop();
                bgMusicSource = null;
            }
            initAudio();
            loadingOverlay.style.display = 'none';
            alert("Custom soundtrack applied and saved!");
        } catch (err) {
            console.error(err);
            alert("Failed to upload soundtrack.");
            loadingOverlay.style.display = 'none';
        }
    });
}

if (clearCustomTrackBtn) {
    clearCustomTrackBtn.addEventListener('click', () => {
        customTrackUrl = null;
        setCookie('mw_custom_track', '');
        if (customTrackInput) customTrackInput.value = '';
        
        if (bgMusicSource) {
            bgMusicSource.stop();
            bgMusicSource = null;
        }
        initAudio();
        alert("Soundtrack reset to original.");
    });
}

async function initMultiplayer() {
    if (room) return;
    room = new WebsimSocket();
    await room.initialize();

    try {
        const currentUser = await window.websim.getCurrentUser();
        currentUsername = currentUser?.username || null;
    } catch (e) {
        console.warn('Failed to get current user for comments', e);
        currentUsername = null;
    }
    
    // Subscribe to persistent scenario records
    room.collection('scenario_v1').subscribe((scenarios) => {
        if (scenarioHubModal.style.display === 'flex') {
            renderHub(scenarios);
        }
    });

    // Subscribe to persistent country records
    room.collection('country_library_v1').subscribe((countries) => {
        if (scenarioHubModal.style.display === 'flex') {
            renderCountryLibrary(countries);
        }
    });

    // Subscribe to persistent flag records
    room.collection('flag_library_v1').subscribe((flags) => {
        if (scenarioHubModal.style.display === 'flex') {
            renderFlagLibrary(flags);
        }
    });

    // Subscribe to comments so hub cards show live comment counts
    room.collection('hub_comment_v1').subscribe(() => {
        // Only bother re-rendering when the hub is visible
        if (scenarioHubModal.style.display === 'flex') {
            const scenarios = room.collection('scenario_v1').getList();
            renderHub(scenarios || []);
        }
    });
}

function openHub(initialTab = 'scenarios') {
    scenarioHubModal.style.display = 'flex';
    switchHubTab(initialTab);
    
    // Refresh content
    renderHub(room.collection('scenario_v1').getList());
    renderCountryLibrary(room.collection('country_library_v1').getList());
    renderFlagLibrary(room.collection('flag_library_v1').getList());
}

function switchHubTab(tab) {
    tabScenariosBtn.classList.remove('active');
    tabCountriesBtn.classList.remove('active');
    tabFlagsBtn.classList.remove('active');
    hubList.style.display = 'none';
    libraryList.style.display = 'none';
    flagLibraryList.style.display = 'none';

    if (tab === 'scenarios') {
        tabScenariosBtn.classList.add('active');
        hubList.style.display = 'grid';
    } else if (tab === 'countries') {
        tabCountriesBtn.classList.add('active');
        libraryList.style.display = 'grid';
    } else if (tab === 'flags') {
        tabFlagsBtn.classList.add('active');
        flagLibraryList.style.display = 'grid';
    }
}

tabScenariosBtn.onclick = () => switchHubTab('scenarios');
tabCountriesBtn.onclick = () => switchHubTab('countries');
tabFlagsBtn.onclick = () => switchHubTab('flags');

function renderHub(scenarios) {
    // scenarios is now an array from the database
    const list = scenarios; 
    hubScenarioCache = {};
    if (list.length === 0) {
        hubList.innerHTML = `<div style="grid-column: 1/-1; text-align: center; color: #666; padding: 40px;">No scenarios uploaded yet. Be the first!</div>`;
        return;
    }

    const myUsername = room.peers[room.clientId]?.username;

    // Compute comment counts per scenario id
    let commentCounts = {};
    try {
        const allComments = room.collection('hub_comment_v1').getList();
        allComments.forEach(c => {
            if (c.item_type === 'scenario' && c.item_id) {
                commentCounts[c.item_id] = (commentCounts[c.item_id] || 0) + 1;
            }
        });
    } catch (e) {
        commentCounts = {};
    }

    hubList.innerHTML = list.map((s) => {
        hubScenarioCache[s.id] = s;
        const safeName = (s.name || '').replace(/'/g, "\\'");
        const safeOwner = (s.username || '').replace(/'/g, "\\'");
        const cCount = commentCounts[s.id] || 0;
        const cLabel = cCount === 1 ? '1 comment' : `${cCount} comments`;
        return `
        <div class="hub-item" data-item-type="scenario" data-item-id="${s.id}">
            <img src="${s.previewUrl || 'https://images.websim.ai/v1/projects/placeholder/landscape'}" class="hub-preview-img">
            <div class="hub-content">
                <div class="hub-info">
                    <div class="hub-name">${s.name}</div>
                    <div class="hub-meta">
                        <img src="https://images.websim.com/avatar/${s.username}" class="hub-author-img">
                        <span>${s.username}</span>
                    </div>
                    ${s.remixed_from_name ? `
                        <div style="font-size: 9px; color: #8e44ad; text-transform: uppercase; font-weight: 900; letter-spacing: 1px; margin-top: 4px; display: flex; align-items: center; gap: 4px;">
                            <span>🔄</span> REMIXED FROM ${s.remixed_from_name}
                        </div>
                    ` : ''}
                </div>
                <div class="hub-description">${s.description || 'No description provided.'}</div>
                <div class="hub-comment-count">💬 ${cLabel}</div>
                <div class="hub-actions" style="margin-top: auto; display: flex; justify-content: flex-end; align-items: center;">
                    <span style="font-size: 10px; color: #555;">${new Date(s.created_at).toLocaleDateString()}</span>
                </div>
            </div>
        </div>
    `;
    }).join('');

    // Attach click handlers to open item modal when clicking the card background
    hubList.querySelectorAll('.hub-item').forEach(card => {
        if (card.dataset.boundClick) return;
        card.dataset.boundClick = '1';
        card.addEventListener('click', (ev) => {
            // Ignore clicks on buttons inside the card
            if (ev.target.closest('.hub-actions-buttons') || ev.target.closest('button')) return;
            const id = card.getAttribute('data-item-id');
            if (!id) return;
            const item = hubScenarioCache[id];
            if (!item) return;
            openItemModal('scenario', item);
        });
    });
}

window.deleteScenario = async (id) => {
    if (!confirm("Are you sure you want to delete this scenario?")) return;
    try {
        await room.collection('scenario_v1').delete(id);
    } catch (e) {
        console.error(e);
        alert("Failed to delete scenario. You can only delete your own posts.");
    }
};

function renderCountryLibrary(countries) {
    hubCountryCache = {};
    if (countries.length === 0) {
        libraryList.innerHTML = `<div style="grid-column: 1/-1; text-align: center; color: #666; padding: 40px;">Library is empty. Contribute your nations!</div>`;
        return;
    }

    const myUsername = room.peers[room.clientId]?.username;
    const canImport = gameMode === 'EDITOR' || godModeActive;

    libraryList.innerHTML = countries.map((c) => {
        hubCountryCache[c.id] = c;
        return `
        <div class="hub-item" data-item-type="country" data-item-id="${c.id}">
            <div style="height: 120px; position: relative; display: flex; align-items: center; justify-content: center; background: #000; border-bottom: 1px solid rgba(255,255,255,0.1); overflow: hidden;">
                 <img src="${c.previewUrl || 'https://images.websim.ai/v1/projects/placeholder/landscape'}" style="width: 100%; height: 100%; object-fit: cover; opacity: 0.6;">
                 <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: radial-gradient(circle, transparent 30%, #000 100%);"></div>
                 <div style="position: absolute; display: flex; align-items: center; justify-content: center; z-index: 2;">
                    ${c.flagUrl ? `<img src="${c.flagUrl}" style="max-height: 40px; max-width: 60px; box-shadow: 0 4px 10px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.2);">` : '<span style="font-size: 30px;">🏳️</span>'}
                 </div>
                 <div style="position: absolute; bottom: 5px; left: 5px; right: 5px; height: 3px; background: ${c.color || '#fff'}; border-radius: 2px;"></div>
            </div>
            <div class="hub-content">
                <div class="hub-info">
                    <div class="hub-name">${c.name}</div>
                    <div class="hub-meta">
                        <img src="https://images.websim.com/avatar/${c.username}" class="hub-author-img">
                        <span>${c.username}</span>
                    </div>
                </div>
                <div class="hub-description">${c.description || 'No description provided.'}</div>
                <div class="hub-actions" style="margin-top: auto; display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; gap: 5px;" class="hub-actions-buttons">
                        ${canImport ? `<button class="mini-btn" style="background: #27ae60; padding: 6px 12px;" onclick="window.importFromLibrary('${c.id}')">IMPORT</button>` : ''}
                        ${c.username === myUsername ? 
                            `<button class="mini-btn" style="background: #c0392b; padding: 6px 12px;" onclick="window.deleteCountry('${c.id}')">DEL</button>` : 
                            ''
                        }
                    </div>
                    <span style="font-size: 10px; color: #555;">${new Date(c.created_at).toLocaleDateString()}</span>
                </div>
            </div>
        </div>
    `;
    }).join('');

    libraryList.querySelectorAll('.hub-item').forEach(card => {
        if (card.dataset.boundClick) return;
        card.dataset.boundClick = '1';
        card.addEventListener('click', (ev) => {
            if (ev.target.closest('.hub-actions-buttons') || ev.target.closest('button')) return;
            const id = card.getAttribute('data-item-id');
            if (!id) return;
            const item = hubCountryCache[id];
            if (!item) return;
            openItemModal('country', item);
        });
    });
}

function renderFlagLibrary(flags) {
    hubFlagCache = {};
    if (flags.length === 0) {
        flagLibraryList.innerHTML = `<div style="grid-column: 1/-1; text-align: center; color: #666; padding: 40px;">No custom flags shared yet. Be the first!</div>`;
        return;
    }

    const myUsername = room.peers[room.clientId]?.username;
    const canImport = gameMode === 'EDITOR' || godModeActive;

    flagLibraryList.innerHTML = flags.map((f) => {
        hubFlagCache[f.id] = f;
        return `
        <div class="hub-item" data-item-type="flag" data-item-id="${f.id}">
            <div style="height: 100px; display: flex; align-items: center; justify-content: center; background: #000; border-bottom: 1px solid rgba(255,255,255,0.1); padding: 15px;">
                 <img src="${f.flagUrl}" style="max-height: 100%; max-width: 100%; box-shadow: 0 4px 15px rgba(0,0,0,0.5); border: 1px solid rgba(255,255,255,0.2);">
            </div>
            <div class="hub-content">
                <div class="hub-info">
                    <div class="hub-name">${f.name}</div>
                    <div class="hub-meta">
                        <img src="https://images.websim.com/avatar/${f.username}" class="hub-author-img">
                        <span>${f.username}</span>
                    </div>
                </div>
                <div class="hub-description">${f.description || 'No description.'}</div>
                <div class="hub-actions" style="margin-top: auto; display: flex; justify-content: space-between; align-items: center;">
                    <div style="display: flex; gap: 5px;" class="hub-actions-buttons">
                        ${canImport ? `<button class="mini-btn" style="background: #2e86de; padding: 6px 12px;" onclick="window.importFlagFromLibrary('${f.id}')">USE</button>` : ''}
                        ${f.username === myUsername ? 
                            `<button class="mini-btn" style="background: #c0392b; padding: 6px 12px;" onclick="window.deleteFlag('${f.id}')">DEL</button>` : 
                            ''
                        }
                    </div>
                </div>
            </div>
        </div>
    `;
    }).join('');

    flagLibraryList.querySelectorAll('.hub-item').forEach(card => {
        if (card.dataset.boundClick) return;
        card.dataset.boundClick = '1';
        card.addEventListener('click', (ev) => {
            if (ev.target.closest('.hub-actions-buttons') || ev.target.closest('button')) return;
            const id = card.getAttribute('data-item-id');
            if (!id) return;
            const item = hubFlagCache[id];
            if (!item) return;
            openItemModal('flag', item);
        });
    });
}

window.deleteFlag = async (id) => {
    if (!confirm("Remove this flag from the library?")) return;
    try {
        await room.collection('flag_library_v1').delete(id);
    } catch (e) {
        console.error(e);
        alert("Delete failed.");
    }
};

/**
 * GLOBAL EXPORTS FOR HUB INTERACTION
 */
window.importFlagFromLibrary = async (id) => {
    // Robust lookup to ensure we have the data
    let list = room.collection('flag_library_v1').getList();
    let flagData = list.find(f => f.id === id);
    
    if (!flagData || editingCountryId <= 0) {
        if (editingCountryId <= 0) {
            alert("SATELLITE INTERFACE: You must select a nation on the map first to designate a target for the new national identity.");
        } else {
            alert("SATELLITE ERROR: Could not retrieve flag data from the hub archives.");
        }
        return;
    }

    const meta = countryMetadata.find(m => m && m.id === editingCountryId);
    if (meta) {
        updateCountryFlag(editingCountryId, flagData.flagUrl);
        scenarioHubModal.style.display = 'none';
        // Visual confirmation
        statusText.innerText = `IDENTIFIED: ${meta.name} now using community flag '${flagData.name}'`;
    }
};

function saveCountryLocally(countryId) {
    const meta = countryMetadata.find(m => m && m.id === countryId);
    if (!meta) return;

    const countryData = {
        id: meta.id,
        name: meta.name,
        color: meta.color,
        flagUrl: meta.flagUrl,
        isCustom: meta.isCustom || false,
        role: meta.role || 'OFFENSE',
        overlordId: meta.overlordId || null
    };

    const cells = [];
    for (let i = 0; i < worldControlMap.length; i++) {
        if (worldControlMap[i] === countryId) {
            const y = Math.floor(i / gridWidth);
            const x = i % gridWidth;
            cells.push([x, y]);
        }
    }

    // Cache cells on metadata so releasables and multi-export can reuse them
    meta.savedCells = cells;

    const presetData = {
        name: `${meta.name}_country`,
        metadata: countryData,
        cells: cells,
        gridRes: CONFIG.GRID_RES,
        version: "1.0"
    };

    const blob = new Blob([JSON.stringify(presetData)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${meta.name.replace(/\s+/g, '_')}_country.json`;
    a.click();
    URL.revokeObjectURL(url);

    statusText.innerText = `SAVED: ${meta.name} exported locally`;
}

function loadCountryFromPC() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        loadingStatus.innerText = "Loading Country Data...";
        loadingOverlay.style.display = 'flex';

        try {
            const text = await file.text();
            const data = JSON.parse(text);

            if (!data.metadata || !data.cells) {
                throw new Error("Invalid country file structure");
            }

            const currentRes = CONFIG.GRID_RES;
            const sourceRes = data.gridRes || currentRes;

            // Find next available country ID
            const maxId = countryMetadata.reduce((max, m) => m ? Math.max(max, m.id) : max, 0);
            const newId = maxId + 1;

            // Create metadata entry
            const meta = {
                id: newId,
                name: data.metadata.name || "Imported Nation",
                color: data.metadata.color || 'rgba(150, 150, 150, 0.5)',
                rgba: parseColorToRGBA(data.metadata.color || 'rgba(150, 150, 150, 0.5)'),
                isCustom: true,
                flagUrl: data.metadata.flagUrl || null,
                role: data.metadata.role || 'OFFENSE',
                overlordId: data.metadata.overlordId || null,
                bounds: { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity }
            };

            if (meta.flagUrl) {
                meta.tempFlag = new Image();
                meta.tempFlag.crossOrigin = "anonymous";
                meta.tempFlag.src = meta.flagUrl;
            }

            countryMetadata[newId - 1] = meta;

            // Place cells on map with resolution conversion if needed
            for (const [sx, sy] of data.cells) {
                if (sourceRes === currentRes) {
                    const idx = sy * gridWidth + sx;
                    if (idx < worldControlMap.length) {
                        worldControlMap[idx] = newId;
                        provinceMap[idx] = getProvinceId(sx, sy, newId);
                        if (landMask[idx] === 0) landMask[idx] = 1;
                        
                        // Update bounds
                        meta.bounds.minX = Math.min(meta.bounds.minX, sx);
                        meta.bounds.maxX = Math.max(meta.bounds.maxX, sx);
                        meta.bounds.minY = Math.min(meta.bounds.minY, sy);
                        meta.bounds.maxY = Math.max(meta.bounds.maxY, sy);
                    }
                } else {
                    // Convert coordinates
                    const baseLat = (sy * sourceRes) - 90;
                    const baseLng = (sx * sourceRes) - 180;
                    
                    if (sourceRes > currentRes) {
                        for (let lat = baseLat; lat < baseLat + sourceRes; lat += currentRes) {
                            for (let lng = baseLng; lng < baseLng + sourceRes; lng += currentRes) {
                                const tIdx = getGridIndex(lat + currentRes/2, lng + currentRes/2);
                                if (tIdx !== -1) {
                                    worldControlMap[tIdx] = newId;
                                    provinceMap[tIdx] = getProvinceId(Math.floor((lng + currentRes/2 + 180) / currentRes), Math.floor((lat + currentRes/2 + 90) / currentRes), newId);
                                    if (landMask[tIdx] === 0) landMask[tIdx] = 1;
                                }
                            }
                        }
                    } else {
                        const tIdx = getGridIndex(baseLat + sourceRes/2, baseLng + sourceRes/2);
                        if (tIdx !== -1) {
                            worldControlMap[tIdx] = newId;
                            const tx = Math.floor((baseLng + sourceRes/2 + 180) / currentRes);
                            const ty = Math.floor((baseLat + sourceRes/2 + 90) / currentRes);
                            provinceMap[tIdx] = getProvinceId(tx, ty, newId);
                            if (landMask[tIdx] === 0) landMask[tIdx] = 1;
                            
                            // Update bounds
                            meta.bounds.minX = Math.min(meta.bounds.minX, tx);
                            meta.bounds.maxX = Math.max(meta.bounds.maxX, tx);
                            meta.bounds.minY = Math.min(meta.bounds.minY, ty);
                            meta.bounds.maxY = Math.max(meta.bounds.maxY, ty);
                        }
                    }
                }
            }

            loadingOverlay.style.display = 'none';
            
            // Check if bounds were updated, if not set reasonable defaults
            if (meta.bounds.minX === Infinity) {
                meta.bounds = { minX: 0, maxX: gridWidth-1, minY: 0, maxY: gridHeight-1 };
            }

            openInspector(newId);
            statusText.innerText = `IMPORTED: ${meta.name} from local file`;
            influenceLayer.render();
        } catch (err) {
            console.error("Country import error:", err);
            alert(`Failed to import country: ${err.message}`);
            loadingOverlay.style.display = 'none';
        }
    };
    input.click();
}

window.deleteCountry = async (id) => {
    if (!confirm("Are you sure you want to delete this country from the library?")) return;
    try {
        await room.collection('country_library_v1').delete(id);
    } catch (e) {
        console.error(e);
        alert("Failed to delete.");
    }
};

window.importFromLibrary = async (id) => {
    const list = room.collection('country_library_v1').getList();
    const countryData = list.find(c => c.id === id);
    if (!countryData) return;

    loadingStatus.innerText = `Importing ${countryData.name}...`;
    loadingOverlay.style.display = 'flex';
    scenarioHubModal.style.display = 'none';

    // Allow UI to update
    await new Promise(r => setTimeout(r, 100));

    try {
        const newId = countryMetadata.length + 1;
        const newMeta = {
            id: newId,
            name: countryData.name,
            color: countryData.color,
            rgba: parseColorToRGBA(countryData.color),
            isCustom: true,
            flagUrl: countryData.flagUrl
        };
        countryMetadata.push(newMeta);

        // Fetch cells from URL if they aren't in the record (new format to avoid 250KB limit)
        let cells = countryData.cells;
        if (!cells && countryData.cellsUrl) {
            try {
                const resp = await fetch(countryData.cellsUrl);
                cells = await resp.json();
            } catch (e) {
                console.error("Failed to fetch country cells", e);
                alert("Error importing country geography.");
                loadingOverlay.style.display = 'none';
                return;
            }
        }

        if (!cells) {
            alert("This country has no geography data.");
            loadingOverlay.style.display = 'none';
            return;
        }

        // Map relative cells to current grid
        const sourceRes = countryData.gridRes || CONFIG.GRID_RES;
        const targetRes = CONFIG.GRID_RES;
        
        cells.forEach(([cx, cy]) => {
            // Robust conversion: Fill all target cells that overlap with the source cell
            const baseLat = (cy * sourceRes) - 90;
            const baseLng = (cx * sourceRes) - 180;
            
            const xStart = Math.floor((baseLng + 180) / targetRes);
            const xEnd = Math.floor((baseLng + sourceRes + 180 - 0.0001) / targetRes);
            const yStart = Math.floor((baseLat + 90) / targetRes);
            const yEnd = Math.floor((baseLat + sourceRes + 90 - 0.0001) / targetRes);
            
            for (let ty = yStart; ty <= yEnd; ty++) {
                if (ty < 0 || ty >= gridHeight) continue;
                const rowOffset = ty * gridWidth;
                for (let tx = xStart; tx <= xEnd; tx++) {
                    if (tx < 0 || tx >= gridWidth) continue;
                    const tIdx = rowOffset + tx;
                    worldControlMap[tIdx] = newId;
                    if (landMask[tIdx] === 0) landMask[tIdx] = 1;
                }
            }
        });

        recalculateAllBounds();
        loadingOverlay.style.display = 'none';
        influenceLayer.render();
        alert(`${countryData.name} imported successfully!`);
    } catch (e) {
        console.error(e);
        alert("Import failed.");
        loadingOverlay.style.display = 'none';
    }
};

window.playFromHub = async (url, id, name, ownerUsername) => {
    initAudio();
    loadingStatus.innerText = "Downloading Scenario...";
    loadingOverlay.style.display = 'flex';
    scenarioHubModal.style.display = 'none';
    
    const currentUser = await window.websim.getCurrentUser();
    const myUsername = currentUser.username;

    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch");
        const blob = await response.blob();
        
        currentScenarioContext = { id, name, ownerUsername, blobUrl: url };
        activeScenarioId = (ownerUsername === myUsername) ? id : null;
        
        await performPresetLoad(blob, 'CONQUEST');
        
        if (activeScenarioId) {
            editorUpdateBtn.style.display = 'block';
        } else {
            editorUpdateBtn.style.display = 'none';
        }
    } catch (e) {
        console.error(e);
        alert("Failed to download scenario.");
        loadingOverlay.style.display = 'none';
    }
};

window.remixFromHub = async (url, sourceId, sourceName, ownerUsername) => {
    initAudio();
    loadingStatus.innerText = "Downloading for Remix...";
    loadingOverlay.style.display = 'flex';
    scenarioHubModal.style.display = 'none';
    
    const currentUser = await window.websim.getCurrentUser();
    const myUsername = currentUser.username;

    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch");
        const blob = await response.blob();
        await performPresetLoad(blob, 'EDITOR');
        
        currentScenarioContext = { id: sourceId, name: sourceName, ownerUsername, blobUrl: url };
        statusText.innerText = `REMIXING: ${sourceName}`;
        
        // If we remix our OWN work, allow updating it
        activeScenarioId = (ownerUsername === myUsername) ? sourceId : null;
        if (activeScenarioId) {
            editorUpdateBtn.style.display = 'block';
        } else {
            editorUpdateBtn.style.display = 'none';
        }
    } catch (e) {
        console.error(e);
        alert("Failed to download scenario for remix.");
        loadingOverlay.style.display = 'none';
    }
};

// Initialization logic
function initializeEngine() {
    const gridRes = parseFloat(document.getElementById('grid-res-select').value);
    const unitLimit = parseInt(document.getElementById('unit-limit-select').value);
    
    // Sync global toggles from both main settings and setup panel sources
    const mtDisabled = document.getElementById('disable-mountains-checkbox').checked || document.getElementById('setup-disable-mountains-checkbox').checked;
    mountainsEnabled = !mtDisabled;

    const provDisabled = document.getElementById('disable-provinces-checkbox').checked || document.getElementById('setup-disable-provinces-checkbox').checked;
    provincesEnabled = !provDisabled;

    showUnitsVisually = !document.getElementById('disable-units-visually-checkbox').checked;
    disableCountryGradient = !!document.getElementById('disable-country-gradient-checkbox')?.checked;

    // Check if configuration changed enough to require re-allocation
    if (CONFIG.GRID_RES !== gridRes || !worldControlMap) {
        CONFIG.GRID_RES = gridRes;
        CONFIG.MAX_UNITS_PER_SIDE = unitLimit;
        
        // Allocate Grid
        gridWidth = Math.ceil(360 / CONFIG.GRID_RES);
        gridHeight = Math.ceil(180 / CONFIG.GRID_RES);
        worldControlMap = new Int32Array(gridWidth * gridHeight);
        deJureMap = new Int32Array(gridWidth * gridHeight);
        provinceMap = new Int32Array(gridWidth * gridHeight);
        occupationMap = new Float32Array(gridWidth * gridHeight);
        primaryOccupierMap = new Int32Array(gridWidth * gridHeight);
        landMask = new Uint8Array(gridWidth * gridHeight);
        biomeMask = new Uint8Array(gridWidth * gridHeight);
        terrainMask = new Float32Array(gridWidth * gridHeight);
        flagProcessedBuffer = new Int32Array(gridWidth * gridHeight);
        flagOwnerBuffer = new Int32Array(gridWidth * gridHeight);
        flagSovereignBuffer = new Int32Array(gridWidth * gridHeight);
        sovereignProcessedBuffer = new Uint8Array(gridWidth * gridHeight);
        
        // If we are already in a mode that has geography loaded, we should refresh it
        if (rawGeoJsonData) {
            const isBlank = gameMode === 'EDITOR';
            updateLandMask(rawGeoJsonData.features, 1, isBlank);
        }
    } else {
        CONFIG.MAX_UNITS_PER_SIDE = unitLimit;
    }
}

musicVolumeSlider.addEventListener('input', (e) => {
    const vol = parseFloat(e.target.value);
    musicVolVal.innerText = Math.round(vol * 100) + '%';
    if (bgMusicGain && !isMuted) {
        bgMusicGain.gain.setTargetAtTime(vol, audioCtx.currentTime, 0.05);
    }
    setCookie('mw_music_vol', vol);
});

muteBtn.addEventListener('click', () => {
    isMuted = !isMuted;
    muteBtn.innerText = isMuted ? '🔇' : '🔊';
    
    if (!audioCtx) return;

    if (isMuted) {
        if (bgMusicGain) bgMusicGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.1);
        if (warAmbianceGain) warAmbianceGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.1);
    } else {
        const savedVol = getCookie('mw_music_vol');
        const musicVol = savedVol !== '' ? parseFloat(savedVol) : 0.15;
        if (bgMusicGain) bgMusicGain.gain.setTargetAtTime(musicVol, audioCtx.currentTime, 0.1);
        if (warAmbianceGain && gameState === 'SIMULATING') {
            warAmbianceGain.gain.setTargetAtTime(0.05, audioCtx.currentTime, 0.1);
        }
    }
});

presetLowBtn.addEventListener('click', () => {
    mapResSelect.value = '110m';
    gridResSelect.value = '0.15';
    unitLimitSelect.value = '100';
    
    // Switch to Simplified mode without gradients for low performance
    setImageryProvider('wargames');
    if (disableCountryGradientCheckbox) {
        disableCountryGradientCheckbox.checked = true;
        disableCountryGradient = true;
    }
    
    document.getElementById('disable-mountains-checkbox').checked = true;
    setupDisableMountainsCheckbox.checked = true;
    mountainsEnabled = false;
    
    // Visual feedback
    presetLowBtn.style.boxShadow = "0 0 15px rgba(192, 57, 43, 0.5)";
    presetDefaultBtn.style.boxShadow = "none";
});

presetDefaultBtn.addEventListener('click', () => {
    mapResSelect.value = '110m';
    gridResSelect.value = '0.1';
    unitLimitSelect.value = '250';
    
    // Reset to Google Earth with gradients for default
    setImageryProvider('google');
    if (disableCountryGradientCheckbox) {
        disableCountryGradientCheckbox.checked = false;
        disableCountryGradient = false;
    }
    
    document.getElementById('disable-mountains-checkbox').checked = false;
    setupDisableMountainsCheckbox.checked = false;
    mountainsEnabled = true;
    
    // Visual feedback
    presetDefaultBtn.style.boxShadow = "0 0 15px rgba(46, 134, 222, 0.5)";
    presetLowBtn.style.boxShadow = "none";
});

launchBtn.addEventListener('click', () => {
    initAudio();
    initMultiplayer();
    initializeEngine();

    if (saveSkipCheckbox.checked) {
        setCookie('mw_skip_settings', 'true');
        setCookie('mw_map_res', mapResSelect.value);
        setCookie('mw_grid_res', gridResSelect.value);
        setCookie('mw_unit_limit', unitLimitSelect.value);
        setCookie('mw_disable_mountains', document.getElementById('disable-mountains-checkbox').checked ? 'true' : 'false');
        setCookie('mw_disable_provinces', document.getElementById('disable-provinces-checkbox').checked ? 'true' : 'false');
        setCookie('mw_disable_units_visually', document.getElementById('disable-units-visually-checkbox').checked ? 'true' : 'false');
        setCookie('mw_disable_country_gradient', disableCountryGradientCheckbox.checked ? 'true' : 'false');
    } else {
        setCookie('mw_skip_settings', 'false');
    }

    settingsOverlay.style.display = 'none';
    if (gameState === 'MAIN_MENU') {
        mainMenu.style.display = 'flex';
    } else {
        mapUi.style.display = 'flex';
        if (currentScenarioContext && gameMode === 'EDITOR') {
            statusText.innerText = `REMIXING: ${currentScenarioContext.name}`;
        } else if (currentScenarioContext && gameMode === 'CONQUEST') {
            statusText.innerText = `PLAYING: ${currentScenarioContext.name}`;
        }
    }
    launchBtn.innerText = "Apply Changes"; // Change for subsequent opens
});

// Auto-load settings on boot
function checkAutoLaunch() {
    if (getCookie('mw_skip_settings') === 'true') {
        mapResSelect.value = getCookie('mw_map_res') || '50m';
        gridResSelect.value = getCookie('mw_grid_res') || '0.15';
        unitLimitSelect.value = getCookie('mw_unit_limit') || '500';
        const mtSaved = getCookie('mw_disable_mountains');
        if (mtSaved === 'true') {
            document.getElementById('disable-mountains-checkbox').checked = true;
            setupDisableMountainsCheckbox.checked = true;
            mountainsEnabled = false;
        } else {
            document.getElementById('disable-mountains-checkbox').checked = false;
            setupDisableMountainsCheckbox.checked = false;
            mountainsEnabled = true;
        }

        const provSaved = getCookie('mw_disable_provinces');
        if (provSaved === 'false') {
            mainDisableProvincesCheckbox.checked = false;
            setupDisableProvincesCheckbox.checked = false;
            provincesEnabled = true;
        } else {
            // Default to disabled (checked) if 'true' or not yet set
            mainDisableProvincesCheckbox.checked = true;
            setupDisableProvincesCheckbox.checked = true;
            provincesEnabled = false;
        }

        const unitsVisSaved = getCookie('mw_disable_units_visually');
        if (unitsVisSaved === 'true') {
            document.getElementById('disable-units-visually-checkbox').checked = true;
            showUnitsVisually = false;
        } else {
            document.getElementById('disable-units-visually-checkbox').checked = false;
            showUnitsVisually = true;
        }

        const gradSaved = getCookie('mw_disable_country_gradient');
        if (gradSaved === 'true') {
            disableCountryGradientCheckbox.checked = true;
            disableCountryGradient = true;
        } else {
            disableCountryGradientCheckbox.checked = false;
            disableCountryGradient = false;
        }

        saveSkipCheckbox.checked = true;

        initMultiplayer();
        initializeEngine();
        
        settingsOverlay.style.display = 'none';
        mainMenu.style.display = 'flex';
        gameState = 'MAIN_MENU';
        launchBtn.innerText = "Apply Changes";
        // Ensure background music is running as soon as the main menu is shown
        initAudio();

        if (getCookie('mw_tutorial_finished') !== 'true') {
            startTutorial(conquestTutorialSteps, 'mw_tutorial_finished');
        }
    }
}

// Settings Tab Logic
document.querySelectorAll('.settings-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        // Buttons UI
        document.querySelectorAll('.settings-tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        // Panes UI
        document.querySelectorAll('.settings-tab-pane').forEach(pane => pane.style.display = 'none');
        const target = document.getElementById(`settings-tab-${tab}`);
        if (target) target.style.display = 'block';
    });
});

if (disableCountryGradientCheckbox) {
    disableCountryGradientCheckbox.addEventListener('change', (e) => {
        disableCountryGradient = e.target.checked;
        influenceLayer.render();
    });
}

checkAutoLaunch();
// Initial language application must happen after all DOM is ready and checkAutoLaunch is done
applyLanguage('zh');
showSupportModalIfNeeded();
updateRestartVisibility();

// Initialize editor tools page if toolbox exists
if (editorToolbox) {
    updateEditorToolPage(1);
}

mainSettingsBtn.addEventListener('click', () => {
    settingsOverlay.style.display = 'flex';
    mainMenu.style.display = 'none';
});

ingameSettingsBtn.addEventListener('click', () => {
    settingsOverlay.style.display = 'flex';
    mapUi.style.display = 'none';
});

playModeBtn.addEventListener('click', () => {
    conquestChoiceModal.style.display = 'flex';
});

if (eraModernTabBtn && eraWarsTabBtn && eraHistoryTabBtn && eraStatesTabBtn) {
    const eraTabs = [eraModernTabBtn, eraWarsTabBtn, eraHistoryTabBtn, eraStatesTabBtn];
    const eraPages = [eraPageModern, eraPageWars, eraPageHistory, eraPageStates];

    const switchEraPage = (targetIndex) => {
        eraPages.forEach((page, i) => {
            if (page) page.style.display = (i === targetIndex) ? 'block' : 'none';
        });
        eraTabs.forEach((tab, i) => {
            if (tab) {
                if (i === targetIndex) tab.classList.add('active');
                else tab.classList.remove('active');
            }
        });
    };

    eraModernTabBtn.onclick = () => switchEraPage(0);
    eraWarsTabBtn.onclick = () => switchEraPage(1);
    eraHistoryTabBtn.onclick = () => switchEraPage(2);
    eraStatesTabBtn.onclick = () => switchEraPage(3);
}

choiceModernDay.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading Modern World Theater...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = 'world map 2022.json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch modern map");
        const blob = await response.blob();
        
        currentScenarioContext = { id: 'world_map_2022', name: 'Modern Day', ownerUsername: 'System', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        // Fallback to old method if preset fails
        gameMode = 'CONQUEST';
        gameState = 'SELECTING_P1';
        const mapRes = document.getElementById('map-res-select').value;
        const geoUrl = `${CONFIG.GEOJSON_BASE}${mapRes}/cultural/ne_${mapRes}_admin_0_countries.json`;
        mainMenu.style.display = 'none';
        loadCountries(geoUrl, false);
    }
};

choice1936Scenario.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading 1936 Theater...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = 'ww2_releasables_fixed_preset.json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch 1936 map");
        const blob = await response.blob();
        
        currentScenarioContext = { id: 'ww2_1936', name: '1936 Scenario', ownerUsername: 'System', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        alert("Failed to load 1936 scenario.");
        loadingOverlay.style.display = 'none';
    }
};

choice1942Scenario.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading 1942 Theater...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = '1942.json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch 1942 map");
        const blob = await response.blob();
        
        currentScenarioContext = { id: 'ww2_1942', name: '1942 Scenario', ownerUsername: 'orange', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        alert("Failed to load 1942 scenario.");
        loadingOverlay.style.display = 'none';
    }
};

choiceWW1Scenario.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading 1914 Theater...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = 'world_war_1__1914_.json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch 1914 map");
        const blob = await response.blob();
        
        currentScenarioContext = { id: 'ww1_1914', name: '1914 Scenario', ownerUsername: 'System', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        alert("Failed to load 1914 scenario.");
        loadingOverlay.style.display = 'none';
    }
};

choice1804Scenario.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading 1804 Napoleonic Theater...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = '1804_map.json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch 1804 map");
        const blob = await response.blob();
        
        currentScenarioContext = { id: 'napoleonic_1804', name: '1804 Napoleonic Wars', ownerUsername: 'orange', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        alert("Failed to load 1804 Napoleonic scenario.");
        loadingOverlay.style.display = 'none';
    }
};

choice1492Scenario.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading 1492 Renaissance Theater...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = '1492_map (2).json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch 1492 map");
        const blob = await response.blob();
        
        currentScenarioContext = { id: 'renaissance_1492', name: '1492 Scenario', ownerUsername: 'orange', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        alert("Failed to load 1492 scenario.");
        loadingOverlay.style.display = 'none';
    }
};

choice1ADScenario.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading 1 AD Classical Theater...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = '1ad.json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch 1 AD map");
        const blob = await response.blob();
        
        currentScenarioContext = { id: '1_ad', name: '1 AD Scenario', ownerUsername: 'System', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        alert("Failed to load 1 AD scenario.");
        loadingOverlay.style.display = 'none';
    }
};

choiceUSStates.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading US States Scenario...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = 'my_custom_preset (7).json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch US States scenario");
        const blob = await response.blob();
        
        currentScenarioContext = { id: 'us_states_scenario', name: 'US States Scenario', ownerUsername: 'System', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        alert("Failed to load US States scenario.");
        loadingOverlay.style.display = 'none';
    }
};

choiceCanadaStates.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading Canada Provinces Scenario...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = 'canada_states (1).json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch Canada Provinces scenario");
        const blob = await response.blob();
        
        currentScenarioContext = { id: 'canada_states_scenario', name: 'Canada Provinces Scenario', ownerUsername: 'System', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        alert("Failed to load Canada Provinces scenario.");
        loadingOverlay.style.display = 'none';
    }
};

choice1948Scenario.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading 1948 Early Cold War Theater...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = '1948 (1).json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch 1948 scenario");
        const blob = await response.blob();
        
        currentScenarioContext = { id: 'early_cold_war_1948', name: '1948 Scenario', ownerUsername: 'orange', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        alert("Failed to load 1948 scenario.");
        loadingOverlay.style.display = 'none';
    }
};

choice1974Scenario.onclick = async () => {
    conquestChoiceModal.style.display = 'none';
    initAudio();
    loadingStatus.innerText = "Loading 1974 Cold War Theater...";
    loadingOverlay.style.display = 'flex';
    
    try {
        const url = 'better_cold_war_preset.json';
        const response = await fetch(url);
        if (!response.ok) throw new Error("Failed to fetch 1974 scenario");
        const blob = await response.blob();
        
        currentScenarioContext = { id: 'cold_war_1974', name: '1974 Scenario', ownerUsername: 'orange', blobUrl: url };
        activeScenarioId = null;
        
        await performPresetLoad(blob, 'CONQUEST');
        mainMenu.style.display = 'none';
    } catch (e) {
        console.error(e);
        alert("Failed to load 1974 scenario.");
        loadingOverlay.style.display = 'none';
    }
};

cancelConquestChoice.onclick = () => {
    conquestChoiceModal.style.display = 'none';
};

/**
 * EDITOR LOGIC
 */
function openReleaseModal(releaserId, sideIdx) {
    const releasables = countryMetadata.filter(m => m && m.releasableBy === releaserId);
    if (releasables.length === 0) return;

    releasableListContainer.innerHTML = releasables.map(m => `
        <button class="menu-card" style="padding: 10px; width: 100%; text-align: left;" onclick="window.releaseNation(${m.id}, ${releaserId}, ${sideIdx})">
            <img src="${m.flagUrl || ''}" style="width: 30px; height: 18px; object-fit: cover; border: 1px solid #444; margin-right: 10px;">
            <div class="card-body">
                <span class="btn-text" style="font-size: 12px;">${m.name}</span>
            </div>
        </button>
    `).join('');

    releaseModal.style.display = 'flex';
}

closeReleaseModalBtn.onclick = () => {
    releaseModal.style.display = 'none';
};

window.releaseNation = async (nationId, releaserId, sideIdx) => {
    const meta = countryMetadata.find(m => m && m.id === nationId);
    if (!meta) return;

    // Remove releasable status
    meta.releasableBy = null;
    
    const isWar = (gameState === 'SIMULATING');
    const poleIdx = sideIdx !== -1 ? sideIdx % 2 : -1;
    const targetOcc = (poleIdx === 0) ? 1.0 : (poleIdx === 1 ? -1.0 : 0);

    loadingStatus.innerText = `RESTORING NATION: ${meta.name}...`;
    loadingOverlay.style.display = 'flex';
    await new Promise(r => setTimeout(r, 50));
    
    // Strategy: Import data from GeoJSON feature if available, 
    // otherwise use saved cells snapshot, otherwise fallback to deJureMap.
    
    let territoryRestored = false;

    // 1. Try GeoJSON Rasterization (Most accurate for modern nations)
    if (meta.feature) {
        const bounds = L.geoJSON(meta.feature).getBounds();
        const res = CONFIG.GRID_RES;
        const sLat = Math.max(0, Math.floor((bounds.getSouth() + 90) / res));
        const eLat = Math.min(gridHeight - 1, Math.ceil((bounds.getNorth() + 90) / res));
        const sLng = Math.max(0, Math.floor((bounds.getWest() + 180) / res));
        const eLng = Math.min(gridWidth - 1, Math.ceil((bounds.getEast() + 180) / res));

        for (let y = sLat; y <= eLat; y++) {
            for (let x = sLng; x <= eLng; x++) {
                const lat = (y * res) - 90 + (res * 0.5);
                const lng = (x * res) - 180 + (res * 0.5);
                if (isPointInFeature(lat, lng, meta.feature)) {
                    const idx = y * gridWidth + x;
                    // Strict Release Constraint: Releasables only reclaim cells that are both 
                    // currently held by the releaser AND part of the host's core territory.
                    if (worldControlMap[idx] === releaserId && (deJureMap[idx] === releaserId || deJureMap[idx] === nationId)) {
                        worldControlMap[idx] = nationId;
                        deJureMap[idx] = nationId;
                        provinceMap[idx] = getProvinceId(x, y, nationId);
                        if (isWar && sideIdx !== -1) {
                            landMask[idx] = 2;
                            occupationMap[idx] = targetOcc;
                            primaryOccupierMap[idx] = nationId;
                        } else {
                            landMask[idx] = 1;
                            occupationMap[idx] = 0;
                            primaryOccupierMap[idx] = 0;
                        }
                        territoryRestored = true;
                    }
                }
            }
        }
    }

    // 2. Try Saved Cells (For custom nations that were set as releasable)
    if (!territoryRestored && meta.savedCells) {
        meta.savedCells.forEach(([x, y]) => {
            const idx = y * gridWidth + x;
            if (idx >= 0 && idx < worldControlMap.length) {
                // Restore any of the host's land that was originally saved for this releasable
                if (worldControlMap[idx] === releaserId) {
                    worldControlMap[idx] = nationId;
                    provinceMap[idx] = getProvinceId(x, y, nationId);
                    if (isWar && sideIdx !== -1) {
                        landMask[idx] = 2;
                        occupationMap[idx] = targetOcc;
                        primaryOccupierMap[idx] = nationId;
                    } else {
                        landMask[idx] = 1;
                        occupationMap[idx] = 0;
                        primaryOccupierMap[idx] = 0;
                    }
                    territoryRestored = true;
                }
            }
        });
    }

    // 3. Fallback to deJureMap
    if (!territoryRestored) {
        for (let i = 0; i < worldControlMap.length; i++) {
            if (deJureMap[i] === nationId) {
                if (worldControlMap[i] === releaserId) {
                    worldControlMap[i] = nationId;
                    provinceMap[i] = getProvinceId(i % gridWidth, Math.floor(i / gridWidth), nationId);
                    if (isWar && sideIdx !== -1) {
                        landMask[i] = 2;
                        occupationMap[i] = targetOcc;
                        primaryOccupierMap[i] = nationId;
                    } else {
                        landMask[i] = 1;
                        occupationMap[i] = 0;
                        primaryOccupierMap[i] = 0;
                    }
                }
            }
        }
    }

    // If in conflict setup or mid-war, deploy the nation
    const newCountry = {
        id: nationId,
        name: meta.name,
        color: meta.color,
        role: 'OFFENSE',
        strategy: 'BALANCED',
        buffState: 'none',
        overlordId: meta.overlordId || null,
        flag: meta.tempFlag || null
    };

    // Ensure the flag is properly initialized if not already
    if (!newCountry.flag && meta.flagUrl) {
        newCountry.flag = new Image();
        newCountry.flag.crossOrigin = "anonymous";
        newCountry.flag.src = meta.flagUrl;
        meta.tempFlag = newCountry.flag;
    }

    if (sideIdx !== -1) {
        if (gameState === 'SIMULATING') {
            activateCountryMidWar(newCountry, sideIdx);
        } else {
            if (!sides[sideIdx]) sides[sideIdx] = [];
            sides[sideIdx].push(newCountry);
        }
    }

    loadingOverlay.style.display = 'none';
    releaseModal.style.display = 'none';
    recalculateAllBounds();
    updateSidesUI();
    influenceLayer.render();
    statusText.innerText = `${meta.name} has been released!`;
};

function setAsReleasable(releasableId, releaserId) {
    const rMeta = countryMetadata.find(m => m && m.id === releasableId);
    const hostMeta = countryMetadata.find(m => m && m.id === releaserId);
    if (!rMeta || !hostMeta) return;

    rMeta.releasableBy = releaserId;
    
    // Capture territory snapshot for future restoration.
    // IMPORTANT: Only touch cells that are currently owned by the releasable.
    // This makes it visually look like the host fully annexed the releasable,
    // and we restore exactly these cells on release.
    const cells = [];
    for (let i = 0; i < worldControlMap.length; i++) {
        if (worldControlMap[i] === releasableId) {
            const y = Math.floor(i / gridWidth);
            const x = i % gridWidth;
            cells.push([x, y]);
            // Hand this land to the host nation for now so it looks annexed
            worldControlMap[i] = releaserId;
        }
    }
    rMeta.savedCells = cells;

    // Remove from active sides
    sides.forEach(side => {
        const idx = side.findIndex(c => c.id === releasableId);
        if (idx > -1) side.splice(idx, 1);
    });

    statusText.innerText = `${rMeta.name} is now a releasable of ${hostMeta.name}`;
    countryInspector.style.display = 'none';
    recalculateAllBounds();
    updateSidesUI();
    influenceLayer.render();
}

function setVassalage(vassalId, overlordId) {
    const vassalMeta = countryMetadata.find(m => m && m.id === vassalId);
    if (!vassalMeta) return;

    // Preserve the original flag the first time this country becomes a puppet
    if (!vassalMeta.baseFlagUrl) {
        vassalMeta.baseFlagUrl = vassalMeta.flagUrl || null;
    }

    vassalMeta.overlordId = overlordId;
    
    // Propagate to sides if active
    sides.flat().filter(Boolean).forEach(c => {
        if (c.id === vassalId) c.overlordId = overlordId;
    });

    const overlordMeta = countryMetadata.find(m => m && m.id === overlordId);
    statusText.innerText = `${vassalMeta.name} is now a vassal of ${overlordMeta ? overlordMeta.name : 'Unknown'}`;

    // Generate a dynamic half-and-half puppet flag for vassals created after game start
    // (existing historical puppets keep their original flags unless re-vassalized through this function).
    generatePuppetFlag(vassalId, overlordId);

    openInspector(vassalId);
    influenceLayer.render();
}

function recruitNeutralMidWar(id, sideIdx) {
    // 1. Remove from existing side if present (handle mid-war switching)
    let oldSideIdx = -1;
    sides.forEach((side, sIdx) => {
        const idx = side.findIndex(c => c.id === id);
        if (idx > -1) {
            oldSideIdx = sIdx;
            side.splice(idx, 1);
        }
    });

    const meta = countryMetadata.find(m => m && m.id === id);
    if (!meta) return;
    
    const newCountry = {
        id: id,
        name: meta.name,
        color: meta.color,
        role: 'OFFENSE',
        strategy: 'BALANCED',
        buffState: meta.buffState || 'none',
        overlordId: meta.overlordId || null
    };
    
    if (!sides[sideIdx]) sides[sideIdx] = [];
    sides[sideIdx].push(newCountry);
    activateCountryMidWar(newCountry, sideIdx);
    
    updateSidesUI();
    influenceLayer.render();
    
    const sideLabel = String.fromCharCode(65 + sideIdx);
    if (oldSideIdx !== -1) {
        statusText.innerText = `${newCountry.name} HAS SWITCHED TO SIDE ${sideLabel}`;
    } else {
        statusText.innerText = `${newCountry.name} HAS DEPLOYED TO SIDE ${sideLabel}`;
    }
    
    // Play sound if possible
    playWarStartSound();
}

function openInspector(id) {
    editingCountryId = id;
    const meta = countryMetadata.find(m => m && m.id === id);
    if (!meta) return;

    const isWar = gameState === 'SIMULATING';
    const isNeutral = !sides.flat().some(c => c.id === id);

    // Toggle editor-only fields, but keep the Combat Buff section visible even in war
    const buffSection = document.getElementById('buff-editor-section');
    document.querySelectorAll('#country-inspector .editor-only').forEach(el => {
        if (el === buffSection) return; // handle buff separately
        el.style.display = isWar ? 'none' : 'block';
    });
    if (buffSection) {
        buffSection.style.display = 'block';
    }

    const vassalStatusDisplay = document.getElementById('vassal-status-display');
    if (vassalStatusDisplay) {
        if (meta.overlordId) {
            vassalStatusDisplay.style.display = 'block';
            const oMeta = countryMetadata.find(m => m && m.id === meta.overlordId);
            document.getElementById('overlord-name-disp').innerText = oMeta ? oMeta.name : "Unknown";
        } else {
            vassalStatusDisplay.style.display = 'none';
        }
    }

    const recruitmentDiv = document.getElementById('mid-war-recruitment');
    const vassalizeBtn = document.getElementById('vassalize-btn');
    const exitConflictBtn = document.getElementById('exit-conflict-btn');
    if (recruitmentDiv) {
        if (isWar) {
            const currentSideIdx = sides.findIndex(s => s.some(c => c.id === id));
            recruitmentDiv.style.display = 'block';

            if (exitConflictBtn) {
                if (currentSideIdx !== -1) {
                    exitConflictBtn.style.display = 'block';
                    exitConflictBtn.onclick = () => {
                        const country = sides[currentSideIdx].find(c => c.id === id);
                        if (country) {
                            unilateralExitConflict(country, currentSideIdx);
                            countryInspector.style.display = 'none';
                        }
                    };
                } else {
                    exitConflictBtn.style.display = 'none';
                }
            }
            const btnContainer = document.getElementById('recruit-sides-btns');
            btnContainer.innerHTML = '';
            
            sides.forEach((side, idx) => {
                const isCurrentSide = currentSideIdx === idx;
                const btn = document.createElement('button');
                btn.className = 'mini-btn';
                const sideLabel = String.fromCharCode(65 + idx);
                btn.innerText = isCurrentSide ? `ON SIDE ${sideLabel}` : `JOIN SIDE ${sideLabel}`;
                btn.style.background = idx % 2 === 0 ? '#ff4757' : '#2e86de';
                btn.style.padding = '8px 12px';
                btn.style.fontSize = '10px';
                btn.style.fontWeight = '900';
                btn.style.opacity = isCurrentSide ? '0.4' : '1';
                btn.disabled = isCurrentSide;
                
                if (!isCurrentSide) {
                    btn.onclick = () => {
                        recruitNeutralMidWar(id, idx);
                        countryInspector.style.display = 'none';
                    };
                }
                btnContainer.appendChild(btn);
            });
            
            // Vassalization Logic: Check if target can be vassalized
            // Requires enough territory taken by a side
            vassalizeBtn.style.display = 'none';
            const stats = latestCountryStats.get(id);
            if (stats) {
                const initial = meta.initialCells || stats.controlled + 100; // fallback if war just started
                const controlPct = (stats.controlled / initial);
                
                // If more than 50% territory taken, show vassalize button for the leading side
                if (controlPct < 0.5) {
                    vassalizeBtn.style.display = 'block';
                    vassalizeBtn.onclick = () => {
                        // Find the side that occupies the most of this country
                        let bestSideIdx = 0;
                        let maxOcc = 0;
                        const sideOccs = new Array(sides.length).fill(0);
                        
                        // Sample grid to find dominant occupier
                        for(let i=0; i<worldControlMap.length; i += 50) {
                            if (worldControlMap[i] === id && landMask[i] === 2) {
                                const occId = primaryOccupierMap[i];
                                const sIdx = sides.findIndex(s => s.some(c => c.id === occId));
                                if (sIdx !== -1) sideOccs[sIdx]++;
                            }
                        }
                        bestSideIdx = sideOccs.indexOf(Math.max(...sideOccs));
                        const overlord = sides[bestSideIdx][0];
                        if (overlord) {
                            meta.overlordId = overlord.id;
                            recruitNeutralMidWar(id, bestSideIdx);
                            countryInspector.style.display = 'none';
                        }
                    };
                }
            }
        } else {
            recruitmentDiv.style.display = 'none';
        }
    }

    const releasables = countryMetadata.filter(m => m && m.releasableBy === id);
    const releaseContainer = document.getElementById('inspector-release-container');
    const releaseBtn = document.getElementById('inspect-release-btn');
    if (releaseContainer && releaseBtn) {
        if (releasables.length > 0) {
            releaseContainer.style.display = 'block';
            releaseBtn.onclick = () => {
                const currentSideIdx = sides.findIndex(s => s.some(c => c.id === id));
                openReleaseModal(id, currentSideIdx);
            };
        } else {
            releaseContainer.style.display = 'none';
        }
    }

    const inspectorDisplayName = getTranslation(meta.name || meta.feature?.properties?.NAME || "Unnamed Land", getCookie('mw_lang') || 'en', 'NATIONS');
    inspectNameInput.value = inspectorDisplayName;
    inspectNameInput.disabled = isWar;
    inspectColorSwatch.style.backgroundColor = meta.color;
    
    // Initialize Buff button state for this country
    if (inspectBuffBtn) {
        const currentBuff = meta.buffState || 'none';
        const bMeta = BUFF_METADATA[currentBuff] || BUFF_METADATA['none'];
        inspectBuffBtn.innerHTML = `
            <span class="buff-arrow" data-dir="-1" style="font-size:11px; margin-right:4px;">◀</span>
            <span class="buff-label">BUFF: ${bMeta.label}</span>
            <span class="buff-arrow" data-dir="1" style="font-size:11px; margin-left:4px;">▶</span>
        `;
        inspectBuffBtn.style.background = bMeta.color;
        inspectBuffBtn.style.color = bMeta.textColor;
    }
    
    // Reset file input and update flag preview
    inspectFlagInput.value = '';
    if (meta.flagUrl) {
        inspectFlagPreview.src = meta.flagUrl;
        inspectFlagPreview.style.display = 'block';
    } else {
        inspectFlagPreview.style.display = 'none';
    }
    
    // Convert current color to Hex for the picker
    const rgba = meta.rgba;
    const toHex = (n) => n.toString(16).padStart(2, '0');
    const hex = `#${toHex(rgba[0])}${toHex(rgba[1])}${toHex(rgba[2])}`;
    inspectColorPicker.value = hex;

    countryInspector.style.display = 'block';
    influenceLayer.render();
}



function placeDivisionAt(latlng, sovereignId) {
    let sideIdx = sides.findIndex(s => s.some(c => c.id === sovereignId));
    let team = 'A';
    
    // If country not in a side, we need to assign it to one or create one if simulating
    if (sideIdx === -1) {
        if (gameState === 'SIMULATING' || godModeActive) {
            // Assign to first available side or default side A polarity
            sideIdx = 0;
            recruitNeutralMidWar(sovereignId, sideIdx);
        } else {
            statusText.innerText = "Nation must be assigned to a side to place units.";
            return;
        }
    }
    
    team = sideIdx % 2 === 0 ? 'A' : 'B';
    const idx = getGridIndex(latlng.lat, latlng.lng);
    const isMountainCell = idx !== -1 && terrainMask && terrainMask[idx] > 0.35;
    const isAlpen = isMountainCell && Math.random() < 0.4;

    units.push({
        id: Math.random(),
        lat: latlng.lat,
        lng: latlng.lng,
        team,
        sideIndex: sideIdx,
        sovereignId: sovereignId,
        beneficiaryId: sovereignId,
        isAlpenjager: !!isAlpen,
        health: CONFIG.UNIT_HEALTH * (isAlpen ? CONFIG.ALPEN_HEALTH_MULT : 1),
        lastAttack: 0,
        deployTicks: 10 // Quick deploy for manual placement
    });

    if (team === 'A') teamASoldiers += soldiersPerUnitA;
    else teamBSoldiers += soldiersPerUnitB;

    statusText.innerText = `MANUAL DEPLOYMENT: Division placed for ${countryMetadata[sovereignId-1]?.name || 'Nation'}`;
    influenceLayer.render();
}

async function placeNewCountry(latlng) {
    // Do not place new countries outside the world-size box
    if (!isInsideWorldBoxLatLng(latlng.lat, latlng.lng)) return;
    const idx = getGridIndex(latlng.lat, latlng.lng);
    if (idx === -1) return;

    const y = Math.floor(idx / gridWidth);
    const x = idx % gridWidth;

    const maxId = countryMetadata.reduce((max, m) => m ? Math.max(max, m.id) : max, 0);
    const id = maxId + 1;
    const newMeta = {
        id: id,
        name: customCountryData.name,
        color: customCountryData.color,
        rgba: parseColorToRGBA(customCountryData.color),
        isCustom: true,
        flagUrl: customCountryData.flagUrl,
        bounds: { minX: x, maxX: x, minY: y, maxY: y }
    };
    
    // Ensure the array has enough space if there were gaps
    if (id > countryMetadata.length) {
        countryMetadata.push(newMeta);
    } else {
        countryMetadata[id - 1] = newMeta;
    }
    
    // Assign initial point
    worldControlMap[idx] = id;
    deJureMap[idx] = id;
    provinceMap[idx] = getProvinceId(x, y, id);
    // Mandatory land conversion at capital point
    landMask[idx] = 1;
    
    gameState = 'EDITOR_ACTIVE';
    statusText.innerText = `Nation Established: ${newMeta.name}`;
    map.getContainer().classList.remove('painting-cursor');
    
    recalculateAllBounds();
    openInspector(id);
    influenceLayer.render();
}

function fillTerrainAt(latlng) {
    // Do not start terrain fill outside the configured world-size box
    if (!isInsideWorldBoxLatLng(latlng.lat, latlng.lng)) return;
    const startIdx = getGridIndex(latlng.lat, latlng.lng);
    if (startIdx === -1) return;

    const replacementType = terrainTypeSelect.value;
    const res = CONFIG.GRID_RES;
    
    // Determine source state at click point
    const sourceIsLand = landMask[startIdx] > 0;
    const sourceIsDesert = biomeMask[startIdx] === 1;
    const sourceIsMtn = terrainMask[startIdx] > 0.1;
    const sourceIsOcean = landMask[startIdx] === 0;

    // Determine what we are trying to achieve
    const isTargetingLand = replacementType === 'LAND';
    const isTargetingDesert = replacementType === 'DESERT';
    const isTargetingMtn = replacementType === 'MOUNTAIN';
    const isTargetingOcean = replacementType === 'OCEAN';

    // Prevent redundant fills
    if (isTargetingLand && sourceIsLand && !sourceIsDesert && !sourceIsMtn) return;
    if (isTargetingDesert && sourceIsDesert) return;
    if (isTargetingMtn && sourceIsMtn) return;
    if (isTargetingOcean && sourceIsOcean) return;

    loadingStatus.innerText = "Filling Terrain...";
    loadingOverlay.style.display = 'flex';

    setTimeout(() => {
        const queue = [startIdx];
        const visited = new Uint8Array(gridWidth * gridHeight);
        visited[startIdx] = 1;

        while (queue.length > 0) {
            const idx = queue.pop();

            const y = Math.floor(idx / gridWidth);
            const x = idx % gridWidth;
            const cellLat = (y + 0.5) * res - 90;
            const cellLng = (x + 0.5) * res - 180;

            // Never modify terrain outside the world-size box
            if (!isInsideWorldBoxLatLng(cellLat, cellLng)) continue;
            
            // Apply replacement
            if (isTargetingOcean) {
                landMask[idx] = 0;
                worldControlMap[idx] = 0;
                biomeMask[idx] = 0;
                terrainMask[idx] = 0;
            } else if (isTargetingLand) {
                landMask[idx] = 1;
                biomeMask[idx] = 0;
                terrainMask[idx] = 0;
            } else if (isTargetingDesert) {
                // Desert/Mtn fill only happens on land
                if (landMask[idx] > 0) {
                    biomeMask[idx] = 1;
                    terrainMask[idx] = 0;
                }
            } else if (isTargetingMtn) {
                if (landMask[idx] > 0) {
                    terrainMask[idx] = 0.75;
                    biomeMask[idx] = 0;
                }
            }

            const neighbors = [];
            if (y > 0) neighbors.push(idx - gridWidth);
            if (y < gridHeight - 1) neighbors.push(idx + gridWidth);
            if (x > 0) neighbors.push(idx - 1);
            if (x < gridWidth - 1) neighbors.push(idx + 1);
            if (x === 0) neighbors.push(idx + (gridWidth - 1));
            if (x === gridWidth - 1) neighbors.push(idx - (gridWidth - 1));

            for (const nIdx of neighbors) {
                if (!visited[nIdx]) {
                    const ny = Math.floor(nIdx / gridWidth);
                    const nx = nIdx % gridWidth;
                    const nLat = (ny + 0.5) * res - 90;
                    const nLng = (nx + 0.5) * res - 180;

                    // Do not propagate fill outside the world-size box
                    if (!isInsideWorldBoxLatLng(nLat, nLng)) continue;

                    const nIsLand = landMask[nIdx] > 0;
                    const nIsDesert = biomeMask[nIdx] === 1;
                    const nIsMtn = terrainMask[nIdx] > 0.1;
                    const nIsOcean = landMask[nIdx] === 0;

                    // Match criteria: must have exact same terrain profile as start point
                    if (nIsLand === sourceIsLand && nIsDesert === sourceIsDesert && 
                        nIsMtn === sourceIsMtn && nIsOcean === sourceIsOcean) {
                        visited[nIdx] = 1;
                        queue.push(nIdx);
                    }
                }
            }
        }

        recalculateAllBounds();
        loadingOverlay.style.display = 'none';
        influenceLayer.render();
    }, 10);
}

function fillAt(latlng) {
    const isUnclaiming = gameState === 'EDITOR_UNCLAIMING';
    if (!isUnclaiming && editingCountryId <= 0) return;
    // Do not start fill outside the world-size box
    if (!isInsideWorldBoxLatLng(latlng.lat, latlng.lng)) return;
    const startIdx = getGridIndex(latlng.lat, latlng.lng);
    if (startIdx === -1 || landMask[startIdx] === 0) return;

    const targetId = worldControlMap[startIdx];
    const replacementId = isUnclaiming ? 0 : editingCountryId;
    if (!isUnclaiming && targetId === replacementId) return;

    loadingStatus.innerText = isUnclaiming ? "Unclaiming Territory..." : "Filling Region...";
    loadingOverlay.style.display = 'flex';

    const res = CONFIG.GRID_RES;

    // Use a small timeout to let the UI show the loader
    setTimeout(() => {
        const queue = [startIdx];
        const visited = new Uint8Array(gridWidth * gridHeight);
        visited[startIdx] = 1;

        while (queue.length > 0) {
            const idx = queue.pop();

            const y = Math.floor(idx / gridWidth);
            const x = idx % gridWidth;
            const cellLat = (y + 0.5) * res - 90;
            const cellLng = (x + 0.5) * res - 180;

            // Never modify ownership outside the world-size box
            if (!isInsideWorldBoxLatLng(cellLat, cellLng)) continue;

            worldControlMap[idx] = replacementId;
            
            // Re-sync province ID to the new country owner to prevent border-crossing provinces
            provinceMap[idx] = getProvinceId(x, y, replacementId);

            // Neighbors: N, S, E, W
            const neighbors = [];
            if (y > 0) neighbors.push(idx - gridWidth);
            if (y < gridHeight - 1) neighbors.push(idx + gridWidth);
            if (x > 0) neighbors.push(idx - 1);
            if (x < gridWidth - 1) neighbors.push(idx + 1);
            
            // Handle world wrapping for East/West if necessary (optional but good for world maps)
            if (x === 0) neighbors.push(idx + (gridWidth - 1));
            if (x === gridWidth - 1) neighbors.push(idx - (gridWidth - 1));

            for (const nIdx of neighbors) {
                if (!visited[nIdx] && landMask[nIdx] > 0 && worldControlMap[nIdx] === targetId) {
                    const ny = Math.floor(nIdx / gridWidth);
                    const nx = nIdx % gridWidth;
                    const nLat = (ny + 0.5) * res - 90;
                    const nLng = (nx + 0.5) * res - 180;

                    // Do not flood-fill outside the world-size box
                    if (!isInsideWorldBoxLatLng(nLat, nLng)) continue;

                    visited[nIdx] = 1;
                    queue.push(nIdx);
                }
            }
        }

        recalculateAllBounds();
        loadingOverlay.style.display = 'none';
        influenceLayer.render();
    }, 10);
}

function applyPaintAt(latlng) {
    const isUnclaiming = gameState === 'EDITOR_UNCLAIMING';
    const isTerrain = gameState === 'EDITOR_PAINTING_TERRAIN';
    if (!isUnclaiming && !isTerrain && editingCountryId <= 0) return false;
    
    // Safety check for grid initialization
    if (!worldControlMap) return false;

    // Do not paint outside the world-size box
    if (!isInsideWorldBoxLatLng(latlng.lat, latlng.lng)) return false;

    const radius = brushSize; 
    const res = CONFIG.GRID_RES;
    
    const startLat = Math.max(0, Math.floor((latlng.lat - radius + 90) / res));
    const endLat = Math.min(gridHeight - 1, Math.ceil((latlng.lat + radius + 90) / res));
    const startLng = Math.max(0, Math.floor((latlng.lng - radius + 180) / res));
    const endLng = Math.min(gridWidth - 1, Math.ceil((latlng.lng + radius + 180) / res));

    let mapChanged = false;
    for (let y = startLat; y <= endLat; y++) {
        const rowOffset = y * gridWidth;
        for (let x = startLng; x <= endLng; x++) {
            const idx = rowOffset + x;
            if (idx < 0 || idx >= worldControlMap.length) continue;
            
            const cellCenterLat = (y + 0.5) * res - 90;
            const cellCenterLng = (x + 0.5) * res - 180;

            // Never paint or terrain-edit outside the world-size box
            if (!isInsideWorldBoxLatLng(cellCenterLat, cellCenterLng)) continue;

            // Masking logic: If a mask is active, only paint on pixels that match the mask ID
            if (paintMaskId !== -1 && worldControlMap[idx] !== paintMaskId) continue;

            // Global Wrap Support for distance calculation
            let dlng = latlng.lng - cellCenterLng;
            if (dlng > 180) dlng -= 360;
            if (dlng < -180) dlng += 360;
            
            const dSq = (latlng.lat - cellCenterLat)**2 + dlng**2;
            
            if (dSq < radius * radius) {
                if (isUnclaiming) {
                    if (landMask[idx] > 0 && worldControlMap[idx] !== 0) {
                        worldControlMap[idx] = 0;
                        provinceMap[idx] = getProvinceId(x, y, 0);
                        mapChanged = true;
                    }
                } else if (isTerrain) {
                    const type = terrainTypeSelect.value;
                    if (type === 'LAND') {
                        if (landMask[idx] === 0 || biomeMask[idx] !== 0 || terrainMask[idx] !== 0) {
                            landMask[idx] = 1;
                            biomeMask[idx] = 0;
                            terrainMask[idx] = 0;
                            mapChanged = true;
                        }
                    } else if (type === 'DESERT') {
                        // Only works on existing land; does not create new land from ocean
                        if (landMask[idx] > 0 && biomeMask[idx] !== 1) {
                            biomeMask[idx] = 1;
                            terrainMask[idx] = 0;
                            mapChanged = true;
                        }
                    } else if (type === 'MOUNTAIN') {
                        if (landMask[idx] > 0 && terrainMask[idx] < 0.7) {
                            terrainMask[idx] = 0.75;
                            biomeMask[idx] = 0;
                            mapChanged = true;
                        }
                    } else { // OCEAN
                        if (landMask[idx] !== 0) {
                            landMask[idx] = 0;
                            worldControlMap[idx] = 0;
                            biomeMask[idx] = 0;
                            mapChanged = true;
                        }
                    }
                } else {
                    if (landMask[idx] > 0 && worldControlMap[idx] !== editingCountryId) {
                        worldControlMap[idx] = editingCountryId;
                        deJureMap[idx] = editingCountryId;
                        provinceMap[idx] = getProvinceId(x, y, editingCountryId);
                        
                        const meta = countryMetadata[editingCountryId - 1];
                        if (meta) {
                            if (!meta.bounds) meta.bounds = { minX: x, maxX: x, minY: y, maxY: y };
                            meta.bounds.minX = Math.min(meta.bounds.minX, x);
                            meta.bounds.maxX = Math.max(meta.bounds.maxX, x);
                            meta.bounds.minY = Math.min(meta.bounds.minY, y);
                            meta.bounds.maxY = Math.max(meta.bounds.maxY, y);
                        }
                        mapChanged = true;
                    }
                }
            }
        }
    }
    return mapChanged;
}

function paintAt(latlng) {
    if (applyPaintAt(latlng)) {
        // Force a render refresh to ensure the canvas visually updates while dragging
        influenceLayer._forceRender = true;
        influenceLayer.render();
    }
}

map.on('mousedown', (e) => {
    // If the user is interacting with reference image handles, do NOT start painting or terrain tools.
    const targetEl = e.originalEvent && e.originalEvent.target;
    if (targetEl && targetEl.closest('.ref-handle, .ref-handle-center')) {
        return;
    }

    if (gameState === 'EDITOR_PAINTING_TERRAIN') {
        // Before starting terrain paint, ensure we're in Simplified (wargames) mode unless this is a custom canvas.
        const currentImagery = imagerySelect ? imagerySelect.value : (getCookie('mw_imagery') || 'arcgis');

        // Only prompt/switch if we're NOT already wargames and NOT on a blank/custom terrain map.
        if (currentImagery !== 'wargames' && !isCustomTerrain) {
            if (confirm("Satellite Directive: Terrain modification requires 'Simplified Mode' to correctly align geography. Switch now?")) {
                setImageryProvider('wargames', false);
                if (disableCountryGradientCheckbox) {
                    disableCountryGradientCheckbox.checked = true;
                    disableCountryGradient = true;
                }
            }
            // After switching (or cancelling), do not treat this same click as a paint event;
            // the user can click again to start painting, which prevents stray lines.
            return;
        }
    }

    if (gameState === 'EDITOR_PAINTING' || gameState === 'EDITOR_UNCLAIMING' || gameState === 'EDITOR_PAINTING_TERRAIN') {
        isPainting = true;
        lastPaintLatLng = e.latlng;
        map.dragging.disable();
        
        // Set paint mask if Alt is held down
        if (e.originalEvent && e.originalEvent.altKey) {
            const idx = getGridIndex(e.latlng.lat, e.latlng.lng);
            if (idx !== -1) {
                paintMaskId = worldControlMap[idx];
            } else {
                paintMaskId = -1;
            }
        } else {
            paintMaskId = -1;
        }

        paintAt(e.latlng);
    }
});

map.on('mousemove', (e) => {
    coordsDisplay.textContent = `${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`;

    // While dragging reference image handles, ignore painting logic entirely.
    const targetEl = e.originalEvent && e.originalEvent.target;
    if (targetEl && targetEl.closest('.ref-handle, .ref-handle-center')) {
        return;
    }

    if (isPainting && (gameState === 'EDITOR_PAINTING' || gameState === 'EDITOR_UNCLAIMING' || gameState === 'EDITOR_PAINTING_TERRAIN')) {
        if (lastPaintLatLng) {
            // INTERPOLATION SYSTEM: "Raycast" between last and current mouse positions.
            // This prevents gaps when dragging the brush faster than the frame rate.
            const p1 = lastPaintLatLng;
            const p2 = e.latlng;
            
            let dLng = p2.lng - p1.lng;
            if (dLng > 180) dLng -= 360;
            if (dLng < -180) dLng += 360;
            const dLat = p2.lat - p1.lat;
            
            const dist = Math.sqrt(dLat*dLat + dLng*dLng);
            const step = brushSize * 0.35; // Step every 35% of brush radius
            
            if (dist > step) {
                const numSteps = Math.ceil(dist / step);
                let changedAny = false;
                for (let i = 1; i <= numSteps; i++) {
                    const t = i / numSteps;
                    const interpLat = p1.lat + dLat * t;
                    let interpLng = p1.lng + dLng * t;
                    if (interpLng > 180) interpLng -= 360;
                    if (interpLng < -180) interpLng += 360;
                    
                    if (applyPaintAt({ lat: interpLat, lng: interpLng })) {
                        changedAny = true;
                    }
                }
                if (changedAny) {
                    influenceLayer._forceRender = true;
                    influenceLayer.render();
                }
            } else {
                paintAt(e.latlng);
            }
            lastPaintLatLng = e.latlng;
        } else {
            paintAt(e.latlng);
            lastPaintLatLng = e.latlng;
        }
    }
});

map.on('mouseup', () => {
    if (isPainting) {
        // Update label positions and territory stats after a painting stroke finishes
        recalculateAllBounds();
        influenceLayer.render();
    }
    isPainting = false;
    map.dragging.enable();
});

editorCreateBtn.addEventListener('click', () => {
    createCountryModal.style.display = 'flex';
});

cancelCreateBtn.addEventListener('click', () => {
    createCountryModal.style.display = 'none';
});

confirmCreateBtn.addEventListener('click', async () => {
    const name = newCountryNameInput.value || "New Nation";
    const color = newCountryColorInput.value;
    const file = newCountryFlagInput.files[0];
    
    customCountryData = {
        name,
        color: color.replace('#', 'rgba(') + ')', // basic hex to rgba converter simplified
        flagUrl: null
    };

    // Correct hex to rgba
    const r = parseInt(color.slice(1, 3), 16);
    const g = parseInt(color.slice(3, 5), 16);
    const b = parseInt(color.slice(5, 7), 16);
    customCountryData.color = `rgba(${r}, ${g}, ${b}, 0.5)`;
    customCountryData.displayName = name;

    if (file) {
        try {
            loadingStatus.innerText = "Uploading Flag...";
            loadingOverlay.style.display = 'flex';
            customCountryData.flagUrl = await websim.upload(file);
            loadingOverlay.style.display = 'none';
        } catch (e) {
            console.error("Flag upload failed", e);
        }
    }

    createCountryModal.style.display = 'none';
    gameState = 'EDITOR_PLACING';
    statusText.innerText = "Click on Map to Place Capital";
    map.getContainer().classList.add('painting-cursor');
});

inspectNameInput.addEventListener('input', (e) => {
    if (editingCountryId <= 0) return;
    const meta = countryMetadata.find(m => m && m.id === editingCountryId);
    if (meta) {
        meta.name = e.target.value;
        // Propagate to live setup/simulation objects
        sides.flat().forEach(c => {
            if (c.id === editingCountryId) c.name = meta.name;
        });
        updateSidesUI();
        // Ensure labels recalculate their spine/position in real-time
        recalculateAllBounds();
        influenceLayer.render();
    }
});

inspectHubFlagBtn.addEventListener('click', () => {
    openHub('flags');
});

inspectFetchFlagBtn.addEventListener('click', async () => {
    if (editingCountryId <= 0) return;
    const name = inspectNameInput.value.trim();
    if (!name) return;

    let code = findCodeByName(name);

    // Fallback to GeoJSON search if code mapping doesn't have it
    if (!code && rawGeoJsonData) {
        const feature = rawGeoJsonData.features.find(f => {
            const p = f.properties;
            const possibleNames = [
                p.NAME, p.name, p.admin, p.NAME_LONG, p.formal_en, p.name_sort
            ].filter(Boolean).map(n => n.toLowerCase());
            return possibleNames.includes(name.toLowerCase());
        });

        if (feature) {
            const getFeatCode = (feat) => {
                if (!feat || !feat.properties) return null;
                const p = feat.properties;
                let c = p.ISO_A2 || p.iso_a2 || p.ISO_A2_EH || p.iso_a2_eh || p.ADDR_A2 || null;
                if (c === "-99") c = null;
                return c ? c.toLowerCase() : null;
            };
            code = getFeatCode(feature);
        }
    }

    if (!code) {
        alert("Could not find a modern flag for '" + name + "'. Try the full English name.");
        return;
    }

    const flagUrl = `https://flagcdn.com/w160/${code}.png`;
    updateCountryFlag(editingCountryId, flagUrl);
});

inspectFlagInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (file && editingCountryId > 0) {
        try {
            loadingStatus.innerText = "Uploading Flag...";
            loadingOverlay.style.display = 'flex';
            const url = await websim.upload(file);
            
            updateCountryFlag(editingCountryId, url);
            loadingOverlay.style.display = 'none';
        } catch (err) {
            console.error(err);
            loadingOverlay.style.display = 'none';
        }
    }
});

inspectColorPicker.addEventListener('input', (e) => {
    if (editingCountryId <= 0) return;
    const newColorHex = e.target.value;
    const r = parseInt(newColorHex.slice(1, 3), 16);
    const g = parseInt(newColorHex.slice(3, 5), 16);
    const b = parseInt(newColorHex.slice(5, 7), 16);
    
    const meta = countryMetadata.find(m => m && m.id === editingCountryId);
    if (meta) {
        meta.color = `rgba(${r}, ${g}, ${b}, 0.5)`;
        meta.rgba = [r, g, b, 0.5];
        inspectColorSwatch.style.backgroundColor = meta.color;
        influenceLayer.render();
    }
});

shareCountryBtn.addEventListener('click', () => {
    if (editingCountryId <= 0) return;
    const meta = countryMetadata.find(m => m && m.id === editingCountryId);
    if (!meta) return;

    shareCountryNameInput.value = meta.name || "Custom Nation";
    shareCountryDescInput.value = "";
    shareCountryModal.style.display = 'flex';
});

shareFlagBtn.addEventListener('click', () => {
    if (editingCountryId <= 0) return;
    const meta = countryMetadata.find(m => m && m.id === editingCountryId);
    if (!meta || !meta.flagUrl) {
        alert("This nation does not have a flag to share. Upload or fetch one first.");
        return;
    }

    shareFlagNameInput.value = `${meta.name || 'Custom'} Flag`;
    shareFlagDescInput.value = "";
    shareFlagModal.style.display = 'flex';
});

cancelShareFlagBtn.onclick = () => {
    shareFlagModal.style.display = 'none';
};

confirmShareFlagBtn.onclick = async () => {
    if (editingCountryId <= 0) return;
    const meta = countryMetadata.find(m => m && m.id === editingCountryId);
    if (!meta || !meta.flagUrl) return;

    const publicName = shareFlagNameInput.value.trim() || "Custom Flag";
    const description = shareFlagDescInput.value.trim();

    shareFlagModal.style.display = 'none';
    loadingStatus.innerText = "Sharing Flag to Library...";
    loadingOverlay.style.display = 'flex';

    try {
        await room.collection('flag_library_v1').create({
            name: publicName,
            description: description,
            flagUrl: meta.flagUrl
        });
        loadingOverlay.style.display = 'none';
        alert("Flag successfully shared!");
    } catch (e) {
        console.error(e);
        alert("Failed to share flag.");
        loadingOverlay.style.display = 'none';
    }
};

cancelShareCountryBtn.onclick = () => {
    shareCountryModal.style.display = 'none';
};

confirmShareCountryBtn.onclick = async () => {
    if (editingCountryId <= 0) return;
    const meta = countryMetadata.find(m => m && m.id === editingCountryId);
    if (!meta) return;
    
    const publicName = shareCountryNameInput.value.trim() || meta.name || "Custom Nation";
    const description = shareCountryDescInput.value.trim();

    shareCountryModal.style.display = 'none';
    loadingStatus.innerText = `Saving ${publicName} to Library...`;
    loadingOverlay.style.display = 'flex';

    try {
        // 1. Generate Border Preview
        let previewUrl = null;
        if (influenceLayer && influenceLayer._container) {
            influenceLayer._isCapturing = true;
            influenceLayer.render();
            const canvas = influenceLayer._container;
            const previewBlob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.8));
            influenceLayer._isCapturing = false;
            influenceLayer.render();
            if (previewBlob) {
                const previewFile = new File([previewBlob], "country_preview.jpg", { type: "image/jpeg" });
                previewUrl = await websim.upload(previewFile);
            }
        }

        // 2. Collect all cells belonging to this country
        const cells = [];
        for (let i = 0; i < worldControlMap.length; i++) {
            if (worldControlMap[i] === editingCountryId) {
                const y = Math.floor(i / gridWidth);
                const x = i % gridWidth;
                cells.push([x, y]);
            }
        }

        if (cells.length === 0) {
            alert("Country has no territory to share!");
            loadingOverlay.style.display = 'none';
            return;
        }

        // 3. Upload Cells Data as a file to bypass 250KB record limit
        const cellsBlob = new Blob([JSON.stringify(cells)], { type: 'application/json' });
        const cellsFile = new File([cellsBlob], "country_cells.json", { type: "application/json" });
        const cellsUrl = await websim.upload(cellsFile);

        // 4. Create Persistent Record
        await room.collection('country_library_v1').create({
            name: publicName,
            description: description,
            previewUrl: previewUrl,
            color: meta.color,
            flagUrl: meta.flagUrl,
            gridRes: CONFIG.GRID_RES,
            cellsUrl: cellsUrl
        });

        loadingOverlay.style.display = 'none';
        alert("Country added to Global Library!");
    } catch (e) {
        console.error(e);
        alert("Failed to share country.");
        loadingOverlay.style.display = 'none';
    }
};

inspectPaintBtn.addEventListener('click', () => {
    gameState = 'EDITOR_PAINTING';
    statusText.innerText = "PAINTING BORDERS (Drag to draw)";
    countryInspector.style.display = 'none';
    map.getContainer().classList.add('painting-cursor');
    editorPaintBtn.style.display = 'block';
    editorFillBtn.style.display = 'block';
    editorUnclaimBtn.style.display = 'block';
    editorPaintBtn.classList.add('active');
    brushControls.style.display = 'flex';
});

inspectAnnexClickBtn.addEventListener('click', () => {
    if (editingCountryId <= 0) return;
    gameState = 'EDITOR_ANNEXING';
    statusText.innerText = "ANNEX TOOL: Click any country on the map to absorb its land";
    countryInspector.style.display = 'none';
    map.getContainer().classList.add('painting-cursor');
});

editorPaintBtn.addEventListener('click', () => {
    if (gameState === 'EDITOR_PAINTING') {
        gameState = 'EDITOR_ACTIVE';
        statusText.innerText = "Map Editor (Alpha)";
        editorPaintBtn.classList.remove('active');
        map.getContainer().classList.remove('painting-cursor');
        brushControls.style.display = 'none';
    } else if (editingCountryId > 0 || gameState === 'EDITOR_UNCLAIMING') {
        gameState = 'EDITOR_PAINTING';
        statusText.innerText = "PAINTING BORDERS (Drag to draw)";
        editorPaintBtn.classList.add('active');
        editorFillBtn.classList.remove('active');
        editorUnclaimBtn.classList.remove('active');
        map.getContainer().classList.add('painting-cursor');
        brushControls.style.display = 'flex';
    }
});

editorFillBtn.addEventListener('click', () => {
    if (gameState === 'EDITOR_FILLING' || gameState === 'EDITOR_FILLING_TERRAIN') {
        const wasTerrain = gameState === 'EDITOR_FILLING_TERRAIN';
        gameState = 'EDITOR_ACTIVE';
        statusText.innerText = "Map Editor (Alpha)";
        editorFillBtn.classList.remove('active');
        map.getContainer().classList.remove('painting-cursor');
        // If we were filling terrain, return to the terrain menu state
        if (wasTerrain) {
            gameState = 'EDITOR_PAINTING_TERRAIN';
            editorTerrainBtn.classList.add('active');
            statusText.innerText = "TERRAIN BRUSH (Paint land or carve oceans)";
            map.getContainer().classList.add('painting-cursor');
            brushControls.style.display = 'flex';
            terrainControls.style.display = 'flex';
        }
    } else if (gameState === 'EDITOR_PAINTING_TERRAIN') {
        gameState = 'EDITOR_FILLING_TERRAIN';
        statusText.innerText = "FILL TERRAIN (Click a region)";
        editorFillBtn.classList.add('active');
        editorTerrainBtn.classList.remove('active');
        brushControls.style.display = 'none';
        map.getContainer().classList.add('painting-cursor');
    } else if (editingCountryId > 0 || gameState === 'EDITOR_UNCLAIMING') {
        gameState = 'EDITOR_FILLING';
        statusText.innerText = "FILL TOOL (Click a region)";
        editorFillBtn.classList.add('active');
        editorPaintBtn.classList.remove('active');
        editorUnclaimBtn.classList.remove('active');
        brushControls.style.display = 'none';
        map.getContainer().classList.add('painting-cursor');
    }
});

editorUnclaimBtn.addEventListener('click', () => {
    if (gameState === 'EDITOR_UNCLAIMING') {
        gameState = 'EDITOR_ACTIVE';
        statusText.innerText = "Map Editor (Alpha)";
        editorUnclaimBtn.classList.remove('active');
        map.getContainer().classList.remove('painting-cursor');
        brushControls.style.display = 'none';
    } else {
        gameState = 'EDITOR_UNCLAIMING';
        statusText.innerText = "UNCLAIM TOOL (Remove country ownership)";
        editorUnclaimBtn.classList.add('active');
        editorPaintBtn.classList.remove('active'); 
        editorFillBtn.classList.remove('active');
        editorTerrainBtn.classList.remove('active');
        terrainControls.style.display = 'none';
        editorPlaceDivisionBtn.classList.remove('active');
        map.getContainer().classList.add('painting-cursor');
        brushControls.style.display = 'flex';
    }
});

editorTerrainBtn.addEventListener('click', () => {
    if (gameState === 'EDITOR_PAINTING_TERRAIN') {
        gameState = 'EDITOR_ACTIVE';
        statusText.innerText = "Map Editor (Alpha)";
        editorTerrainBtn.classList.remove('active');
        map.getContainer().classList.remove('painting-cursor');
        brushControls.style.display = 'none';
        terrainControls.style.display = 'none';
    } else {
        gameState = 'EDITOR_PAINTING_TERRAIN';
        statusText.innerText = "TERRAIN BRUSH (Paint land or carve oceans)";
        editorTerrainBtn.classList.add('active');
        editorPaintBtn.classList.remove('active');
        editorFillBtn.classList.remove('active');
        editorUnclaimBtn.classList.remove('active');
        editorPlaceDivisionBtn.classList.remove('active');
        map.getContainer().classList.add('painting-cursor');
        brushControls.style.display = 'flex';
        terrainControls.style.display = 'flex';
    }
});

editorPlaceDivisionBtn.addEventListener('click', () => {
    if (gameState === 'EDITOR_PLACING_DIVISION') {
        gameState = 'EDITOR_ACTIVE';
        statusText.innerText = godModeActive ? "GOD MODE: Map Editing Active" : "Map Editor (Alpha)";
        editorPlaceDivisionBtn.classList.remove('active');
        map.getContainer().classList.remove('painting-cursor');
    } else {
        gameState = 'EDITOR_PLACING_DIVISION';
        editingCountryId = -1; // Reset to force selecting a new country source
        statusText.innerText = "SELECT SOURCE: Click a nation to deploy its divisions";
        editorPlaceDivisionBtn.classList.add('active');
        editorPaintBtn.classList.remove('active');
        editorFillBtn.classList.remove('active');
        editorUnclaimBtn.classList.remove('active');
        countryInspector.style.display = 'none';
        brushControls.style.display = 'none';
        map.getContainer().classList.add('painting-cursor');
    }
});

brushSizeSlider.addEventListener('input', (e) => {
    brushSize = parseFloat(e.target.value);
    brushSizeVal.innerText = brushSize.toFixed(1);
});

async function annexFeatureToCountry(feature, countryId) {
    if (!feature || countryId <= 0) return;

    loadingStatus.innerText = `Annexing ${feature.properties.NAME || feature.properties.name || 'Region'}...`;
    loadingOverlay.style.display = 'flex';
    
    // Brief timeout to let UI update
    await new Promise(r => setTimeout(r, 50));

    const bounds = L.geoJSON(feature).getBounds();
    const res = CONFIG.GRID_RES;
    const sLat = Math.max(0, Math.floor((bounds.getSouth() + 90) / res));
    const eLat = Math.min(gridHeight - 1, Math.ceil((bounds.getNorth() + 90) / res));
    const sLng = Math.max(0, Math.floor((bounds.getWest() + 180) / res));
    const eLng = Math.min(gridWidth - 1, Math.ceil((bounds.getEast() + 180) / res));

    for (let y = sLat; y <= eLat; y++) {
        for (let x = sLng; x <= eLng; x++) {
            const lat = (y * res) - 90 + (res * 0.5);
            const lng = (x * res) - 180 + (res * 0.5);
            if (isPointInFeature(lat, lng, feature)) {
                const idx = y * gridWidth + x;
                // Add this land to the country's world control map
                worldControlMap[idx] = countryId;
                // Sync province ID immediately
                provinceMap[idx] = getProvinceId(x, y, countryId);
                
                const meta = countryMetadata[countryId - 1];
                if (meta) {
                    if (!meta.bounds) meta.bounds = { minX: x, maxX: x, minY: y, maxY: y };
                    meta.bounds.minX = Math.min(meta.bounds.minX, x);
                    meta.bounds.maxX = Math.max(meta.bounds.maxX, x);
                    meta.bounds.minY = Math.min(meta.bounds.minY, y);
                    meta.bounds.maxY = Math.max(meta.bounds.maxY, y);
                }
                // Ensure it's marked as land
                if (landMask[idx] === 0) landMask[idx] = 1;
            }
        }
    }

    loadingOverlay.style.display = 'none';
    influenceLayer.render();
}

annexCountryBtn.addEventListener('click', async () => {
    if (!rawGeoJsonData || editingCountryId <= 0) return;
    const name = annexCountryInput.value.trim().toLowerCase();
    if (!name) return;

    const feature = rawGeoJsonData.features.find(f => {
        const fName = (f.properties.NAME || f.properties.name || f.properties.admin || f.properties.NAME_LONG || "").toLowerCase();
        return fName === name;
    });

    if (!feature) {
        alert("Country not found in modern reference data. Try names like 'Poland', 'Ukraine', or 'United States of America'.");
        return;
    }

    await annexFeatureToCountry(feature, editingCountryId);
    annexCountryInput.value = "";
});

document.getElementById('set-overlord-btn').onclick = () => {
    if (editingCountryId <= 0) return;
    selectingOverlordForId = editingCountryId;
    gameState = 'EDITOR_SELECTING_OVERLORD';
    statusText.innerText = "Select Overlord Country (Click map)";
    countryInspector.style.display = 'none';
    map.getContainer().classList.add('painting-cursor');
};

document.getElementById('set-releasable-btn').onclick = () => {
    if (editingCountryId <= 0) return;
    selectingOverlordForId = editingCountryId;
    gameState = 'EDITOR_SELECTING_RELEASER';
    statusText.innerText = "Select Host Nation (Releaser) on map";
    countryInspector.style.display = 'none';
    map.getContainer().classList.add('painting-cursor');
};

document.getElementById('clear-overlord-btn').onclick = () => {
    if (editingCountryId <= 0) return;
    const meta = countryMetadata.find(m => m && m.id === editingCountryId);
    if (meta) {
        meta.overlordId = null;
        sides.flat().forEach(c => { if (c.id === editingCountryId) c.overlordId = null; });

        // If this country had an original flag before puppetization, restore it
        if (meta.baseFlagUrl) {
            updateCountryFlag(editingCountryId, meta.baseFlagUrl);
        }

        statusText.innerText = `Vassal status cleared for ${meta.name}`;
        openInspector(editingCountryId);
        influenceLayer.render();
    }
};

closeInspectorBtn.addEventListener('click', () => {
    countryInspector.style.display = 'none';
    editingCountryId = -1;
    influenceLayer.render();
});

if (inspectBuffBtn) {
    inspectBuffBtn.addEventListener('click', (event) => {
        if (editingCountryId <= 0) return;
        const meta = countryMetadata.find(m => m && m.id === editingCountryId);
        if (!meta) return;

        // Determine direction: clicked arrow uses its data-dir, clicking center cycles forward
        let dir = 1;
        const target = event.target;
        if (target && target.classList.contains('buff-arrow')) {
            const d = parseInt(target.getAttribute('data-dir'), 10);
            if (d === -1 || d === 1) dir = d;
        }

        const current = meta.buffState || 'none';
        const nextState = cycleBuffState(current, dir);
        meta.buffState = nextState;

        // Propagate to any live side objects so combat uses the new buff
        sides.flat().forEach(c => {
            if (c && c.id === editingCountryId) {
                c.buffState = nextState;
            }
        });

        const bMeta = BUFF_METADATA[nextState] || BUFF_METADATA['none'];
        inspectBuffBtn.innerHTML = `
            <span class="buff-arrow" data-dir="-1" style="font-size:11px; margin-right:4px;">◀</span>
            <span class="buff-label">BUFF: ${bMeta.label}</span>
            <span class="buff-arrow" data-dir="1" style="font-size:11px; margin-left:4px;">▶</span>
        `;
        inspectBuffBtn.style.background = bMeta.color;
        inspectBuffBtn.style.color = bMeta.textColor;

        // Refresh setup UI so side slots show the new buff too
        updateSidesUI();
        influenceLayer.render();
    });
}

// City inspector logic
function refreshCityOwnerSelect(selectedOwnerId) {
    if (!cityOwnerSelect) return;
    cityOwnerSelect.innerHTML = '<option value="">(None)</option>';
    countryMetadata.forEach(m => {
        if (!m) return;
        const opt = document.createElement('option');
        opt.value = m.id;
        opt.textContent = m.name;
        if (selectedOwnerId && selectedOwnerId === m.id) opt.selected = true;
        cityOwnerSelect.appendChild(opt);
    });
}

function openCityInspector(cityId) {
    const city = cities.find(c => c.id === cityId);
    if (!city) return;
    editingCityId = cityId;
    cityInspector.style.display = 'block';
    cityNameInput.value = city.name || "";
    refreshCityOwnerSelect(city.ownerId || city.sovereignId || null);
    cityCapitalCheckbox.checked = !!city.isCapital;
}

cityNameInput.addEventListener('input', (e) => {
    if (editingCityId <= 0) return;
    const city = cities.find(c => c.id === editingCityId);
    if (!city) return;
    city.name = e.target.value;
    influenceLayer.render();
});

cityOwnerSelect.addEventListener('change', () => {
    if (editingCityId <= 0) return;
    const city = cities.find(c => c.id === editingCityId);
    if (!city) return;
    const val = parseInt(cityOwnerSelect.value || '0', 10);
    city.ownerId = val || null;
    city.sovereignId = city.ownerId;
    influenceLayer.render();
});

cityCapitalCheckbox.addEventListener('change', () => {
    if (editingCityId <= 0) return;
    const city = cities.find(c => c.id === editingCityId);
    if (!city) return;
    const ownerId = city.ownerId || city.sovereignId;
    city.isCapital = cityCapitalCheckbox.checked;
    if (ownerId && city.isCapital) {
        // Clear capital flag on other cities of this owner
        cities.forEach(c => {
            if (c.id !== city.id && (c.ownerId || c.sovereignId) === ownerId) {
                c.isCapital = false;
            }
        });
    }
    influenceLayer.render();
});

cityMoveBtn.addEventListener('click', () => {
    if (editingCityId <= 0) return;
    statusText.innerText = "City Move: click on the map to set the new position.";
    cityEditMode = 'MOVE';
    cityInspector.style.display = 'none';
});

cityDeleteBtn.addEventListener('click', () => {
    if (editingCityId <= 0) return;
    const city = cities.find(c => c.id === editingCityId);
    if (!city) return;
    if (!confirm(`Delete city "${city.name}"?`)) return;
    cities = cities.filter(c => c.id !== editingCityId);
    activeTheaterCities = activeTheaterCities.filter(c => c.id !== editingCityId);
    editingCityId = -1;
    cityInspector.style.display = 'none';
    influenceLayer.render();
    statusText.innerText = "City deleted.";
});

cityCloseBtn.addEventListener('click', () => {
    cityInspector.style.display = 'none';
    editingCityId = -1;
});

editorExitBtn.addEventListener('click', () => {
    location.reload(); // Quick reset
});

if (editorMapSettingsBtn && mapSettingsModal) {
    editorMapSettingsBtn.addEventListener('click', () => {
        // Pre-fill fields from current state
        mapSettingsNameInput.value = mapName || "";
        mapSettingsWidthInput.value = worldWidthDeg || 360;
        mapSettingsHeightInput.value = worldHeightDeg || 180;
        mapSettingsMissilesCheckbox.checked = !!missilesEnabled;
        mapSettingsModal.style.display = 'flex';
    });
}

if (mapSettingsCancelBtn && mapSettingsModal) {
    mapSettingsCancelBtn.addEventListener('click', () => {
        mapSettingsModal.style.display = 'none';
    });
}

if (mapSettingsApplyBtn && mapSettingsModal) {
    mapSettingsApplyBtn.addEventListener('click', () => {
        const newName = mapSettingsNameInput.value.trim() || "Untitled Map";
        const newW = parseFloat(mapSettingsWidthInput.value) || 360;
        const newH = parseFloat(mapSettingsHeightInput.value) || 180;
        const newMissilesEnabled = !!mapSettingsMissilesCheckbox.checked;

        const sizeChanged = (newW !== worldWidthDeg) || (newH !== worldHeightDeg);

        mapName = newName;
        missilesEnabled = newMissilesEnabled;

        // If size changed, apply bounds and force Simplified mode if not already there
        if (sizeChanged) {
            const currentImagery = imagerySelect ? imagerySelect.value : (getCookie('mw_imagery') || 'arcgis');
            const allowSwitch = currentImagery !== 'wargames';
            applyWorldBounds(newW, newH, allowSwitch);
        } else {
            // Still enforce bounding box if it was never set
            applyWorldBounds(newW, newH, false);
        }

        // Sync missiles toggle with simulation-level bombsDisabled and checkboxes
        if (disableBombsCheckbox) {
            disableBombsCheckbox.checked = !missilesEnabled;
        }
        bombsDisabled = (disableBombsCheckbox && disableBombsCheckbox.checked) || !missilesEnabled;

        mapSettingsModal.style.display = 'none';
        statusText.innerText = `MAP SETTINGS UPDATED: ${mapName}`;
        influenceLayer.render();
    });
}

/**
 * Editor tools paging: split the crowded toolbox into two pages.
 * Page 1: scenario-level tools; Page 2: country library / ZIP tools.
 */
function clearRefHandles() {
    refHandles.forEach(h => map.removeLayer(h));
    refHandles = [];
}

function updateRefHandles() {
    clearRefHandles();
    if (!referenceOverlay || !referenceImageUrl) return;

    const bounds = referenceOverlay.getBounds();
    const nw = bounds.getNorthWest();
    const ne = bounds.getNorthEast();
    const sw = bounds.getSouthWest();
    const se = bounds.getSouthEast();
    const center = bounds.getCenter();

    const handleIcon = L.divIcon({
        className: 'ref-handle',
        html: '<div style="width:14px; height:14px; background:#27ae60; border:2px solid #fff; border-radius:50%; box-shadow:0 0 8px rgba(0,0,0,0.6);"></div>',
        iconSize: [14, 14],
        iconAnchor: [7, 7]
    });

    const centerHandleIcon = L.divIcon({
        className: 'ref-handle-center',
        html: '<div style="width:20px; height:20px; background:#2e86de; border:2px solid #fff; border-radius:50%; box-shadow:0 0 10px rgba(0,0,0,0.7); display:flex; align-items:center; justify-content:center; color:white; font-size:12px; font-weight:bold;">✥</div>',
        iconSize: [20, 20],
        iconAnchor: [10, 10]
    });

    // 1. Center Handle (Move)
    const mCenter = L.marker(center, { icon: centerHandleIcon, draggable: true }).addTo(map);
    mCenter.on('dragstart', () => {
        // Disable map dragging while manipulating the reference image center handle
        map.dragging.disable();
    });
    mCenter.on('drag', (e) => {
        const newCenter = e.target.getLatLng();
        const dLat = newCenter.lat - center.lat;
        const dLng = newCenter.lng - center.lng;
        const newBounds = [
            [nw.lat + dLat, nw.lng + dLng],
            [se.lat + dLat, se.lng + dLng]
        ];
        referenceOverlay.setBounds(newBounds);
    });
    mCenter.on('dragend', (e) => {
        map.dragging.enable();
        updateRefHandles(e);
    });
    refHandles.push(mCenter);

    // 2. Corner Handles (Resize)
    const corners = [
        { pos: nw, name: 'nw' },
        { pos: ne, name: 'ne' },
        { pos: sw, name: 'sw' },
        { pos: se, name: 'se' }
    ];

    corners.forEach(c => {
        const marker = L.marker(c.pos, { icon: handleIcon, draggable: true }).addTo(map);
        marker.on('dragstart', () => {
            // Disable map dragging while resizing the reference image with a corner handle
            map.dragging.disable();
        });
        marker.on('drag', (e) => {
            const newPos = e.target.getLatLng();
            let newBounds;
            if (c.name === 'nw') newBounds = L.latLngBounds(newPos, se);
            else if (c.name === 'ne') newBounds = L.latLngBounds(newPos, sw);
            else if (c.name === 'sw') newBounds = L.latLngBounds(newPos, ne);
            else if (c.name === 'se') newBounds = L.latLngBounds(newPos, nw);
            
            if (newBounds) referenceOverlay.setBounds(newBounds);
        });
        marker.on('dragend', (e) => {
            // Re-enable map dragging once the handle drag is finished
            map.dragging.enable();
            updateRefHandles(e);
        });
        refHandles.push(marker);
    });
}

function updateEditorToolPage(page) {
    // Page 1: Scenario-level tools
    const page1Ids = [
        'editor-create-btn',
        'editor-test-btn',
        'editor-update-btn',
        'editor-save-btn',
        'editor-load-btn',
        'editor-share-btn',
        'editor-hub-btn'
    ];

    // Page 2: Library / country / ZIP tools
    const page2Ids = [
        'editor-library-btn',
        'editor-flag-library-btn',
        'editor-save-country-btn',
        'editor-load-country-btn',
        'editor-save-multi-btn',
        'editor-save-all-zip-btn',
        'editor-load-zip-btn',
        'editor-import-country-from-scenario-btn'
    ];

    // Page 3: Map painting / Unit tools
    const page3Ids = [
        'editor-paint-btn',
        'editor-fill-btn',
        'editor-unclaim-btn',
        'editor-terrain-btn',
        'editor-place-division-btn',
        'brush-controls',
        'terrain-controls'
    ];

    // Page 4: City tools
    const page4Ids = [
        'editor-city-new-btn',
        'editor-city-clear-btn'
    ];

    // Page 5: Overlay tools
    const page5Ids = [
        'overlay-tools'
    ];

    const allIds = page1Ids.concat(page2Ids, page3Ids, page4Ids, page5Ids);

    // Explicit display types so we don't depend on whatever inline style happened to be set before.
    const displayMap = {
        'brush-controls': 'flex',
        'overlay-tools': 'flex'
    };

    // Show only the tools belonging to the active page
    allIds.forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;

        const isOnPage1 = page1Ids.includes(id);
        const isOnPage2 = page2Ids.includes(id);
        const isOnPage3 = page3Ids.includes(id);
        const isOnPage4 = page4Ids.includes(id);
        const isOnPage5 = page5Ids.includes(id);

        const shouldShow =
            (page === 1 && isOnPage1) ||
            (page === 2 && isOnPage2) ||
            (page === 3 && isOnPage3) ||
            (page === 4 && isOnPage4) ||
            (page === 5 && isOnPage5);

        if (shouldShow) {
            el.style.display = displayMap[id] || 'inline-flex';
        } else {
            el.style.display = 'none';
        }
    });

    // Toggle handles visibility based on whether a reference image exists
    if (referenceOverlay) {
        updateRefHandles();
    } else {
        clearRefHandles();
    }

    // Highlight active page button
    if (editorToolsPage1Btn && editorToolsPage2Btn && editorToolsPage3Btn && editorToolsPage4Btn && editorToolsPage5Btn) {
        editorToolsPage1Btn.style.background = page === 1 ? '#2e86de' : '#444';
        editorToolsPage2Btn.style.background = page === 2 ? '#2e86de' : '#444';
        editorToolsPage3Btn.style.background = page === 3 ? '#2e86de' : '#444';
        editorToolsPage4Btn.style.background = page === 4 ? '#2e86de' : '#444';
        editorToolsPage5Btn.style.background = page === 5 ? '#2e86de' : '#444';
    }
}

if (editorToolsPage1Btn) {
    editorToolsPage1Btn.addEventListener('click', () => updateEditorToolPage(1));
}
if (editorToolsPage2Btn) {
    editorToolsPage2Btn.addEventListener('click', () => updateEditorToolPage(2));
}
if (editorToolsPage3Btn) {
    editorToolsPage3Btn.addEventListener('click', () => updateEditorToolPage(3));
}
if (editorToolsPage4Btn) {
    editorToolsPage4Btn.addEventListener('click', () => updateEditorToolPage(4));
}
if (editorToolsPage5Btn) {
    editorToolsPage5Btn.addEventListener('click', () => updateEditorToolPage(5));
}

editorTestBtn.addEventListener('click', () => {
    if (countryMetadata.length < 2) {
        alert("You need at least 2 nations to test a conflict.");
        return;
    }
    gameMode = 'EDITOR_TEST';
    gameState = 'SELECTING_P1';
    statusText.innerText = "Test: Select First Country";
    editorToolbox.style.display = 'none';
    setupPanel.style.display = 'block';
    setupOptions.style.display = 'none';
    resetBtn.style.display = 'block';
    
    // Clear selections
    attackers = [];
    defenders = [];
    teamAId = -1;
    
    updateSidesUI();
    influenceLayer.render();
});

function generatePresetData(name) {
    const mapData = [];
    // Save all cells that are land (mask != 0), even if they don't have a country owner (id == 0)
    for (let i = 0; i < worldControlMap.length; i++) {
        if (landMask[i] !== 0) {
            // Store as [index, ownerId, biomeId]
            mapData.push([i, worldControlMap[i], biomeMask[i] || 0]);
        }
    }

    // Save mountain/terrain intensity for custom maps to prevent losing painted peaks
    const mountainData = [];
    if (isCustomTerrain) {
        for (let i = 0; i < terrainMask.length; i++) {
            if (terrainMask[i] > 0) {
                mountainData.push([i, parseFloat(terrainMask[i].toFixed(2))]);
            }
        }
    }

    const currentImagery = getCookie('mw_imagery') || 'arcgis';

    // Filter countryMetadata to handle sparse arrays/null entries
    // Includes releasables (nations without current land but preserved in metadata)
    const cleanMetadata = countryMetadata.filter(m => m && typeof m === 'object' && m.id).map(m => ({
        id: m.id,
        name: m.name || m.feature?.properties?.NAME || "Unnamed Nation",
        color: m.color || 'rgba(150, 150, 150, 0.5)',
        isCustom: !!m.isCustom,
        flagUrl: m.flagUrl || null,
        role: m.role || 'OFFENSE',
        overlordId: m.overlordId || null,
        releasableBy: m.releasableBy || null,
        savedCells: m.savedCells || null
    }));

    // Persist city data (custom + any edited capitals)
    const cleanCities = (cities || []).map((c, idx) => ({
        id: c.id || idx + 1,
        name: c.name,
        lat: c.lat,
        lng: c.lng,
        isCapital: !!c.isCapital,
        ownerId: c.ownerId || c.sovereignId || null,
        isCustom: !!c.isCustom,
        pop: c.pop || 0
    }));

    return {
        name: name,
        metadata: cleanMetadata,
        mapData: mapData,
        mountainData: mountainData.length > 0 ? mountainData : null,
        mapRes: document.getElementById('map-res-select').value,
        gridRes: CONFIG.GRID_RES,
        cities: cleanCities,
        imagery: currentImagery,
        isCustomTerrain: isCustomTerrain,
        disableCountryGradient: disableCountryGradient,
        customSatelliteUrl: customSatelliteUrl,
        worldWidthDeg: worldWidthDeg,
        worldHeightDeg: worldHeightDeg,
        missilesEnabled: missilesEnabled,
        // Reference image persistence
        referenceImageUrl: referenceImageUrl || null,
        refImageOpacity: typeof refOpacity === 'number' ? refOpacity : 0.5,
        refImageBounds: referenceOverlay
            ? {
                  nw: referenceOverlay.getBounds().getNorthWest(),
                  se: referenceOverlay.getBounds().getSouthEast()
              }
            : null,
        refDrawAbove: !!refAboveTerrain
    };
}

editorSaveBtn.addEventListener('click', () => {
    const presetName = prompt("Enter a name for this preset:", "My Custom Scenario");
    if (!presetName) return;

    const saveData = generatePresetData(presetName);
    const blob = new Blob([JSON.stringify(saveData)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${presetName.replace(/\s+/g, '_')}_preset.json`;
    a.click();
    URL.revokeObjectURL(url);
});

function resetConflictSetupState() {
    // Clear any previous conflict setup or running war state so new scenarios start clean
    sides = [[], []];
    attackers = sides[0];
    defenders = sides[1];
    activeSideIndex = 0;
    teamAId = -1;
    buffedTeam = null;
    teamASoldiers = 0;
    teamBSoldiers = 0;
    initialTeamASoldiers = 0;
    initialTeamBSoldiers = 0;
    soldiersPerUnitA = CONFIG.UNIT_TO_SOLDIER_RATIO;
    soldiersPerUnitB = CONFIG.UNIT_TO_SOLDIER_RATIO;
    units = [];
    bases = [];
    bombs = [];
    explosions = [];
    activeBattles = [];
    capitalLostCountries = new Set();
    activeRebellion = null;
    countryCasualties.clear();
    latestCountryStats.clear();
    selectedCountryIds.clear();
    editingCountryId = -1;
    editingCityId = -1;
    paintMaskId = -1;
    gameTimeEnabled = false;
    gameTimeDate = null;
    gameTimeAccumulatorMs = 0;
    if (gameDateDisplay) {
        gameDateDisplay.style.display = 'none';
    }
    treatyAlert.style.display = 'none';
    statusText.innerText = getTranslation('SELECT_P1');
    unitCountsDiv.style.display = 'none';
    statsPanel.style.display = 'none';
    casualtyPanel.style.display = 'none';
    document.getElementById('speed-controls').style.display = 'none';
    godModeBtn.style.display = (gameMode === 'CONQUEST') ? 'block' : 'none';
    forcePeaceBtn.style.display = 'none';
    resetBtn.style.display = 'block';
    restartScenarioBtn.style.display = 'block';
    updateRestartVisibility();
}

async function performPresetLoad(fileOrBlob, targetMode = 'EDITOR') {
    if (!fileOrBlob) return;

    let userChoice = { action: 'skip' };

    try {
        loadingOverlay.style.display = 'flex';
        loadingStatus.innerText = "Processing Archives...";
        
        const text = await fileOrBlob.text();
        const data = JSON.parse(text);

        if (!data || !data.metadata || !data.mapData) {
            throw new Error("Invalid preset structure");
        }

        // Ensure engine is initialized with the CURRENT grid density before we use worldControlMap.
        // This fixes cases where a preset was saved at a low grid density, but your settings are now higher.
        const gridSelect = document.getElementById('grid-res-select');
        const desiredGridRes = gridSelect ? parseFloat(gridSelect.value) : CONFIG.GRID_RES;

        if (!worldControlMap || CONFIG.GRID_RES !== desiredGridRes) {
            // Update engine config to the desired grid resolution and reallocate all grid arrays.
            CONFIG.GRID_RES = desiredGridRes;
            initializeEngine();
        } else {
            // Sync settings state (mountains/provinces) even if resolution hasn't changed
            initializeEngine();
        }

        // Always clear previous conflict setup / selection so old picks don't bleed into new scenarios
        resetConflictSetupState();

        // Visual environment restoration
        if (data.imagery) {
            // If it's a custom terrain map, the imagery switch should be temporary as per user directive
            setImageryProvider(data.imagery, !data.isCustomTerrain);
        }
        if (data.disableCountryGradient !== undefined) {
            disableCountryGradient = data.disableCountryGradient;
            if (disableCountryGradientCheckbox) {
                disableCountryGradientCheckbox.checked = disableCountryGradient;
            }
        }

        // World size & missile settings restoration
        if (typeof data.worldWidthDeg === 'number' && typeof data.worldHeightDeg === 'number') {
            applyWorldBounds(data.worldWidthDeg, data.worldHeightDeg, false);
        } else {
            // Default to full world if not specified
            applyWorldBounds(360, 180, false);
        }
        if (typeof data.missilesEnabled === 'boolean') {
            missilesEnabled = data.missilesEnabled;
        } else {
            missilesEnabled = true;
        }
        if (mapSettingsMissilesCheckbox) {
            mapSettingsMissilesCheckbox.checked = !!missilesEnabled;
        }
        if (disableBombsCheckbox) {
            disableBombsCheckbox.checked = !missilesEnabled;
        }
        bombsDisabled = (disableBombsCheckbox && disableBombsCheckbox.checked) || !missilesEnabled;

        // Restore Custom Overlays
        if (data.customSatelliteUrl) {
            customSatelliteUrl = data.customSatelliteUrl;
            customSatelliteImg = new Image();
            customSatelliteImg.crossOrigin = "anonymous";
            customSatelliteImg.src = customSatelliteUrl;
        } else {
            customSatelliteUrl = null;
            customSatelliteImg = null;
        }

        // Reference image metadata is always loaded, but the overlay is only drawn in editor modes.
        referenceImageUrl = data.referenceImageUrl || null;
        refOpacity = typeof data.refImageOpacity === 'number' ? data.refImageOpacity : 0.5;
        refScale = typeof data.refImageScale === 'number' ? data.refImageScale : 1.0;
        refAboveTerrain = !!data.refDrawAbove;

        if (referenceOverlay) {
            map.removeLayer(referenceOverlay);
            referenceOverlay = null;
        }

        if (referenceImageUrl && targetMode === 'EDITOR') {
            let bounds;
            if (data.refImageBounds && data.refImageBounds.nw && data.refImageBounds.se) {
                // Use saved bounds to preserve proportions/position
                bounds = [
                    [data.refImageBounds.nw.lat, data.refImageBounds.nw.lng],
                    [data.refImageBounds.se.lat, data.refImageBounds.se.lng]
                ];
            } else {
                // Fallback: center on map using approximate aspect
                const center = map.getCenter();
                const h = 20 * refScale;
                const w = h * 1.6;
                bounds = [[center.lat - h, center.lng - w], [center.lat + h, center.lng + w]];
            }
            referenceOverlay = L.imageOverlay(referenceImageUrl, bounds, {
                opacity: refOpacity,
                interactive: false,
                pane: 'refImagePane'
            }).addTo(map);
            // Rebuild handles in editor
            updateRefHandles();
        } else {
            referenceOverlay = null;
        }

        // Optimization: Use cached GeoJSON if available to skip redundant network requests and processing
        // But only if this isn't a custom painted map that doesn't need them
        if (!rawGeoJsonData && !data.isCustomTerrain) {
            const mapRes = document.getElementById('map-res-select').value;
            const geoUrl = `${CONFIG.GEOJSON_BASE}${mapRes}/cultural/ne_${mapRes}_admin_0_countries.json`;
            await loadCountries(geoUrl, true, true);
        } else if (!data.isCustomTerrain) {
            // If we have GeoJSON, we still need to reset the masks but don't need to re-download
            worldControlMap.fill(0);
            occupationMap.fill(0);
            primaryOccupierMap.fill(0);
            landMask.fill(0);
            provinceMap.fill(0);
            deJureMap.fill(0);
            // Land mask is usually preserved from first boot load but ensure it is ready
        }

        // Check for empty metadata and prompt for procedural generation
        const metaList = data.metadata || [];
        if (metaList.length === 0 && targetMode !== 'EDITOR') {
            loadingOverlay.style.display = 'none';
            noNationsModal.style.display = 'flex';
            userChoice = await new Promise(resolve => {
                confirmRandomGenBtn.onclick = () => {
                    const count = parseInt(randomNationsCountInput.value) || 15;
                    resolve({ action: 'generate', count });
                };
                skipRandomGenBtn.onclick = () => {
                    resolve({ action: 'skip' });
                };
            });
            noNationsModal.style.display = 'none';
            loadingOverlay.style.display = 'flex';
        }

        // Restore metadata and reconstruct RGBA values for rendering
        const currentLang = getCookie('mw_lang') || 'en';
        
        // Reset and rebuild metadata
        countryMetadata = [];
        metaList.forEach(m => {
            if (!m || !m.id) return;

            // Apply system language translation to country names in preset
            const translatedName = getTranslation(m.name, currentLang, 'NATIONS');
            if (translatedName !== m.name) {
                m.displayName = translatedName;
            }
            
            // Resolution Normalization for Releasable Saved Cells
            const sourceRes = data.gridRes || CONFIG.GRID_RES;
            const targetRes = CONFIG.GRID_RES;
            let normalizedCells = m.savedCells;

            if (m.savedCells && sourceRes !== targetRes) {
                // If resolution changed, we clear savedCells and rely on deJure fallback 
                // unless we implement a complex coordinate remapper here.
                // For now, we'll keep the raw data but warn the engine.
                console.log(`Satellite Notice: ${m.name} releasable cells require coordinate remapping.`);
            }

            const meta = {
                ...m,
                savedCells: normalizedCells,
                rgba: parseColorToRGBA(m.color || 'rgba(150, 150, 150, 0.5)'),
                bounds: m.bounds || { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity }
            };
            if (meta.flagUrl) {
                meta.tempFlag = new Image();
                meta.tempFlag.crossOrigin = "anonymous";
                meta.tempFlag.src = meta.flagUrl;
            }
            countryMetadata[m.id - 1] = meta;
        });
        
        // Clear current map
        worldControlMap.fill(0);
        occupationMap.fill(0);
        primaryOccupierMap.fill(0);
        biomeMask.fill(0);
        
        // Ensure custom terrain state is preserved
        isCustomTerrain = !!data.isCustomTerrain;
        if (isCustomTerrain) {
            landMask.fill(0);
        }
        
        // Coordinate Remapping: If source resolution differs from current engine settings,
        // we re-project each point to the new grid coordinate system.
        const sourceRes = data.gridRes || CONFIG.GRID_RES;
        const targetRes = CONFIG.GRID_RES;
        const sourceGridWidth = Math.ceil(360 / sourceRes);

        const mapData = data.mapData;
        const totalEntries = mapData.length;

        if (sourceRes === targetRes) {
            // Optimized bulk assignment
            for (let i = 0; i < totalEntries; i++) {
                const entry = mapData[i];
                const idx = entry[0];
                const val = entry[1];
                const bio = entry[2] || 0;
                
                if (idx < worldControlMap.length) {
                    worldControlMap[idx] = val;
                    biomeMask[idx] = bio;
                    // Any index present in the mapData array is land
                    landMask[idx] = 1;
                }
            }
        } else {
            console.log(`Satellite Redrawing: Converting scenario grid (${sourceRes} -> ${targetRes})`);
            // Pre-calculate loop limits and constants for resolution conversion
            const ratio = sourceRes / targetRes;
            const isUpscaling = sourceRes > targetRes;

            for (let i = 0; i < totalEntries; i++) {
                const entry = mapData[i];
                const idx = entry[0];
                const val = entry[1];
                
                const sy = Math.floor(idx / sourceGridWidth);
                const sx = idx % sourceGridWidth;
                const baseLat = (sy * sourceRes) - 90;
                const baseLng = (sx * sourceRes) - 180;
                
                // Robust conversion: Map all target cells covered by the source cell
                const xStart = Math.floor((baseLng + 180) / targetRes);
                const xEnd = Math.floor((baseLng + sourceRes + 180 - 0.0001) / targetRes);
                const yStart = Math.floor((baseLat + 90) / targetRes);
                const yEnd = Math.floor((baseLat + sourceRes + 90 - 0.0001) / targetRes);
                
                for (let ty = yStart; ty <= yEnd; ty++) {
                    if (ty < 0 || ty >= gridHeight) continue;
                    const rowOffset = ty * gridWidth;
                    for (let tx = xStart; tx <= xEnd; tx++) {
                        if (tx < 0 || tx >= gridWidth) continue;
                        const tIdx = rowOffset + tx;
                        if (tIdx < worldControlMap.length) {
                            worldControlMap[tIdx] = val;
                            landMask[tIdx] = 1;
                        }
                    }
                }
            }
        }
        
        // Restore mountain data
        terrainMask.fill(0);
        if (data.mountainData) {
            const mData = data.mountainData;
            for (let i = 0; i < mData.length; i++) {
                const [idx, intensity] = mData[i];
                if (idx < terrainMask.length) {
                    terrainMask[idx] = intensity;
                }
            }
        } else if (!data.isCustomTerrain && mountainsEnabled) {
            // Earth scenario without baked mountains: trigger dynamic GeoJSON terrain scan
            const resToUse = data.mapRes || document.getElementById('map-res-select').value || '110m';
            await loadTerrain(resToUse);
        }

        // Re-generate provinces for the loaded preset to ensure they respect the new borders
        generateProvinces();

        // Reset adjacency cache whenever map changes
        adjacencyCache = null;

        // Load cities from preset if present, otherwise fall back to global dataset
        if (Array.isArray(data.cities)) {
            cities = data.cities.map((c, idx) => ({
                id: c.id || idx + 1,
                name: c.name,
                lat: c.lat,
                lng: c.lng,
                pop: c.pop || 0,
                isCapital: !!c.isCapital,
                ownerId: c.ownerId || null,
                isCustom: !!c.isCustom
            }));
        } else {
            await loadCities();
        }

        gameMode = targetMode;
        mainMenu.style.display = 'none';
        mapUi.style.display = 'flex';

        if (targetMode === 'CONQUEST') {
            gameState = 'SELECTING_P1';
            statusText.innerText = currentScenarioContext ? `PLAYING: ${currentScenarioContext.name}` : getTranslation('SELECT_P1');
            setupPanel.style.display = 'block';
            editorToolbox.style.display = 'none';
            godModeBtn.style.display = 'block';
            resetBtn.style.display = 'block';
            statsPanel.style.display = 'none';
        } else {
            gameState = 'EDITOR_ACTIVE';
            statusText.innerText = currentScenarioContext ? `REMIXING: ${currentScenarioContext.name}` : "Map Editor (Alpha)";
            setupPanel.style.display = 'none';
            editorToolbox.style.display = 'flex';
            statsPanel.style.display = 'none';
        }
        updateRestartVisibility();

        if (activeScenarioId) {
            editorUpdateBtn.style.display = 'block';
        } else {
            editorUpdateBtn.style.display = 'none';
        }

        // Capture Instant Quick Restart Snapshots immediately upon scenario load
        initialWorldControlMapSnapshot = new Int32Array(worldControlMap);
        initialDeJureMapSnapshot = new Int32Array(deJureMap);
        initialProvinceMapSnapshot = new Int32Array(provinceMap);
        initialLandMaskSnapshot = new Uint8Array(landMask);
        initialCountryMetadataSnapshot = deepClone(countryMetadata);
        initialCitiesSnapshot = deepClone(cities);

        setTimeout(async () => {
            // If the user chose to generate random nations earlier, trigger it now after the grid is ready
            if (metaList.length === 0 && userChoice.action === 'generate') {
                await spawnRandomNationsAcrossMap(userChoice.count);
            }
            
            recalculateAllBounds();
            loadingOverlay.style.display = 'none';
            mapUi.style.display = 'flex';
            influenceLayer.render();
            updateRestartVisibility();
        }, 500);
    } catch (err) {
        console.error("Satellite Load Error:", err);
        alert(`Error loading preset: ${err.message || "File may be corrupted"}`);
        loadingOverlay.style.display = 'none';
    }
}

editorLoadBtn.addEventListener('click', () => {
    initAudio();
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
        currentScenarioContext = null;
        performPresetLoad(e.target.files[0], 'EDITOR');
    };
    input.click();
});

editorHubBtn.addEventListener('click', () => {
    openHub('scenarios');
});

editorLibraryBtn.addEventListener('click', () => {
    openHub('countries');
});

document.getElementById('editor-save-country-btn').addEventListener('click', () => {
    if (editingCountryId <= 0) return;
    saveCountryLocally(editingCountryId);
});

document.getElementById('editor-load-country-btn').addEventListener('click', () => {
    loadCountryFromPC();
});

if (editorSaveMultiBtn) {
    editorSaveMultiBtn.addEventListener('click', async () => {
        if (selectedCountryIds.size === 0) {
            alert("Ctrl+click countries on the map to select them, then use this button to export a ZIP.");
            return;
        }

        const ids = Array.from(selectedCountryIds);
        const zip = new JSZip();

        // Ensure each selected country has up-to-date savedCells and metadata
        ids.forEach((id) => {
            const meta = countryMetadata.find(m => m && m.id === id);
            if (!meta) return;

            // Build or refresh savedCells snapshot
            const cells = [];
            for (let i = 0; i < worldControlMap.length; i++) {
                if (worldControlMap[i] === id) {
                    const y = Math.floor(i / gridWidth);
                    const x = i % gridWidth;
                    cells.push([x, y]);
                }
            }
            meta.savedCells = cells;

            const countryData = {
                id: meta.id,
                name: meta.name,
                color: meta.color,
                flagUrl: meta.flagUrl,
                isCustom: meta.isCustom || false,
                role: meta.role || 'OFFENSE',
                overlordId: meta.overlordId || null
            };

            const presetData = {
                name: `${meta.name}_country`,
                metadata: countryData,
                cells: cells,
                gridRes: CONFIG.GRID_RES,
                version: "1.0"
            };

            const safeName = (meta.name || `country_${id}`).replace(/[^\w\-]+/g, '_');
            zip.file(`${safeName}.json`, JSON.stringify(presetData, null, 2));
        });

        try {
            const blob = await zip.generateAsync({ type: 'blob' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'selected_countries.zip';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            statusText.innerText = `Exported ${ids.length} countr${ids.length === 1 ? 'y' : 'ies'} to selected_countries.zip`;
        } catch (err) {
            console.error("ZIP export failed:", err);
            alert("Failed to generate ZIP. Check console for details.");
        }
    });
}

/**
 * Save all countries with any territory in the scenario into a ZIP of per‑country JSONs.
 */
if (editorSaveAllZipBtn) {
    editorSaveAllZipBtn.addEventListener('click', async () => {
        if (!countryMetadata || !worldControlMap) {
            alert("No map is loaded yet.");
            return;
        }

        const zip = new JSZip();

        // Build a quick presence map (which ids actually have tiles)
        const hasTiles = new Set();
        for (let i = 0; i < worldControlMap.length; i++) {
            const id = worldControlMap[i];
            if (id > 0) hasTiles.add(id);
        }

        const candidates = countryMetadata.filter(m => m && m.id && hasTiles.has(m.id));
        if (candidates.length === 0) {
            alert("No countries with territory to export.");
            return;
        }

        candidates.forEach(meta => {
            const cells = [];
            for (let i = 0; i < worldControlMap.length; i++) {
                if (worldControlMap[i] === meta.id) {
                    const y = Math.floor(i / gridWidth);
                    const x = i % gridWidth;
                    cells.push([x, y]);
                }
            }

            const countryData = {
                id: meta.id,
                name: meta.name,
                color: meta.color,
                flagUrl: meta.flagUrl,
                isCustom: meta.isCustom || false,
                role: meta.role || 'OFFENSE',
                overlordId: meta.overlordId || null
            };

            const presetData = {
                name: `${meta.name}_country`,
                metadata: countryData,
                cells: cells,
                gridRes: CONFIG.GRID_RES,
                version: "1.0"
            };

            const safeName = (meta.name || `country_${meta.id}`).replace(/[^\w\-]+/g, '_');
            zip.file(`${safeName}.json`, JSON.stringify(presetData, null, 2));
        });

        try {
            const blob = await zip.generateAsync({ type: 'blob' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'all_countries.zip';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            statusText.innerText = `Exported ${candidates.length} countries to all_countries.zip`;
        } catch (err) {
            console.error("ZIP export (all countries) failed:", err);
            alert("Failed to generate ZIP for all countries. Check console for details.");
        }
    });
}

/**
 * Load multiple country JSON files from a ZIP and merge them into the current scenario.
 */


// -------- Overlay Tools Implementation --------

document.getElementById('custom-sat-input')?.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    loadingStatus.innerText = "Uploading Background Overlay...";
    loadingOverlay.style.display = 'flex';
    try {
        const url = await websim.upload(file);
        customSatelliteUrl = url;
        customSatelliteImg = new Image();
        customSatelliteImg.crossOrigin = "anonymous";
        customSatelliteImg.onload = () => {
            loadingOverlay.style.display = 'none';
            influenceLayer.render();
        };
        customSatelliteImg.src = url;
    } catch (err) {
        console.error(err);
        loadingOverlay.style.display = 'none';
    }
});

document.getElementById('clear-sat-btn')?.addEventListener('click', () => {
    customSatelliteUrl = null;
    customSatelliteImg = null;
    influenceLayer.render();
});

document.getElementById('ref-image-input')?.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    loadingStatus.innerText = "Processing Reference Image...";
    loadingOverlay.style.display = 'flex';
    try {
        const url = await websim.upload(file);
        referenceImageUrl = url;
        if (referenceOverlay) map.removeLayer(referenceOverlay);
        
        // Load image to get natural dimensions for aspect ratio preservation
        const img = new Image();
        img.onload = () => {
            const aspect = img.width / img.height;
            const center = map.getCenter();
            const h = 20 * refScale;
            const w = h * aspect;
            const bounds = [[center.lat - h, center.lng - w], [center.lat + h, center.lng + w]];
            
            referenceOverlay = L.imageOverlay(url, bounds, { 
                opacity: refOpacity, 
                interactive: false,
                pane: 'refImagePane' 
            }).addTo(map);
            updateRefHandles();
            loadingOverlay.style.display = 'none';
        };
        img.src = url;
    } catch (err) {
        console.error(err);
        loadingOverlay.style.display = 'none';
    }
});

document.getElementById('ref-opacity-slider')?.addEventListener('input', (e) => {
    refOpacity = parseFloat(e.target.value);
    if (referenceOverlay) referenceOverlay.setOpacity(refOpacity);
    if (influenceLayer) {
        influenceLayer._forceRender = true;
        influenceLayer.render();
    }
});

const refAboveCheckbox = document.getElementById('ref-above-checkbox');
if (refAboveCheckbox) {
    // Initialize checkbox from current state when opening editor
    refAboveCheckbox.checked = !!refAboveTerrain;
    refAboveCheckbox.addEventListener('change', (e) => {
        refAboveTerrain = !!e.target.checked;
        // No need to change Leaflet pane; we composite into the canvas.
        if (influenceLayer) {
            influenceLayer._forceRender = true;
            influenceLayer.render();
        }
    });
}

document.getElementById('ref-scale-slider')?.addEventListener('input', (e) => {
    refScale = parseFloat(e.target.value);
    if (referenceOverlay && referenceImageUrl) {
        const center = referenceOverlay.getBounds().getCenter();
        const w = 40 * refScale;
        const h = 25 * refScale;
        const newBounds = [[center.lat - h, center.lng - w], [center.lat + h, center.lng + w]];
        referenceOverlay.setBounds(newBounds);
        updateRefHandles();
    }
});

document.getElementById('clear-ref-btn')?.addEventListener('click', () => {
    if (referenceOverlay) map.removeLayer(referenceOverlay);
    referenceOverlay = null;
    referenceImageUrl = null;
    clearRefHandles();
});

document.getElementById('editor-download-map-btn')?.addEventListener('click', () => {
    if (!worldControlMap || !landMask) return;
    
    statusText.innerText = "GENERATING GLOBAL MAP EXPORT...";
    
    // GLOBAL EXPORT SYSTEM: Produces a 1:1 Plate Carree projection of the world grid.
    // This allows the resulting PNG to be re-imported as a Custom Satellite background
    // that aligns perfectly with the engine's geographical coordinate system.
    const canvas = document.createElement('canvas');
    canvas.width = gridWidth;
    canvas.height = gridHeight;
    const ctx = canvas.getContext('2d');
    const imgData = ctx.createImageData(gridWidth, gridHeight);
    const data = imgData.data;

    for (let i = 0; i < worldControlMap.length; i++) {
        const sid = worldControlMap[i];
        const lm = landMask[i];
        
        // Base Palette (Matches 'wargames' mode)
        let r = 5, g = 52, b = 72; // Deep Ocean Blue
        
        if (lm > 0) {
            // Country colors are excluded from the terrain layout export for a cleaner reference image
            r = 20; g = 38; b = 20; // Dark Military Green (Neutral Land)
        }

        // Project grid cell index to image pixel coordinates (Flipping Y axis)
        const gx = i % gridWidth;
        const gy = Math.floor(i / gridWidth);
        const ty = (gridHeight - 1 - gy);
        const pixelIdx = (ty * gridWidth + gx) * 4;
        
        data[pixelIdx] = r;
        data[pixelIdx + 1] = g;
        data[pixelIdx + 2] = b;
        data[pixelIdx + 3] = 255;
    }
    
    ctx.putImageData(imgData, 0, 0);
    
    try {
        const link = document.createElement('a');
        const timestamp = new Date().getTime();
        link.download = `modern_wars_world_layout_${timestamp}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
        statusText.innerText = "GLOBAL MAP EXPORTED";
    } catch (e) {
        console.error("Export failed:", e);
        alert("SATELLITE ERROR: Could not generate export file.");
    }
});

// -------- Procedural Nation Generation (For empty presets) --------

const noNationsModal = document.getElementById('no-nations-modal');
const randomNationsCountInput = document.getElementById('random-nations-count');
const confirmRandomGenBtn = document.getElementById('confirm-random-gen-btn');
const skipRandomGenBtn = document.getElementById('skip-random-gen-btn');

/**
 * Procedurally populates all land cells on the map with a specified number of random nations.
 * Uses an interleaved BFS expansion to ensure organic, relatively balanced territory sizes.
 */
async function spawnRandomNationsAcrossMap(count) {
    if (!worldControlMap || !landMask) return;
    
    loadingStatus.innerText = "Generating Civilizations...";
    loadingOverlay.style.display = 'flex';
    
    // 1. Identify all valid land indices
    const landIndices = [];
    for (let i = 0; i < landMask.length; i++) {
        if (landMask[i] > 0) {
            landIndices.push(i);
            worldControlMap[i] = 0; // Ensure unowned start
        }
    }

    if (landIndices.length === 0) {
        loadingOverlay.style.display = 'none';
        alert("SATELLITE ERROR: No landmass identified to populate with civilizations.");
        return;
    }

    const actualCount = Math.min(count, landIndices.length);
    const queues = [];
    
    // 2. Pick random seeds and initialize metadata
    countryMetadata = [];
    for (let i = 0; i < actualCount; i++) {
        let randIdx;
        let attempts = 0;
        // Try to pick seeds that aren't already taken
        do {
            randIdx = landIndices[Math.floor(Math.random() * landIndices.length)];
            attempts++;
        } while (worldControlMap[randIdx] !== 0 && attempts < 100);

        const id = i + 1;
        worldControlMap[randIdx] = id;
        
        const h = Math.floor(Math.random() * 360);
        const s = 60 + Math.random() * 30;
        const l = 40 + Math.random() * 20;
        const color = `hsla(${h}, ${s}%, ${l}%, 0.5)`;
        
        const prefixes = ["United", "New", "Grand", "Great", "North", "South", "East", "West", "Holy", "Royal", "Federal", "Imperial", "Democratic", "People's", "Sovereign"];
        const roots = ["Balt", "Nord", "Slav", "Franc", "Goth", "Rhone", "Iber", "Sax", "Slavia", "Anglo", "Lat", "Turk", "Persia", "Indo", "Sino", "Nippon", "Austral", "Afro", "Euro", "Ameri", "Veld", "Arid", "Boreal", "Luso", "Fenn", "Celt", "Gallic", "Helvet", "Austr", "Magyar", "Pannoni", "Daci", "Thrac", "Levant", "Mesopotam"];
        const suffixes = ["ia", "stan", "land", "ica", "any", "os", "nia", "ria", "via", "dia", "zania", "ga", "tania", "onia", "esia"];
        const forms = [
            "{Prefix} {Root}{Suffix}",
            "Republic of {Root}{Suffix}",
            "Kingdom of {Root}{Suffix}",
            "{Root}{Suffix} Empire",
            "Federation of {Prefix} {Root}{Suffix}",
            "United {Root}{Suffix} States",
            "{Root}{Suffix} Commonwealth"
        ];

        const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
        const root = roots[Math.floor(Math.random() * roots.length)];
        const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
        const form = forms[Math.floor(Math.random() * forms.length)];
        
        const name = form.replace("{Prefix}", prefix).replace("{Root}", root).replace("{Suffix}", suffix);

        const newMeta = {
            id: id,
            name: name,
            color: color,
            rgba: parseColorToRGBA(color),
            isCustom: true,
            bounds: { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity }
        };
        countryMetadata.push(newMeta);

        queues.push([randIdx]);
    }

    // 3. Interleaved Expansion (BFS)
    // We expand each nation one "step" at a time in a round-robin to prevent one nation
    // from instantly claiming a giant continent while others are stuck.
    let unclaimedLand = true;
    let iterations = 0;
    
    while (unclaimedLand) {
        unclaimedLand = false;
        iterations++;
        
        if (iterations % 100 === 0) {
            await new Promise(r => setTimeout(r, 0));
        }

        for (let i = 0; i < actualCount; i++) {
            const q = queues[i];
            const id = i + 1;
            const nextLevel = [];
            
            while (q.length > 0) {
                const curr = q.shift();
                const x = curr % gridWidth;
                const y = Math.floor(curr / gridWidth);

                const neighbors = [
                    curr + 1, curr - 1, curr + gridWidth, curr - gridWidth
                ];

                for (const nIdx of neighbors) {
                    if (nIdx < 0 || nIdx >= worldControlMap.length) continue;
                    // Horizontal wrapping check
                    const nx = nIdx % gridWidth;
                    if (Math.abs(nx - x) > 1) continue; 

                    if (landMask[nIdx] > 0 && worldControlMap[nIdx] === 0) {
                        worldControlMap[nIdx] = id;
                        nextLevel.push(nIdx);
                        unclaimedLand = true;
                    }
                }
                
                // Only process one "layer" per nation per round
                if (q.length === 0) {
                    queues[i] = nextLevel;
                    break;
                }
            }
        }
    }

    generateProvinces();
    recalculateAllBounds();
    loadingOverlay.style.display = 'none';
    influenceLayer.render();
    statusText.innerText = `WORLD POPULATED: ${actualCount} nations established.`;
}

// -------- Import Country From Scenario (editor / godmode) --------

async function loadScenarioForCountryImportFromBlob(blob) {
    try {
        const text = await blob.text();
        const data = JSON.parse(text);
        if (!data || !data.metadata || !data.mapData) {
            throw new Error("Invalid preset structure");
        }
        importScenarioBuffer = {
            metadata: data.metadata,
            mapData: data.mapData,
            gridRes: data.gridRes || CONFIG.GRID_RES
        };
        populateImportCountrySelect();
        // Restore the last selected scenario key in the dropdown if we have one
        if (importScenarioSelect && lastImportScenarioKey) {
            importScenarioSelect.value = lastImportScenarioKey;
        }
    } catch (e) {
        console.error("Import scenario load failed:", e);
        alert("Could not read that scenario file. Make sure it is a preset exported from this engine.");
        importScenarioBuffer = null;
        selectedImportCountryId = null;
        if (importCountrySearch) {
            importCountrySearch.value = '';
            importCountrySearch.disabled = true;
        }
        if (importCountryCardList) {
            importCountryCardList.innerHTML = `
                <div style="font-size:11px; color:#777; text-align:center; padding:10px;">
                    Failed to load scenario
                </div>
            `;
        }
    }
}

async function loadScenarioForCountryImportFromUrl(url) {
    try {
        const resp = await fetch(url);
        if (!resp.ok) throw new Error("HTTP " + resp.status);
        const blob = await resp.blob();
        await loadScenarioForCountryImportFromBlob(blob);
    } catch (e) {
        console.error("Import built‑in scenario load failed:", e);
        alert("Failed to load built‑in scenario for import.");
    }
}

function populateImportCountrySelect() {
    if (!importScenarioBuffer || !importCountryCardList || !importCountrySearch) return;
    const metaList = importScenarioBuffer.metadata || [];
    if (!metaList.length) {
        importCountryCardList.innerHTML = `
            <div style="font-size:11px; color:#777; text-align:center; padding:10px;">
                No countries found in scenario
            </div>
        `;
        importCountrySearch.disabled = true;
        selectedImportCountryId = null;
        importScenarioCountriesCache = [];
        return;
    }

    // Count tiles per country id in the source scenario for a useful size hint
    const mapData = importScenarioBuffer.mapData || [];
    const tileCounts = new Map();
    mapData.forEach(([idx, val]) => {
        if (!val) return;
        tileCounts.set(val, (tileCounts.get(val) || 0) + 1);
    });

    const sortedMeta = metaList
        .filter(m => m && m.id)
        .map(m => {
            const tiles = tileCounts.get(m.id) || 0;
            // Try to find a flagUrl from metadata if present
            const flagUrl = m.flagUrl || null;
            return {
                id: m.id,
                name: m.name || `Country ${m.id}`,
                tiles,
                flagUrl
            };
        })
        .filter(m => m.tiles > 0)
        .sort((a, b) => b.tiles - a.tiles || a.name.localeCompare(b.name));

    if (!sortedMeta.length) {
        importCountryCardList.innerHTML = `
            <div style="font-size:11px; color:#777; text-align:center; padding:10px;">
                No countries with territory found
            </div>
        `;
        importCountrySearch.disabled = true;
        selectedImportCountryId = null;
        importScenarioCountriesCache = [];
        return;
    }

    importScenarioCountriesCache = sortedMeta;
    selectedImportCountryId = null;
    importCountrySearch.disabled = false;
    importCountrySearch.value = '';
    renderImportCountryCards('');
}

function openImportCountryModal() {
    if (!importCountryModal) return;
    if (!(gameMode === 'EDITOR' || godModeActive)) {
        alert("You can only import from scenario while in the editor or God Mode.");
        return;
    }

    // If we already have a loaded source scenario, reuse it and its country list
    if (importScenarioBuffer && importScenarioCountriesCache.length > 0) {
        importCountryModal.style.display = 'flex';
        if (importScenarioSelect && lastImportScenarioKey) {
            importScenarioSelect.value = lastImportScenarioKey;
        }
        if (importScenarioFileInput) {
            importScenarioFileInput.style.display = 'none';
        }
        if (importCountrySearch) {
            // Keep any existing search text; just ensure the field is enabled
            importCountrySearch.disabled = false;
        }
        // Re-render cards from cache (filtered by current search if any)
        renderImportCountryCards(importCountrySearch ? importCountrySearch.value : '');
        return;
    }

    // Fresh open with no cached source scenario
    importScenarioBuffer = null;
    selectedImportCountryId = null;
    importScenarioCountriesCache = [];
    if (importScenarioSelect) importScenarioSelect.value = '';
    if (importScenarioFileInput) {
        importScenarioFileInput.value = '';
        importScenarioFileInput.style.display = 'none';
    }
    if (importCountrySearch) {
        importCountrySearch.value = '';
        importCountrySearch.disabled = true;
    }
    if (importCountryCardList) {
        importCountryCardList.innerHTML = `
            <div style="font-size:11px; color:#777; text-align:center; padding:10px;">
                Choose a source scenario first
            </div>
        `;
    }
    importCountryModal.style.display = 'flex';
}

if (editorImportCountryBtn) {
    editorImportCountryBtn.addEventListener('click', () => {
        openImportCountryModal();
    });
}

if (importCountryCancelBtn) {
    importCountryCancelBtn.addEventListener('click', () => {
        importCountryModal.style.display = 'none';
    });
}

if (importScenarioSelect) {
    importScenarioSelect.addEventListener('change', async (e) => {
        const val = e.target.value;
        lastImportScenarioKey = val || null;
        importScenarioBuffer = null;
        selectedImportCountryId = null;
        if (importCountrySearch) {
            importCountrySearch.value = '';
            importCountrySearch.disabled = true;
        }
        if (importCountryCardList) {
            importCountryCardList.innerHTML = `
                <div style="font-size:11px; color:#777; text-align:center; padding:10px;">
                    Loading…
                </div>
            `;
        }

        if (val === 'file') {
            if (importScenarioFileInput) {
                importScenarioFileInput.style.display = 'block';
                importScenarioFileInput.click();
            }
            return;
        } else {
            if (importScenarioFileInput) importScenarioFileInput.style.display = 'none';
        }

        // Map built‑in keys to local preset JSONs
        const keyToUrl = {
            'builtin:modern_2022': 'world map 2022.json',
            'builtin:ww2_1936': 'ww2_releasables_fixed_preset.json',
            'builtin:ww2_1942': '1942.json',
            'builtin:ww1_1914': 'world_war_1__1914_.json',
            'builtin:coldwar_1974': 'better_cold_war_preset.json',
            'builtin:coldwar_1948': '1948 (1).json'
        };
        const url = keyToUrl[val];
        if (!url) {
            importScenarioSelect.innerHTML = '<option value="">Unknown source selection</option>';
            importScenarioSelect.disabled = true;
            return;
        }
        await loadScenarioForCountryImportFromUrl(url);
    });
}

if (importScenarioFileInput) {
    importScenarioFileInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        // Remember that we're using a file source so the select can reflect it
        lastImportScenarioKey = 'file';
        await loadScenarioForCountryImportFromBlob(file);
    });
}

if (importCountryConfirmBtn) {
    importCountryConfirmBtn.addEventListener('click', () => {
        if (!importScenarioBuffer) {
            alert("Choose a source scenario first.");
            return;
        }
        const cid = selectedImportCountryId || 0;
        if (!cid) {
            alert("Choose a country to import.");
            return;
        }
        importSingleCountryFromScenario(importScenarioBuffer, cid);
        importCountryModal.style.display = 'none';
    });
}

function importSingleCountryFromScenario(source, sourceCountryId) {
    if (!worldControlMap || !countryMetadata) return;

    const metaList = source.metadata || [];
    const sourceMeta = metaList.find(m => m && m.id === sourceCountryId);
    if (!sourceMeta) {
        alert("Country not found in source scenario.");
        return;
    }

    // Allocate a fresh ID in the current scenario
    const maxId = countryMetadata.reduce((max, m) => m ? Math.max(max, m.id) : max, 0);
    const newId = maxId + 1;

    // Build new metadata entry
    const newMeta = {
        id: newId,
        name: sourceMeta.name || `Imported ${sourceCountryId}`,
        color: sourceMeta.color || 'rgba(150,150,150,0.5)',
        rgba: parseColorToRGBA(sourceMeta.color || 'rgba(150,150,150,0.5)'),
        isCustom: true,
        flagUrl: sourceMeta.flagUrl || null,
        role: sourceMeta.role || 'OFFENSE',
        overlordId: sourceMeta.overlordId || null,
        bounds: { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity }
    };
    if (newMeta.flagUrl) {
        newMeta.tempFlag = new Image();
        newMeta.tempFlag.crossOrigin = "anonymous";
        newMeta.tempFlag.onload = () => influenceLayer && influenceLayer.render();
        newMeta.tempFlag.src = newMeta.flagUrl;
    }
    countryMetadata[newId - 1] = newMeta;

    const sourceRes = source.gridRes || CONFIG.GRID_RES;
    const targetRes = CONFIG.GRID_RES;
    const sourceGridWidth = Math.ceil(360 / sourceRes);

    const mapData = source.mapData || [];
    let paintedAny = false;

    // Map each source cell belonging to the selected country into our grid
    for (let i = 0; i < mapData.length; i++) {
        const [idx, val] = mapData[i];
        if (val !== sourceCountryId) continue;

        const sy = Math.floor(idx / sourceGridWidth);
        const sx = idx % sourceGridWidth;
        const baseLat = (sy * sourceRes) - 90;
        const baseLng = (sx * sourceRes) - 180;

        if (sourceRes === targetRes) {
            const gx = sx;
            const gy = sy;
            const tIdx = gy * gridWidth + gx;
            if (tIdx >= 0 && tIdx < worldControlMap.length && landMask[tIdx] > 0) {
                worldControlMap[tIdx] = newId;
                deJureMap[tIdx] = newId;
                provinceMap[tIdx] = getProvinceId(gx, gy, newId);
                newMeta.bounds.minX = Math.min(newMeta.bounds.minX, gx);
                newMeta.bounds.maxX = Math.max(newMeta.bounds.maxX, gx);
                newMeta.bounds.minY = Math.min(newMeta.bounds.minY, gy);
                newMeta.bounds.maxY = Math.max(newMeta.bounds.maxY, gy);
                paintedAny = true;
            }
        } else {
            // Convert source cell area into one or more target cells
            const xStart = Math.floor((baseLng + 180) / targetRes);
            const xEnd = Math.floor((baseLng + sourceRes + 180 - 0.0001) / targetRes);
            const yStart = Math.floor((baseLat + 90) / targetRes);
            const yEnd = Math.floor((baseLat + sourceRes + 90 - 0.0001) / targetRes);
            for (let gy = yStart; gy <= yEnd; gy++) {
                if (gy < 0 || gy >= gridHeight) continue;
                const rowOffset = gy * gridWidth;
                for (let gx = xStart; gx <= xEnd; gx++) {
                    if (gx < 0 || gx >= gridWidth) continue;
                    const tIdx = rowOffset + gx;
                    worldControlMap[tIdx] = newId;
                    deJureMap[tIdx] = newId;
                    provinceMap[tIdx] = getProvinceId(gx, gy, newId);
                    landMask[tIdx] = landMask[tIdx] || 1;
                    newMeta.bounds.minX = Math.min(newMeta.bounds.minX, gx);
                    newMeta.bounds.maxX = Math.max(newMeta.bounds.maxX, gx);
                    newMeta.bounds.minY = Math.min(newMeta.bounds.minY, gy);
                    newMeta.bounds.maxY = Math.max(newMeta.bounds.maxY, gy);
                    paintedAny = true;
                }
            }
        }
    }

    if (!paintedAny) {
        alert("No territory for that country was found in the source scenario at this resolution.");
        return;
    }

    recalculateAllBounds();
    influenceLayer.render();
    statusText.innerText = `Imported ${newMeta.name} from scenario into this map.`;
}
if (editorLoadZipBtn) {
    editorLoadZipBtn.addEventListener('click', () => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.zip';
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            loadingStatus.innerText = "Importing countries from ZIP...";
            loadingOverlay.style.display = 'flex';

            try {
                const zip = await JSZip.loadAsync(file);
                const files = Object.values(zip.files).filter(f => !f.dir && f.name.toLowerCase().endsWith('.json'));
                if (files.length === 0) {
                    alert("ZIP file does not contain any .json country files.");
                    loadingOverlay.style.display = 'none';
                    return;
                }

                // Find current max id so we can assign new, non‑conflicting IDs
                let maxId = countryMetadata.reduce((m, c) => c && c.id ? Math.max(m, c.id) : m, 0);

                for (const zf of files) {
                    try {
                        const text = await zf.async('text');
                        const data = JSON.parse(text);

                        if (!data.metadata || !data.cells) continue;

                        maxId += 1;
                        const newId = maxId;

                        const sourceRes = data.gridRes || CONFIG.GRID_RES;
                        const meta = {
                            id: newId,
                            name: data.metadata.name || "Imported Nation",
                            color: data.metadata.color || 'rgba(150,150,150,0.5)',
                            rgba: parseColorToRGBA(data.metadata.color || 'rgba(150,150,150,0.5)'),
                            isCustom: true,
                            flagUrl: data.metadata.flagUrl || null,
                            role: data.metadata.role || 'OFFENSE',
                            overlordId: data.metadata.overlordId || null,
                            bounds: { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity }
                        };

                        if (meta.flagUrl) {
                            meta.tempFlag = new Image();
                            meta.tempFlag.crossOrigin = "anonymous";
                            meta.tempFlag.src = meta.flagUrl;
                        }

                        countryMetadata[newId - 1] = meta;

                        // Map cells to current grid
                        const currentRes = CONFIG.GRID_RES;
                        data.cells.forEach(([sx, sy]) => {
                            if (sourceRes === currentRes) {
                                const idx = sy * gridWidth + sx;
                                if (idx < worldControlMap.length && landMask[idx] > 0) {
                                    worldControlMap[idx] = newId;
                                    meta.bounds.minX = Math.min(meta.bounds.minX, sx);
                                    meta.bounds.maxX = Math.max(meta.bounds.maxX, sx);
                                    meta.bounds.minY = Math.min(meta.bounds.minY, sy);
                                    meta.bounds.maxY = Math.max(meta.bounds.maxY, sy);
                                }
                            } else {
                                const baseLat = (sy * sourceRes) - 90;
                                const baseLng = (sx * sourceRes) - 180;
                                const tIdx = getGridIndex(baseLat + sourceRes / 2, baseLng + sourceRes / 2);
                                if (tIdx !== -1 && landMask[tIdx] > 0) {
                                    const tx = Math.floor((baseLng + sourceRes / 2 + 180) / currentRes);
                                    const ty = Math.floor((baseLat + sourceRes / 2 + 90) / currentRes);
                                    worldControlMap[tIdx] = newId;
                                    meta.bounds.minX = Math.min(meta.bounds.minX, tx);
                                    meta.bounds.maxX = Math.max(meta.bounds.maxX, tx);
                                    meta.bounds.minY = Math.min(meta.bounds.minY, ty);
                                    meta.bounds.maxY = Math.max(meta.bounds.maxY, ty);
                                }
                            }
                        });
                    } catch (innerErr) {
                        console.warn("Failed to import one country from ZIP:", innerErr);
                    }
                }

                recalculateAllBounds();
                loadingOverlay.style.display = 'none';
                influenceLayer.render();
                statusText.innerText = "Imported countries from ZIP.";
            } catch (err) {
                console.error("ZIP import failed:", err);
                alert("Failed to import ZIP of countries.");
                loadingOverlay.style.display = 'none';
            }
        };
        input.click();
    });
}

editorFlagLibraryBtn.addEventListener('click', () => {
    openHub('flags');
});

// City tools buttons
if (editorCityNewBtn) {
    editorCityNewBtn.addEventListener('click', () => {
        if (!(gameMode === 'EDITOR' || godModeActive)) return;
        cityEditMode = 'CREATE';
        statusText.innerText = "City Tools: click on the map to create a new city.";
        cityInspector.style.display = 'none';
    });
}

if (editorCityClearBtn) {
    editorCityClearBtn.addEventListener('click', () => {
        if (!(gameMode === 'EDITOR' || godModeActive)) return;
        if (!confirm("Clear all cities from this scenario? This cannot be undone.")) return;
        cities = [];
        activeTheaterCities = [];
        editingCityId = -1;
        cityInspector.style.display = 'none';
        influenceLayer.render();
        statusText.innerText = "All cities cleared.";
    });
}

menuHubBtn.addEventListener('click', () => {
    openHub('scenarios');
});

if (globalChatBtn) {
    globalChatBtn.addEventListener('click', () => {
        openGlobalChat();
    });
}

discordBtn.addEventListener('click', () => {
    window.open('https://discord.gg/R9rYX2ScXe', '_blank');
});

donateBtn.addEventListener('click', () => {
    window.websim.postComment({
        content: "Supporting the development of Modern Wars! ☕",
        credits: 50
    });
});

creditsBtn.addEventListener('click', () => {
    creditsModal.style.display = 'flex';
});

closeCreditsBtn.addEventListener('click', () => {
    creditsModal.style.display = 'none';
});

if (leaderboardBtn) {
    leaderboardBtn.addEventListener('click', () => {
        openLeaderboard();
    });
}

if (closeLeaderboardBtn) {
    closeLeaderboardBtn.addEventListener('click', () => {
        leaderboardOverlay.style.display = 'none';
    });
}

closeHubBtn.addEventListener('click', () => {
    scenarioHubModal.style.display = 'none';
});

// -------- Item details + comments modal logic --------

function renderCommentsList(comments) {
    if (!itemCommentsList) return;
    if (!comments || comments.length === 0) {
        itemCommentsList.innerHTML = `<div style="padding:10px; font-size:11px; color:#777; text-align:center;">No comments yet. Be the first to brief this item.</div>`;
        return;
    }

    // Sort newest -> oldest from collection (already newest-first) but keep parent/replies grouped
    const byParent = new Map();
    comments.forEach(c => {
        const parentId = c.parent_id || null;
        if (!byParent.has(parentId)) byParent.set(parentId, []);
        byParent.get(parentId).push(c);
    });

    const renderThread = (parentId, depth = 0) => {
        const arr = byParent.get(parentId) || [];
        return arr.map(c => {
            const created = new Date(c.created_at).toLocaleString();
            const safeText = (c.text || '').replace(/</g,'&lt;').replace(/>/g,'&gt;');
            const isMine = currentUsername && c.username === currentUsername;
            return `
                <div class="item-comment" data-comment-id="${c.id}" style="padding:6px 8px; border-bottom:1px solid rgba(255,255,255,0.05); margin-left:${depth*12}px;">
                    <div style="display:flex; align-items:center; gap:6px; margin-bottom:2px;">
                        <img src="https://images.websim.com/avatar/${c.username}" style="width:16px; height:16px; border-radius:50%; background:#000;">
                        <span style="font-size:11px; color:#ddd;">${c.username}</span>
                        <span style="font-size:9px; color:#555; margin-left:auto;">${created}</span>
                    </div>
                    <div class="item-comment-text" style="font-size:12px; color:#ccc; white-space:pre-wrap;">${safeText}</div>
                    <div style="margin-top:4px; display:flex; gap:4px;">
                        <button class="mini-btn item-reply-btn" style="padding:2px 6px; font-size:9px;">Reply</button>
                        ${isMine ? `
                            <button class="mini-btn item-edit-btn" style="padding:2px 6px; font-size:9px;">Edit</button>
                            <button class="mini-btn item-delete-btn" style="padding:2px 6px; font-size:9px; background:#c0392b;">Delete</button>
                        ` : ''}
                    </div>
                </div>
                ${renderThread(c.id, depth+1)}
            `;
        }).join('');
    };

    itemCommentsList.innerHTML = renderThread(null);

    // Wire reply buttons
    itemCommentsList.querySelectorAll('.item-reply-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const commentEl = btn.closest('.item-comment');
            if (!commentEl) return;
            currentReplyParentId = commentEl.getAttribute('data-comment-id');
            currentEditingCommentId = null;
            itemReplyIndicator.style.display = 'inline-block';
            itemReplyIndicator.textContent = 'Replying...';
            itemCancelReplyBtn.style.display = 'inline-block';
            itemCommentSubmit.textContent = 'Post';
            itemCommentInput.focus();
        });
    });

    // Wire edit buttons (only for own comments)
    itemCommentsList.querySelectorAll('.item-edit-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const commentEl = btn.closest('.item-comment');
            if (!commentEl) return;
            const id = commentEl.getAttribute('data-comment-id');
            const comment = comments.find(c => c.id === id);
            if (!comment || comment.username !== currentUsername) return;
            currentEditingCommentId = id;
            currentReplyParentId = comment.parent_id || null;
            const textEl = commentEl.querySelector('.item-comment-text');
            const currentText = textEl ? textEl.textContent : (comment.text || '');
            itemCommentInput.value = currentText;
            itemReplyIndicator.style.display = 'inline-block';
            itemReplyIndicator.textContent = 'Editing...';
            itemCancelReplyBtn.style.display = 'inline-block';
            itemCommentSubmit.textContent = 'Save';
            itemCommentInput.focus();
        });
    });

    // Wire delete buttons (only for own comments)
    itemCommentsList.querySelectorAll('.item-delete-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const commentEl = btn.closest('.item-comment');
            if (!commentEl) return;
            const id = commentEl.getAttribute('data-comment-id');
            const comment = comments.find(c => c.id === id);
            if (!comment || comment.username !== currentUsername) return;
            if (!confirm('Delete this comment?')) return;
            (async () => {
                try {
                    await room.collection('hub_comment_v1').delete(id);
                } catch (e) {
                    console.error('Failed to delete comment', e);
                    alert('Failed to delete comment.');
                }
            })();
        });
    });
}

async function openItemModal(type, item) {
    currentCommentItemType = type;
    currentCommentItemId = item.id;
    currentReplyParentId = null;
    currentEditingCommentId = null;
    if (commentsUnsubscribe) {
        commentsUnsubscribe();
        commentsUnsubscribe = null;
    }

    // Title / desc / preview
    itemModalTitle.textContent = item.name || 'Item Details';
    const desc = item.description || item.desc || '';
    itemModalDesc.textContent = desc;
    if (item.previewUrl || item.flagUrl) {
        itemModalPreview.src = item.previewUrl || item.flagUrl;
        itemModalPreview.style.display = 'block';
    } else {
        itemModalPreview.style.display = 'none';
    }

    // Configure big-card actions for all item types
    if (itemModalActions) {
        const canImport = (gameMode === 'EDITOR' || godModeActive);

        if (type === 'scenario') {
            // Play / Remix a scenario
            itemModalActions.style.display = 'flex';
            if (itemModalPlayBtn) {
                itemModalPlayBtn.style.display = 'inline-flex';
                itemModalPlayBtn.textContent = 'Play';
                itemModalPlayBtn.onclick = () => {
                    if (window.playFromHub) {
                        window.playFromHub(item.blobUrl, item.id, item.name || '', item.username || '');
                        itemCommentModal.style.display = 'none';
                    }
                };
            }
            if (itemModalRemixBtn) {
                itemModalRemixBtn.style.display = 'inline-flex';
                itemModalRemixBtn.textContent = 'Remix';
                itemModalRemixBtn.onclick = () => {
                    if (window.remixFromHub) {
                        window.remixFromHub(item.blobUrl, item.id, item.name || '', item.username || '');
                        itemCommentModal.style.display = 'none';
                    }
                };
            }
        } else if (type === 'country' && canImport) {
            // Import a country into the current editor map
            itemModalActions.style.display = 'flex';
            if (itemModalPlayBtn) {
                itemModalPlayBtn.style.display = 'inline-flex';
                itemModalPlayBtn.textContent = 'Import';
                itemModalPlayBtn.onclick = () => {
                    if (window.importFromLibrary) {
                        window.importFromLibrary(item.id);
                        itemCommentModal.style.display = 'none';
                    }
                };
            }
            if (itemModalRemixBtn) {
                // Hide secondary button for countries
                itemModalRemixBtn.style.display = 'none';
                itemModalRemixBtn.onclick = null;
            }
        } else if (type === 'flag' && canImport) {
            // Use a flag from the library on the currently selected country
            itemModalActions.style.display = 'flex';
            if (itemModalPlayBtn) {
                itemModalPlayBtn.style.display = 'inline-flex';
                itemModalPlayBtn.textContent = 'Use Flag';
                itemModalPlayBtn.onclick = () => {
                    if (window.importFlagFromLibrary) {
                        window.importFlagFromLibrary(item.id);
                        itemCommentModal.style.display = 'none';
                    }
                };
            }
            if (itemModalRemixBtn) {
                // Hide secondary button for flags
                itemModalRemixBtn.style.display = 'none';
                itemModalRemixBtn.onclick = null;
            }
        } else {
            // No applicable actions (e.g. not in editor for country/flag)
            itemModalActions.style.display = 'none';
            if (itemModalPlayBtn) itemModalPlayBtn.onclick = null;
            if (itemModalRemixBtn) itemModalRemixBtn.onclick = null;
        }
    }

    // Clear composer
    itemCommentInput.value = '';
    itemReplyIndicator.style.display = 'none';
    itemCancelReplyBtn.style.display = 'none';
    itemCommentSubmit.textContent = 'Post';

    // Subscribe to comments for this item (using records)
    try {
        const coll = room.collection('hub_comment_v1').filter({
            item_type: type,
            item_id: item.id
        });
        commentsUnsubscribe = coll.subscribe((records) => {
            renderCommentsList(records || []);
        });
        // Initial render
        renderCommentsList(coll.getList());
    } catch (e) {
        console.warn('Comment subscription failed', e);
        renderCommentsList([]);
    }

    itemCommentModal.style.display = 'flex';
}

// -------- Global Chat Logic --------

function renderGlobalChatList(messages) {
    if (!globalChatList) return;
    if (!messages || messages.length === 0) {
        globalChatList.innerHTML = `<div style="text-align:center; font-size:11px; color:#666; padding:16px;">No messages yet. Say hello!</div>`;
        return;
    }
    // oldest at top
    const sorted = messages.slice().sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
    globalChatList.innerHTML = sorted.map(m => {
        const created = new Date(m.created_at).toLocaleTimeString();
        const safeText = (m.text || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const isMine = currentUsername && m.username === currentUsername;
        return `
            <div style="margin-bottom:6px; font-size:12px; ${isMine ? 'text-align:right;' : ''}">
                <div style="display:flex; ${isMine ? 'flex-direction:row-reverse;' : ''} align-items:center; gap:6px;">
                    <img src="https://images.websim.com/avatar/${m.username}" style="width:16px; height:16px; border-radius:50%; background:#000;">
                    <span style="font-size:11px; color:#ddd;">${m.username}</span>
                    <span style="font-size:9px; color:#555;">${created}</span>
                </div>
                <div style="margin-top:2px; color:#ccc; white-space:pre-wrap;">${safeText}</div>
            </div>
        `;
    }).join('');
    globalChatList.scrollTop = globalChatList.scrollHeight;
}

async function openGlobalChat() {
    if (!globalChatModal) return;
    if (!room) {
        try {
            await initMultiplayer();
        } catch (e) {
            console.warn('Failed to init multiplayer for chat', e);
        }
    }
    globalChatModal.style.display = 'flex';
    if (room && !globalChatUnsubscribe) {
        const coll = room.collection('global_chat_v1');
        globalChatUnsubscribe = coll.subscribe((records) => {
            renderGlobalChatList(records || []);
        });
        renderGlobalChatList(coll.getList());
    }
}

if (globalChatClose) {
    globalChatClose.addEventListener('click', () => {
        globalChatModal.style.display = 'none';
    });
}

if (globalChatSend) {
    globalChatSend.addEventListener('click', async () => {
        if (!room || !globalChatInput) return;
        const text = globalChatInput.value.trim();
        if (!text) return;
        try {
            await room.collection('global_chat_v1').create({
                text
            });
            globalChatInput.value = '';
        } catch (e) {
            console.error('Failed to send chat message', e);
        }
    });
}

if (globalChatInput) {
    globalChatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (globalChatSend) globalChatSend.click();
        }
    });
}

itemCommentSubmit.addEventListener('click', async () => {
    if (!currentCommentItemType || !currentCommentItemId) return;
    const text = itemCommentInput.value.trim();
    if (!text) return;
    try {
        if (currentEditingCommentId) {
            // Edit existing comment
            await room.collection('hub_comment_v1').update(currentEditingCommentId, {
                text
            });
        } else {
            // New comment or reply
            await room.collection('hub_comment_v1').create({
                item_type: currentCommentItemType,
                item_id: currentCommentItemId,
                parent_id: currentReplyParentId || null,
                text,
            });
        }
        itemCommentInput.value = '';
        currentReplyParentId = null;
        currentEditingCommentId = null;
        itemReplyIndicator.style.display = 'none';
        itemCancelReplyBtn.style.display = 'none';
        itemCommentSubmit.textContent = 'Post';
    } catch (e) {
        console.error('Failed to post comment', e);
        alert('Failed to post comment. Try again.');
    }
});

itemCancelReplyBtn.addEventListener('click', () => {
    currentReplyParentId = null;
    currentEditingCommentId = null;
    itemReplyIndicator.style.display = 'none';
    itemCancelReplyBtn.style.display = 'none';
    itemCommentSubmit.textContent = 'Post';
});

closeItemModalBtn.addEventListener('click', () => {
    itemCommentModal.style.display = 'none';
    if (commentsUnsubscribe) {
        commentsUnsubscribe();
        commentsUnsubscribe = null;
    }
});

editorShareBtn.addEventListener('click', () => {
    if (countryMetadata.length < 2) {
        alert("Your map must have at least 2 nations to be playable.");
        return;
    }
    uploadNameInput.value = "";
    uploadDescInput.value = "";
    uploadDetailsModal.style.display = 'flex';
});

cancelUploadBtn.addEventListener('click', () => {
    uploadDetailsModal.style.display = 'none';
});

confirmUploadBtn.addEventListener('click', async () => {
    const name = uploadNameInput.value.trim() || "Untitled Scenario";
    const desc = uploadDescInput.value.trim();
    
    uploadDetailsModal.style.display = 'none';
    loadingStatus.innerText = "Uploading Scenario...";
    loadingOverlay.style.display = 'flex';

    try {
        // 1. Generate Preview Snapshot
        let previewUrl = null;
        if (influenceLayer && influenceLayer._container) {
            influenceLayer._isCapturing = true;
            influenceLayer.render();
            const canvas = influenceLayer._container;
            const previewBlob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.8));
            influenceLayer._isCapturing = false;
            influenceLayer.render();
            if (previewBlob) {
                const previewFile = new File([previewBlob], "preview.jpg", { type: "image/jpeg" });
                previewUrl = await websim.upload(previewFile);
            }
        }

        // 2. Generate and Upload JSON
        const saveData = generatePresetData(name);
        const blob = new Blob([JSON.stringify(saveData)], { type: 'application/json' });
        const file = new File([blob], "scenario.json", { type: "application/json" });
        const blobUrl = await websim.upload(file);

        // Determine if this is a remix
        const currentUser = await window.websim.getCurrentUser();
        let remixedFromId = null;
        let remixedFromName = null;

        // If current scenario context exists, it's a remix
        if (currentScenarioContext) {
            remixedFromId = currentScenarioContext.id;
            remixedFromName = currentScenarioContext.name;
        }

        // 3. Create Persistent Record
        await room.collection('scenario_v1').create({
            name: name,
            description: desc,
            previewUrl: previewUrl,
            blobUrl: blobUrl,
            remixed_from_id: remixedFromId,
            remixed_from_name: remixedFromName
        });

        loadingOverlay.style.display = 'none';
        alert("Scenario uploaded successfully to the hub!");
    } catch (e) {
        console.error(e);
        alert("Failed to upload scenario.");
        loadingOverlay.style.display = 'none';
    }
});

menuLoadPlayBtn.addEventListener('click', () => {
    initAudio();
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
        currentScenarioContext = null;
        performPresetLoad(e.target.files[0], 'CONQUEST');
    };
    input.click();
});

editorModeBtn.addEventListener('click', () => {
    editorChoiceModal.style.display = 'flex';
});

cancelEditorChoice.onclick = () => {
    editorChoiceModal.style.display = 'none';
};

choiceExternalEditor.onclick = () => {
    window.open('https://websim.com/@thepineguy/modern-wars-alternative-editor', '_blank');
    editorChoiceModal.style.display = 'none';
};

choiceIngameEditor.onclick = () => {
    editorChoiceModal.style.display = 'none';
    editorSourceModal.style.display = 'flex';
};

cancelSourceChoice.onclick = () => {
    editorSourceModal.style.display = 'none';
    editorChoiceModal.style.display = 'flex';
};

choiceSourceEarth.onclick = () => {
    isCustomTerrain = false;
    editorSourceModal.style.display = 'none';
    initAudio();
    gameMode = 'EDITOR';
    gameState = 'EDITOR_ACTIVE';
    currentScenarioContext = null;
    activeScenarioId = null;
    editorUpdateBtn.style.display = 'none';
    mainMenu.style.display = 'none';
    mapUi.style.display = 'flex';
    editorToolbox.style.display = 'flex';
    
    // Ensure grid is ready
    if (!worldControlMap) {
        gridWidth = Math.ceil(360 / CONFIG.GRID_RES);
        gridHeight = Math.ceil(180 / CONFIG.GRID_RES);
        worldControlMap = new Int32Array(gridWidth * gridHeight);
        deJureMap = new Int32Array(gridWidth * gridHeight);
        provinceMap = new Int32Array(gridWidth * gridHeight);
        occupationMap = new Float32Array(gridWidth * gridHeight);
        primaryOccupierMap = new Int32Array(gridWidth * gridHeight);
        landMask = new Uint8Array(gridWidth * gridHeight);
        terrainMask = new Float32Array(gridWidth * gridHeight);
        flagProcessedBuffer = new Int32Array(gridWidth * gridHeight);
        flagOwnerBuffer = new Int32Array(gridWidth * gridHeight);
        flagSovereignBuffer = new Int32Array(gridWidth * gridHeight);
        sovereignProcessedBuffer = new Uint8Array(gridWidth * gridHeight);
    }

    loadCities();
    statusText.innerText = "Map Editor (Alpha)";
    setupPanel.style.display = 'none';
    resetBtn.style.display = 'block';
    editorUnclaimBtn.style.display = 'block';
    
    // Load geography without filling country IDs
    const mapRes = document.getElementById('map-res-select').value;
    const geoUrl = `${CONFIG.GEOJSON_BASE}${mapRes}/cultural/ne_${mapRes}_admin_0_countries.json`;
    loadCountries(geoUrl, true);

    if (getCookie('mw_editor_tutorial_finished') !== 'true') {
        startTutorial(editorTutorialSteps, 'mw_editor_tutorial_finished');
    }

    updateRestartVisibility();
};

choiceSourceBlank.onclick = () => {
    document.getElementById('blank-size-modal').style.display = 'flex';
};

document.getElementById('cancel-blank-size-btn').onclick = () => {
    document.getElementById('blank-size-modal').style.display = 'none';
};

document.getElementById('confirm-blank-size-btn').onclick = () => {
    const w = parseFloat(document.getElementById('blank-width-input').value) || 360;
    const h = parseFloat(document.getElementById('blank-height-input').value) || 180;
    
    document.getElementById('blank-size-modal').style.display = 'none';
    isCustomTerrain = true;
    editorSourceModal.style.display = 'none';
    initAudio();
    gameMode = 'EDITOR';
    gameState = 'EDITOR_ACTIVE';
    currentScenarioContext = null;
    activeScenarioId = null;
    editorUpdateBtn.style.display = 'none';
    mainMenu.style.display = 'none';
    mapUi.style.display = 'flex';
    editorToolbox.style.display = 'flex';
    
    // Ensure grid is ready
    if (!worldControlMap) {
        initializeEngine();
    }

    // Initialize Blank Canvas State
    worldControlMap.fill(0);
    deJureMap.fill(0);
    landMask.fill(0);
    provinceMap.fill(0);
    terrainMask.fill(0);
    cities = [];
    activeTheaterCities = [];
    countryMetadata = [];
    
    // Custom World Size Logic:
    // If w or h are smaller than full world, we restrict the view and paintable area
    if (w < 360 || h < 180) {
        const halfW = w / 2;
        const halfH = h / 2;
        const bounds = [[-halfH, -halfW], [halfH, halfW]];
        map.setMaxBounds(bounds);
        map.fitBounds(bounds);
        
        // Block painting outside these bounds by keeping landMask at 0 (Ocean) for those cells
        // Note: The paintAt logic already checks landMask[idx] > 0 for country painting.
        // We'll also update terrain brush to respect these bounds if we really wanted to be strict.
    } else {
        map.setMaxBounds(null);
    }

    // Switch to Simplified View for better "blank canvas" painting feel (temporarily)
    setImageryProvider('wargames', false);
    if (disableCountryGradientCheckbox) {
        disableCountryGradientCheckbox.checked = true;
        disableCountryGradient = true;
    }

    statusText.innerText = "Blank Canvas: Draw Terrain";
    setupPanel.style.display = 'none';
    resetBtn.style.display = 'block';
    
    // Instantly jump to Page 3 tools so they see the terrain brush
    updateEditorToolPage(3);
    
    influenceLayer.render();
    updateRestartVisibility();
};

/**
 * GAMEPAD API SUPPORT
 */
let lastGamepadButtons = new Array(17).fill(false);
let gamepadFrameCount = 0;

function handleGamepadInput() {
    const gamepads = navigator.getGamepads();
    const gp = Array.from(gamepads).find(g => g !== null);
    if (!gp) return;

    gamepadFrameCount++;

    const deadzone = 0.2;
    const lx = Math.abs(gp.axes[0]) > deadzone ? gp.axes[0] : 0;
    const ly = Math.abs(gp.axes[1]) > deadzone ? gp.axes[1] : 0;
    const ry = Math.abs(gp.axes[3]) > deadzone ? gp.axes[3] : 0;

    // Panning (Left Stick)
    if (lx !== 0 || ly !== 0) {
        map.panBy([lx * 15, ly * 15], { animate: false });
    }

    // Zooming (Right Stick Y - Throttled)
    if (Math.abs(ry) > 0.5 && gamepadFrameCount % 12 === 0) {
        if (ry < 0) map.zoomIn();
        else map.zoomOut();
    }

    const pressed = (i) => gp.buttons[i] && gp.buttons[i].pressed && !lastGamepadButtons[i];

    if (pressed(0)) { // A - Select / Pause
        if (gameState === 'SIMULATING') togglePause();
        else if (mainMenu.style.display === 'flex') playModeBtn.click();
        else if (settingsOverlay.style.display === 'flex') launchBtn.click();
    }
    if (pressed(1)) { // B - Back / God Mode
        if (gameState === 'SIMULATING' || gameState === 'EDITOR_ACTIVE' || gameState.startsWith('SELECTING')) {
            godModeBtn.click();
        }
    }
    if (pressed(2)) { // X - Speed Down
        if (gameState === 'SIMULATING') speedDownBtn.click();
    }
    if (pressed(3)) { // Y - Speed Up
        if (gameState === 'SIMULATING') speedUpBtn.click();
    }
    if (pressed(8)) { // Select - Reset
        if (resetBtn.style.display !== 'none') resetBtn.click();
    }
    if (pressed(9)) { // Start - Settings
        if (mainMenu.style.display === 'flex') mainSettingsBtn.click();
        else ingameSettingsBtn.click();
    }

    lastGamepadButtons = gp.buttons.map(b => b.pressed);
}

minimizeSetupBtn.onclick = (e) => {
    e.stopPropagation();
    const isMinimized = setupPanel.classList.toggle('minimized');
    minimizeSetupBtn.innerText = isMinimized ? '+' : '−';
};

minimizeStatsBtn.onclick = (e) => {
    e.stopPropagation();
    const isMinimized = statsPanel.classList.toggle('minimized');
    minimizeStatsBtn.innerText = isMinimized ? '+' : '−';
};

minimizeStatusBtn.onclick = (e) => {
    e.stopPropagation();
    const isMinimized = document.getElementById('game-status').classList.toggle('minimized');
    minimizeStatusBtn.innerText = isMinimized ? '+' : '−';
};

function gamepadLoop() {
    handleGamepadInput();
    requestAnimationFrame(gamepadLoop);
}
gamepadLoop();

// Keep simulation running when tab is not focused (background ticking)
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // Stop visual loop and start a lightweight background tick loop
        if (animationFrameId !== null) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = null;
        }
        if (!backgroundTickId && gameState === 'SIMULATING') {
            backgroundTickId = setInterval(() => {
                if (gameState !== 'SIMULATING') return;
                // Advance simulation based on simSpeed, but skip rendering/UI-heavy work
                frameAccumulator += simSpeed;
                while (frameAccumulator >= 1) {
                    const warEnded = performSimulationTick();
                    if (warEnded) {
                        frameAccumulator = 0;
                        break;
                    }
                    frameAccumulator -= 1;
                }
                // Advance in-game date based on background tick interval
                tickGameTime(100);
                simFrameCount++;
            }, 100); // ~10 ticks per second while unfocused
        }
    } else {
        // Back to foreground: stop background loop and resume visual loop
        if (backgroundTickId) {
            clearInterval(backgroundTickId);
            backgroundTickId = null;
        }
        if (gameState === 'SIMULATING') {
            if (animationFrameId !== null) {
                cancelAnimationFrame(animationFrameId);
            }
            animationFrameId = requestAnimationFrame(updateLoop);
        }
    }
});

window.addEventListener("gamepadconnected", (e) => {
    console.log("Gamepad connected at index %d: %s. %d buttons, %d axes.",
        e.gamepad.index, e.gamepad.id,
        e.gamepad.buttons.length, e.gamepad.axes.length);
    statusText.innerText = "Gamepad Linked: " + e.gamepad.id.substring(0, 15) + "...";
});

 // Support modal: show once with cookie persistence
 function showSupportModalIfNeeded() {
     try {
         const dontShow = getCookie('mw_support_dont_show');
         if (dontShow === 'true') return;
     } catch (e) { /* ignore */ }
 
     const modal = document.getElementById('support-modal');
     if (!modal) return;
 
     const joinBtn = document.getElementById('support-join-discord');
     const closeBtn = document.getElementById('support-close');
     const neverCheckbox = document.getElementById('support-never-show-checkbox');
 
     // Default: toggle "Never show this again" ON when the popup appears,
     // and persist that decision immediately so it won't show again next boot.
     if (neverCheckbox) {
         neverCheckbox.checked = true;
         setCookie('mw_support_dont_show', 'true');
     }
 
     modal.style.display = 'flex';
 
     joinBtn.onclick = () => {
         // If user explicitly unchecked before clicking, respect that by clearing cookie.
         if (neverCheckbox) {
             if (neverCheckbox.checked) setCookie('mw_support_dont_show', 'true');
             else setCookie('mw_support_dont_show', 'false');
         }
         // Open Discord (same link used elsewhere)
         window.open('https://discord.gg/R9rYX2ScXe', '_blank');
         modal.style.display = 'none';
     };
 
     closeBtn.onclick = () => {
         if (neverCheckbox) {
             if (neverCheckbox.checked) setCookie('mw_support_dont_show', 'true');
             else setCookie('mw_support_dont_show', 'false');
         }
         modal.style.display = 'none';
     };
 }