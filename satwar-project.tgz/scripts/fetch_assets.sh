#!/usr/bin/env bash
# Downloads everything the game needs that is NOT part of the game files themselves,
# so the finished APK works without any CDN:
#   - Leaflet and JSZip (previously loaded from esm.sh / unpkg)
#   - Natural Earth map data (previously loaded from raw.githubusercontent.com)
#   - Country flag images (previously loaded from flagcdn.com)
# Runs inside GitHub Actions, where the network is open.
set -euo pipefail
cd "$(dirname "$0")/.."

A=app/src/main/assets
V=$A/www/vendor
mkdir -p "$V/images" "$A/flags" \
  "$A/ne/110m/cultural" "$A/ne/110m/physical" \
  "$A/ne/50m/cultural" "$A/ne/50m/physical" \
  "$A/ne/10m/cultural"

echo "== Leaflet + JSZip (npm)"
TMP="$(mktemp -d)"
( cd "$TMP" && npm init -y >/dev/null && npm install --no-audit --no-fund leaflet@1.9.4 jszip@3.10.1 )
cp "$TMP/node_modules/leaflet/dist/leaflet-src.js" "$V/leaflet-src.js"
cp "$TMP/node_modules/leaflet/dist/leaflet.css"    "$V/leaflet.css"
cp "$TMP/node_modules/leaflet/dist/images/"*        "$V/images/"
cp "$TMP/node_modules/jszip/dist/jszip.min.js"     "$V/jszip.min.js"
test -s "$V/leaflet-src.js" && test -s "$V/jszip.min.js"

echo "== Natural Earth map data"
B=https://raw.githubusercontent.com/martynafford/natural-earth-geojson/master
dl() {
  local rel="$1" mode="${2:-required}"
  if curl -fsSL --retry 4 --retry-delay 3 "$B/$rel" -o "$A/ne/$rel"; then
    echo "ok    $rel ($(du -h "$A/ne/$rel" | cut -f1))"
  else
    rm -f "$A/ne/$rel"
    if [ "$mode" = optional ]; then
      echo "::warning::未能下载可选地图数据 $rel（该精度将回退为联网加载）"
    else
      echo "::error::下载失败: $rel"; exit 1
    fi
  fi
}
dl 110m/cultural/ne_110m_admin_0_countries.json
dl 50m/cultural/ne_50m_admin_0_countries.json
dl 110m/physical/ne_110m_geography_regions_polys.json
dl 50m/physical/ne_50m_geography_regions_polys.json
dl 50m/cultural/ne_50m_populated_places_simple.json
# The "High (Very Heavy)" map precision. Large file, so it is optional.
dl 10m/cultural/ne_10m_admin_0_countries.json optional

echo "== Flags"
curl -fsSL --retry 4 --retry-delay 3 https://flagcdn.com/en/codes.json -o "$A/flags/codes.json"
jq -r 'keys[]' "$A/flags/codes.json" | xargs -P 8 -I{} sh -c \
  'curl -fsSL --retry 3 --retry-delay 2 "https://flagcdn.com/w320/{}.png" -o "'"$A"'/flags/{}.png" || { rm -f "'"$A"'/flags/{}.png"; echo "skip flag {}"; }'
echo "flags downloaded: $(ls "$A/flags"/*.png 2>/dev/null | wc -l)"

echo "== Game files check"
for f in "style.css" "other thing (1).png" "world map 2022.json" \
         "explosion-pas-61639.mp3" "low-button-click-331780.mp3" \
         "war.wav" "peace.wav" "modern-war-129016.mp3"; do
  if [ ! -e "$A/www/$f" ]; then
    echo "::warning::缺少游戏文件: $f"
  fi
done
echo "done."
